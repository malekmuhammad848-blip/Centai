import { useEffect, useRef, useCallback } from 'react';
import { useStore, type Track } from '../store/useStore';
import { TRACKS } from '../data/mock';

// Free sample audio tracks (royalty-free)
const AUDIO_SOURCES: Record<string, string> = {
  '1': 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
  '2': 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
  '3': 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
  '4': 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3',
  '5': 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3',
  '6': 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3',
  '7': 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3',
  '8': 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3',
  '9': 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-9.mp3',
  '10': 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-10.mp3',
  '11': 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-11.mp3',
  '12': 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-12.mp3',
};

/* ========== SINGLETON AUDIO - Lives outside React ========== */
class AudioManager {
  private audio: HTMLAudioElement;
  private loadedTrackId: string | null = null;
  private isLoading = false;
  constructor() {
    this.audio = new Audio();
    this.audio.preload = 'auto';
    this.audio.volume = 0.8;
    
    // Critical: Set up event handlers once
    this.audio.onended = () => this.handleTrackEnd();
    this.audio.onerror = () => {
      this.isLoading = false;
      console.warn('Audio playback error');
    };

    // Start progress tracking
    this.startProgressTracking();
  }

  private handleTrackEnd() {
    const state = useStore.getState();
    if (state.repeatMode === 'one') {
      this.audio.currentTime = 0;
      this.audio.play().catch(() => {});
    } else {
      // Play next track
      const tracks = state.queue.length > 0 ? state.queue : TRACKS;
      const currentIndex = tracks.findIndex(t => t.id === state.currentTrack?.id);
      const nextIndex = (currentIndex + 1) % tracks.length;
      state.setCurrentTrack(tracks[nextIndex]);
      state.setIsPlaying(true);
    }
  }

  private startProgressTracking() {
    // Use a single persistent interval
    setInterval(() => {
      const state = useStore.getState();
      if (!state.isPlaying || !state.currentTrack) return;

      const audio = this.audio;
      if (audio.duration && !isNaN(audio.duration) && audio.duration > 0) {
        const pct = (audio.currentTime / audio.duration) * 100;
        state.setProgress(pct);

        // Update Media Session position
        if ('mediaSession' in navigator) {
          try {
            navigator.mediaSession.setPositionState({
              duration: audio.duration,
              playbackRate: audio.playbackRate,
              position: Math.min(audio.currentTime, audio.duration),
            });
          } catch {
            // Ignore position state errors
          }
        }
      }
    }, 250);
  }

  loadTrack(track: Track) {
    const src = AUDIO_SOURCES[track.id] || AUDIO_SOURCES['1'];
    
    if (this.loadedTrackId === track.id) {
      // Same track, don't reload
      return;
    }

    this.isLoading = true;
    this.loadedTrackId = track.id;

    // Set source and load
    this.audio.src = src;
    this.audio.load();

    this.audio.oncanplay = () => {
      this.isLoading = false;
      // Check if we should auto-play
      const state = useStore.getState();
      if (state.isPlaying && state.currentTrack?.id === this.loadedTrackId) {
        this.audio.play().catch(() => {
          // Autoplay blocked - user needs to interact first
        });
      }
    };

    // Update Media Session metadata
    this.updateMediaSessionMetadata(track);
  }

  play() {
    if (this.audio.src && !this.isLoading) {
      this.audio.play().catch(() => {});
    }
    if ('mediaSession' in navigator) {
      navigator.mediaSession.playbackState = 'playing';
    }
  }

  pause() {
    this.audio.pause();
    if ('mediaSession' in navigator) {
      navigator.mediaSession.playbackState = 'paused';
    }
  }

  setVolume(vol: number) {
    this.audio.volume = Math.max(0, Math.min(1, vol / 100));
  }

  seekTo(percentage: number) {
    if (this.audio.duration && !isNaN(this.audio.duration)) {
      this.audio.currentTime = (percentage / 100) * this.audio.duration;
      useStore.getState().setProgress(percentage);
    }
  }

  getCurrentTime(): number {
    return this.audio.currentTime || 0;
  }

  getDuration(): number {
    if (this.audio.duration && !isNaN(this.audio.duration)) {
      return this.audio.duration;
    }
    const state = useStore.getState();
    return state.currentTrack?.duration || 0;
  }

  private updateMediaSessionMetadata(track: Track) {
    if (!('mediaSession' in navigator)) return;

    navigator.mediaSession.metadata = new MediaMetadata({
      title: track.title,
      artist: track.artist,
      album: track.album,
      artwork: [
        { src: track.cover, sizes: '96x96', type: 'image/jpeg' },
        { src: track.cover, sizes: '128x128', type: 'image/jpeg' },
        { src: track.cover, sizes: '192x192', type: 'image/jpeg' },
        { src: track.cover, sizes: '256x256', type: 'image/jpeg' },
        { src: track.cover, sizes: '384x384', type: 'image/jpeg' },
        { src: track.cover, sizes: '512x512', type: 'image/jpeg' },
      ],
    });
  }

  setupMediaSessionHandlers() {
    if (!('mediaSession' in navigator)) return;

    const ms = navigator.mediaSession;

    ms.setActionHandler('play', () => {
      this.audio.play().catch(() => {});
      useStore.getState().setIsPlaying(true);
    });

    ms.setActionHandler('pause', () => {
      this.audio.pause();
      useStore.getState().setIsPlaying(false);
    });

    ms.setActionHandler('previoustrack', () => {
      const state = useStore.getState();
      const tracks = state.queue.length > 0 ? state.queue : TRACKS;
      const currentIndex = tracks.findIndex(t => t.id === state.currentTrack?.id);
      const prevIndex = currentIndex <= 0 ? tracks.length - 1 : currentIndex - 1;
      state.setCurrentTrack(tracks[prevIndex]);
      state.setIsPlaying(true);
    });

    ms.setActionHandler('nexttrack', () => {
      const state = useStore.getState();
      const tracks = state.queue.length > 0 ? state.queue : TRACKS;
      const currentIndex = tracks.findIndex(t => t.id === state.currentTrack?.id);
      const nextIndex = (currentIndex + 1) % tracks.length;
      state.setCurrentTrack(tracks[nextIndex]);
      state.setIsPlaying(true);
    });

    ms.setActionHandler('seekto', (details) => {
      if (details.seekTime !== undefined) {
        this.audio.currentTime = details.seekTime;
        if (this.audio.duration) {
          useStore.getState().setProgress((details.seekTime / this.audio.duration) * 100);
        }
      }
    });

    ms.setActionHandler('seekbackward', (details) => {
      this.audio.currentTime = Math.max(0, this.audio.currentTime - (details.seekOffset || 10));
    });

    ms.setActionHandler('seekforward', (details) => {
      this.audio.currentTime = Math.min(this.audio.duration || 0, this.audio.currentTime + (details.seekOffset || 10));
    });
  }
}

// Create singleton instance
let audioManager: AudioManager | null = null;

function getAudioManager(): AudioManager {
  if (!audioManager) {
    audioManager = new AudioManager();
    audioManager.setupMediaSessionHandlers();
  }
  return audioManager;
}

/* ========== REACT HOOK ========== */
export function useAudioPlayer() {
  const currentTrack = useStore(s => s.currentTrack);
  const isPlaying = useStore(s => s.isPlaying);
  const volume = useStore(s => s.volume);
  const initialized = useRef(false);

  // Initialize manager once
  useEffect(() => {
    if (!initialized.current) {
      getAudioManager();
      initialized.current = true;
    }
  }, []);

  // Load track when it changes
  useEffect(() => {
    if (!currentTrack) return;
    getAudioManager().loadTrack(currentTrack);
  }, [currentTrack?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  // Play/Pause control
  useEffect(() => {
    if (!currentTrack) return;
    const manager = getAudioManager();
    if (isPlaying) {
      manager.play();
    } else {
      manager.pause();
    }
  }, [isPlaying, currentTrack?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  // Volume control
  useEffect(() => {
    getAudioManager().setVolume(volume);
  }, [volume]);

  const seekTo = useCallback((pct: number) => {
    getAudioManager().seekTo(Math.max(0, Math.min(100, pct)));
  }, []);

  const playNext = useCallback(() => {
    const state = useStore.getState();
    if (state.repeatMode === 'one') {
      const manager = getAudioManager();
      manager.seekTo(0);
      manager.play();
      return;
    }
    const tracks = state.queue.length > 0 ? state.queue : TRACKS;
    const currentIndex = tracks.findIndex(t => t.id === state.currentTrack?.id);
    let nextIndex: number;
    if (state.shuffle) {
      nextIndex = Math.floor(Math.random() * tracks.length);
      while (nextIndex === currentIndex && tracks.length > 1) {
        nextIndex = Math.floor(Math.random() * tracks.length);
      }
    } else {
      nextIndex = (currentIndex + 1) % tracks.length;
    }
    state.setCurrentTrack(tracks[nextIndex]);
    state.setIsPlaying(true);
  }, []);

  const playPrev = useCallback(() => {
    const manager = getAudioManager();
    if (manager.getCurrentTime() > 3) {
      manager.seekTo(0);
      return;
    }
    const state = useStore.getState();
    const tracks = state.queue.length > 0 ? state.queue : TRACKS;
    const currentIndex = tracks.findIndex(t => t.id === state.currentTrack?.id);
    const prevIndex = currentIndex <= 0 ? tracks.length - 1 : currentIndex - 1;
    state.setCurrentTrack(tracks[prevIndex]);
    state.setIsPlaying(true);
  }, []);

  const getCurrentTime = useCallback(() => {
    return getAudioManager().getCurrentTime();
  }, []);

  const getDuration = useCallback(() => {
    return getAudioManager().getDuration();
  }, []);

  return {
    seekTo,
    playNext,
    playPrev,
    getCurrentTime,
    getDuration,
  };
}
