import { motion } from 'framer-motion';
import { Play, Pause, Heart, MoreHorizontal } from 'lucide-react';
import { useStore, type Track } from '../store/useStore';
import { formatDuration, formatNumber } from '../data/mock';

export function TrackCard({ track, index, variant = 'default' }: { track: Track; index: number; variant?: 'default' | 'list' | 'compact' }) {
  const { currentTrack, setCurrentTrack, isPlaying, togglePlay, favorites, toggleFavorite } = useStore();
  const isActive = currentTrack?.id === track.id;
  const isFav = favorites.includes(track.id);

  const handlePlay = () => {
    if (isActive) {
      togglePlay();
    } else {
      setCurrentTrack(track);
      useStore.getState().setIsPlaying(true);
    }
  };

  if (variant === 'list') {
    return (
      <motion.div
        initial={{ opacity: 0, x: -10 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: index * 0.04 }}
        className={`flex items-center gap-4 p-3 rounded-xl group cursor-pointer transition-all duration-200 ${
          isActive ? 'bg-cent-500/6' : 'hover:bg-white/[0.02]'
        }`}
        onClick={handlePlay}
      >
        <span className={`text-sm w-6 text-right font-mono ${isActive ? 'text-cent-400' : 'text-white/15'}`}>
          {isActive && isPlaying ? (
            <div className="flex items-end gap-[2px] h-4 justify-end">
              {[0, 1, 2].map(i => (
                <motion.div
                  key={i}
                  className="w-[2px] bg-cent-400 rounded-full"
                  animate={{ height: ['20%', '100%', '20%'] }}
                  transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.15 }}
                />
              ))}
            </div>
          ) : (
            index + 1
          )}
        </span>
        <div className="relative w-11 h-11 rounded-lg overflow-hidden flex-shrink-0 shadow-md">
          <img src={track.cover} alt="" className="w-full h-full object-cover" />
          <div className={`absolute inset-0 bg-black/40 flex items-center justify-center transition-opacity ${isActive ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}>
            {isActive && isPlaying ? <Pause className="w-4 h-4 text-white" /> : <Play className="w-4 h-4 text-white ml-0.5" />}
          </div>
        </div>
        <div className="flex-1 min-w-0">
          <p className={`text-sm font-medium truncate ${isActive ? 'text-cent-400' : 'text-white/80'}`}>{track.title}</p>
          <p className="text-[11px] text-white/25 truncate">{track.artist} · {track.album}</p>
        </div>
        <span className="text-[11px] text-white/15 hidden sm:block font-mono">{formatNumber(track.plays)}</span>
        <motion.button
          whileTap={{ scale: 0.8 }}
          onClick={(e) => { e.stopPropagation(); toggleFavorite(track.id); }}
          className="opacity-0 group-hover:opacity-100 transition-opacity p-1"
        >
          <Heart className={`w-4 h-4 transition-colors ${isFav ? 'fill-cent-400 text-cent-400' : 'text-white/15'}`} />
        </motion.button>
        <span className="text-[11px] text-white/15 font-mono w-10 text-right">{formatDuration(track.duration)}</span>
        <button className="opacity-0 group-hover:opacity-100 transition-opacity p-1">
          <MoreHorizontal className="w-4 h-4 text-white/15" />
        </button>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.06 }}
      whileHover={{ y: -6 }}
      className="group cursor-pointer"
      onClick={handlePlay}
    >
      <div className="relative aspect-square rounded-2xl overflow-hidden mb-3 shadow-lg shadow-black/30 group-hover:shadow-xl group-hover:shadow-black/40 transition-all duration-300">
        <img
          src={track.cover}
          alt={track.title}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/5 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-300" />
        
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          className="absolute bottom-3 right-3 w-11 h-11 rounded-full bg-cent-500 shadow-lg shadow-cent-500/40 flex items-center justify-center opacity-0 group-hover:opacity-100 translate-y-3 group-hover:translate-y-0 transition-all duration-300"
        >
          {isActive && isPlaying ? <Pause className="w-4 h-4 text-white" /> : <Play className="w-4 h-4 text-white ml-0.5" />}
        </motion.button>

        {isActive && isPlaying && (
          <div className="absolute top-3 left-3 px-2 py-1 rounded-full bg-black/50 backdrop-blur-sm">
            <div className="flex items-end gap-[2px] h-3">
              {[0, 1, 2, 3].map(i => (
                <motion.div
                  key={i}
                  className="w-[2px] bg-cent-400 rounded-full"
                  animate={{ height: ['25%', '100%', '25%'] }}
                  transition={{ duration: 0.7, repeat: Infinity, delay: i * 0.12 }}
                />
              ))}
            </div>
          </div>
        )}

        <button
          onClick={(e) => { e.stopPropagation(); toggleFavorite(track.id); }}
          className="absolute top-3 right-3 p-1.5 rounded-full bg-black/30 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-all"
        >
          <Heart className={`w-3.5 h-3.5 ${isFav ? 'fill-cent-400 text-cent-400' : 'text-white/60'}`} />
        </button>
      </div>
      <p className={`text-sm font-semibold truncate ${isActive ? 'text-cent-400' : 'text-white/80'}`}>{track.title}</p>
      <p className="text-[11px] text-white/25 truncate mt-0.5">{track.artist}</p>
    </motion.div>
  );
}
