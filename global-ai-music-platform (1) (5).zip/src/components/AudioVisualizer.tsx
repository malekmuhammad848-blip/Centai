import { useEffect, useRef } from 'react';
import { useStore } from '../store/useStore';

export function AudioVisualizer({ size = 'md', color = '#7a5af8', type = 'bars' }: { size?: 'sm' | 'md' | 'lg'; color?: string; type?: 'bars' | 'circle' | 'wave' }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const isPlaying = useStore(s => s.isPlaying);
  const animRef = useRef<number>(0);
  const barsRef = useRef<number[]>([]);

  const dims = size === 'sm' ? { w: 80, h: 40 } : size === 'md' ? { w: 200, h: 80 } : { w: 300, h: 140 };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Support HiDPI
    const dpr = window.devicePixelRatio || 1;
    canvas.width = dims.w * dpr;
    canvas.height = dims.h * dpr;
    canvas.style.width = dims.w + 'px';
    canvas.style.height = dims.h + 'px';
    ctx.scale(dpr, dpr);

    const barCount = type === 'circle' ? 72 : 40;
    if (barsRef.current.length !== barCount) {
      barsRef.current = Array.from({ length: barCount }, () => Math.random() * 0.3);
    }

    const draw = () => {
      ctx.clearRect(0, 0, dims.w, dims.h);

      if (type === 'bars') {
        const barWidth = dims.w / barCount;
        const gap = 2;
        barsRef.current.forEach((_val, i) => {
          if (isPlaying) {
            barsRef.current[i] += (Math.random() - 0.5) * 0.14;
            barsRef.current[i] = Math.max(0.05, Math.min(1, barsRef.current[i]));
          } else {
            barsRef.current[i] *= 0.94;
            barsRef.current[i] = Math.max(0.03, barsRef.current[i]);
          }
          const h = barsRef.current[i] * dims.h;
          const gradient = ctx.createLinearGradient(0, dims.h - h, 0, dims.h);
          gradient.addColorStop(0, color);
          gradient.addColorStop(1, color + '20');
          ctx.fillStyle = gradient;
          ctx.beginPath();
          ctx.roundRect(i * barWidth + gap / 2, dims.h - h, barWidth - gap, h, 2);
          ctx.fill();
        });
      } else if (type === 'wave') {
        ctx.beginPath();
        const gradient = ctx.createLinearGradient(0, 0, dims.w, 0);
        gradient.addColorStop(0, color + '80');
        gradient.addColorStop(0.5, color);
        gradient.addColorStop(1, color + '80');
        ctx.strokeStyle = gradient;
        ctx.lineWidth = 2;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        barsRef.current.forEach((_val, i) => {
          if (isPlaying) {
            barsRef.current[i] += (Math.random() - 0.5) * 0.08;
            barsRef.current[i] = Math.max(0.1, Math.min(1, barsRef.current[i]));
          } else {
            barsRef.current[i] = 0.5 + Math.sin(i * 0.2) * 0.02;
          }
          const x = (i / barCount) * dims.w;
          const y = dims.h / 2 + (barsRef.current[i] - 0.5) * dims.h * 0.8;
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        });
        ctx.stroke();
      } else if (type === 'circle') {
        const cx = dims.w / 2;
        const cy = dims.h / 2;
        const radius = Math.min(cx, cy) * 0.45;
        barsRef.current.forEach((_val, i) => {
          if (isPlaying) {
            barsRef.current[i] += (Math.random() - 0.5) * 0.1;
            barsRef.current[i] = Math.max(0.1, Math.min(1, barsRef.current[i]));
          } else {
            barsRef.current[i] *= 0.96;
            barsRef.current[i] = Math.max(0.08, barsRef.current[i]);
          }
          const angle = (i / barCount) * Math.PI * 2 - Math.PI / 2;
          const barH = barsRef.current[i] * radius * 0.7;
          const x1 = cx + Math.cos(angle) * radius;
          const y1 = cy + Math.sin(angle) * radius;
          const x2 = cx + Math.cos(angle) * (radius + barH);
          const y2 = cy + Math.sin(angle) * (radius + barH);

          const alpha = Math.floor(barsRef.current[i] * 200 + 55).toString(16).padStart(2, '0');
          ctx.beginPath();
          ctx.strokeStyle = color + alpha;
          ctx.lineWidth = 2.5;
          ctx.lineCap = 'round';
          ctx.moveTo(x1, y1);
          ctx.lineTo(x2, y2);
          ctx.stroke();
        });
      }

      animRef.current = requestAnimationFrame(draw);
    };

    draw();
    return () => cancelAnimationFrame(animRef.current);
  }, [isPlaying, color, type, dims.w, dims.h]);

  return <canvas ref={canvasRef} style={{ width: dims.w, height: dims.h }} className="opacity-90" />;
}
