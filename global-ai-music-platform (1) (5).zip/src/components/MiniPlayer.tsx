import { motion, AnimatePresence } from 'framer-motion';
import { Play, Pause, SkipForward, SkipBack, Heart, X } from 'lucide-react';
import { useStore } from '../store/useStore';
import { useAudio } from '../App';

export function MiniPlayer() {
  const { currentTrack, isPlaying, togglePlay, showMiniPlayer, setShowMiniPlayer, setPage, progress, favorites, toggleFavorite } = useStore();
  const { playNext, playPrev } = useAudio();

  if (!currentTrack || !showMiniPlayer) return null;

  const isFav = favorites.includes(currentTrack.id);

  return (
    <AnimatePresence>
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 100, opacity: 0 }}
        transition={{ type: 'spring', stiffness: 300, damping: 30 }}
        className="fixed bottom-[68px] lg:bottom-0 left-0 lg:left-[260px] right-0 z-40"
      >
        <div className="mx-2 mb-2 lg:mx-3 lg:mb-3">
          <div
            className="glass-strong rounded-2xl overflow-hidden cursor-pointer group hover-glow transition-all relative"
            onClick={() => setPage('player')}
          >
            {/* Track color accent glow */}
            <div
              className="absolute inset-0 opacity-[0.05] transition-opacity group-hover:opacity-[0.1]"
              style={{ background: `radial-gradient(ellipse at 0% 50%, ${currentTrack.color}, transparent 70%)` }}
            />

            {/* Progress bar */}
            <div className="h-[2px] bg-white/[0.04] relative">
              <motion.div
                className="h-full relative"
                style={{
                  width: `${progress}%`,
                  background: `linear-gradient(90deg, ${currentTrack.color}, ${currentTrack.color}cc)`,
                  boxShadow: `0 0 8px ${currentTrack.color}30`,
                }}
              >
                <div
                  className="absolute right-0 top-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-white shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
                />
              </motion.div>
            </div>

            <div className="flex items-center gap-3 p-2.5 sm:p-3 relative">
              {/* Album art */}
              <div className="relative w-11 h-11 sm:w-12 sm:h-12 rounded-xl overflow-hidden flex-shrink-0 shadow-lg">
                <img src={currentTrack.cover} alt={currentTrack.title} className="w-full h-full object-cover" />
                {isPlaying && (
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                    <div className="flex items-end gap-[2px] h-4">
                      {[0, 1, 2, 3].map(i => (
                        <motion.div
                          key={i}
                          className="w-[3px] rounded-full"
                          style={{ background: currentTrack.color }}
                          animate={{ height: ['30%', '100%', '30%'] }}
                          transition={{ duration: 0.7, repeat: Infinity, delay: i * 0.15, ease: 'easeInOut' }}
                        />
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Info */}
              <div className="flex-1 min-w-0">
                <motion.p
                  key={currentTrack.title}
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-xs sm:text-sm font-semibold text-white truncate"
                >
                  {currentTrack.title}
                </motion.p>
                <p className="text-[10px] sm:text-xs text-white/30 truncate">{currentTrack.artist}</p>
              </div>

              {/* Controls */}
              <div className="flex items-center gap-0.5 sm:gap-1" onClick={(e) => e.stopPropagation()}>
                <motion.button
                  whileTap={{ scale: 0.85 }}
                  onClick={() => toggleFavorite(currentTrack.id)}
                  className="p-1.5 sm:p-2 rounded-full hover:bg-white/5 transition"
                >
                  <Heart className={`w-4 h-4 transition-colors ${isFav ? 'fill-cent-400 text-cent-400' : 'text-white/25'}`} />
                </motion.button>
                <button onClick={playPrev} className="p-1.5 sm:p-2 rounded-full hover:bg-white/5 transition hidden sm:block">
                  <SkipBack className="w-4 h-4 text-white/35" />
                </button>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={togglePlay}
                  className="w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center shadow-lg"
                  style={{ 
                    background: `linear-gradient(135deg, ${currentTrack.color}, ${currentTrack.color}bb)`,
                    boxShadow: `0 4px 15px ${currentTrack.color}30`,
                  }}
                >
                  {isPlaying ? <Pause className="w-4 h-4 text-white" /> : <Play className="w-4 h-4 text-white ml-0.5" />}
                </motion.button>
                <button onClick={playNext} className="p-1.5 sm:p-2 rounded-full hover:bg-white/5 transition">
                  <SkipForward className="w-4 h-4 text-white/35" />
                </button>
                <button
                  onClick={(e) => { e.stopPropagation(); setShowMiniPlayer(false); }}
                  className="p-1.5 sm:p-2 rounded-full hover:bg-white/5 transition lg:hidden"
                >
                  <X className="w-4 h-4 text-white/15" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
