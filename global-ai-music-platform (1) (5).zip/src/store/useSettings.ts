import { create } from 'zustand';
import { type Language, RTL_LANGUAGES } from '../i18n/translations';

interface SettingsState {
  language: Language;
  setLanguage: (lang: Language) => void;
  audioQuality: string;
  setAudioQuality: (q: string) => void;
  downloadQuality: string;
  setDownloadQuality: (q: string) => void;
  spatialAudio: boolean;
  toggleSpatialAudio: () => void;
  autoPlay: boolean;
  toggleAutoPlay: () => void;
  crossfade: boolean;
  toggleCrossfade: () => void;
  normalizeVolume: boolean;
  toggleNormalizeVolume: () => void;
  offlineMode: boolean;
  toggleOfflineMode: () => void;
  wifiOnly: boolean;
  toggleWifiOnly: () => void;
  showLyrics: boolean;
  toggleShowLyrics: () => void;
  notifications: boolean;
  toggleNotifications: () => void;
  storageLimit: string;
  setStorageLimit: (s: string) => void;
  isRTL: () => boolean;
}

const loadSetting = <T>(key: string, fallback: T): T => {
  try {
    const stored = localStorage.getItem(`cent_${key}`);
    if (stored !== null) return JSON.parse(stored);
  } catch { /* ignore */ }
  return fallback;
};

const saveSetting = (key: string, value: unknown) => {
  try {
    localStorage.setItem(`cent_${key}`, JSON.stringify(value));
  } catch { /* ignore */ }
};

export const useSettings = create<SettingsState>((set, get) => ({
  language: loadSetting<Language>('language', 'en'),
  setLanguage: (lang) => {
    saveSetting('language', lang);
    // Apply RTL
    if (RTL_LANGUAGES.includes(lang)) {
      document.documentElement.dir = 'rtl';
      document.documentElement.lang = lang;
    } else {
      document.documentElement.dir = 'ltr';
      document.documentElement.lang = lang;
    }
    set({ language: lang });
  },

  audioQuality: loadSetting('audioQuality', 'High (320kbps)'),
  setAudioQuality: (q) => { saveSetting('audioQuality', q); set({ audioQuality: q }); },

  downloadQuality: loadSetting('downloadQuality', 'Very High (FLAC)'),
  setDownloadQuality: (q) => { saveSetting('downloadQuality', q); set({ downloadQuality: q }); },

  spatialAudio: loadSetting('spatialAudio', true),
  toggleSpatialAudio: () => { const v = !get().spatialAudio; saveSetting('spatialAudio', v); set({ spatialAudio: v }); },

  autoPlay: loadSetting('autoPlay', true),
  toggleAutoPlay: () => { const v = !get().autoPlay; saveSetting('autoPlay', v); set({ autoPlay: v }); },

  crossfade: loadSetting('crossfade', true),
  toggleCrossfade: () => { const v = !get().crossfade; saveSetting('crossfade', v); set({ crossfade: v }); },

  normalizeVolume: loadSetting('normalizeVolume', false),
  toggleNormalizeVolume: () => { const v = !get().normalizeVolume; saveSetting('normalizeVolume', v); set({ normalizeVolume: v }); },

  offlineMode: loadSetting('offlineMode', false),
  toggleOfflineMode: () => { const v = !get().offlineMode; saveSetting('offlineMode', v); set({ offlineMode: v }); },

  wifiOnly: loadSetting('wifiOnly', true),
  toggleWifiOnly: () => { const v = !get().wifiOnly; saveSetting('wifiOnly', v); set({ wifiOnly: v }); },

  showLyrics: loadSetting('showLyrics', true),
  toggleShowLyrics: () => { const v = !get().showLyrics; saveSetting('showLyrics', v); set({ showLyrics: v }); },

  notifications: loadSetting('notifications', true),
  toggleNotifications: () => { const v = !get().notifications; saveSetting('notifications', v); set({ notifications: v }); },

  storageLimit: loadSetting('storageLimit', '10 GB'),
  setStorageLimit: (s) => { saveSetting('storageLimit', s); set({ storageLimit: s }); },

  isRTL: () => RTL_LANGUAGES.includes(get().language),
}));
