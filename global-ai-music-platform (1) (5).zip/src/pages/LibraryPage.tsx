import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, Clock, Download, ListMusic, Plus, Music, TrendingUp, Headphones, BarChart3, Calendar, Star, Shuffle, Play, MoreHorizontal, Search } from 'lucide-react';
import { TRACKS, PLAYLISTS, formatNumber, formatDuration } from '../data/mock';
import { TrackCard } from '../components/TrackCard';
import { useStore } from '../store/useStore';

type Tab = 'playlists' | 'favorites' | 'history' | 'downloads' | 'stats';

export function LibraryPage() {
  const [activeTab, setActiveTab] = useState<Tab>('playlists');
  const [_searchQuery, _setSearchQuery] = useState('');
  const { favorites, setSelectedPlaylist, setPage, setCurrentTrack, setIsPlaying, setQueue } = useStore();

  const favTracks = TRACKS.filter(t => favorites.includes(t.id));

  // Simulated history with timestamps
  const historyItems = TRACKS.slice(0, 10).map((track, i) => ({
    ...track,
    playedAt: i === 0 ? 'Now' : i < 3 ? `${i * 12}m ago` : i < 6 ? `${i}h ago` : `${i - 4}d ago`,
    listenedPct: 100 - i * 8,
  }));

  const TABS: { id: Tab; label: string; icon: typeof Heart; count?: number }[] = [
    { id: 'playlists', label: 'Playlists', icon: ListMusic, count: PLAYLISTS.length + 1 },
    { id: 'favorites', label: 'Favorites', icon: Heart, count: favTracks.length },
    { id: 'history', label: 'History', icon: Clock },
    { id: 'downloads', label: 'Downloads', icon: Download, count: 3 },
    { id: 'stats', label: 'Stats', icon: BarChart3 },
  ];

  const playAllFavorites = () => {
    if (favTracks.length > 0) {
      setQueue(favTracks);
      setCurrentTrack(favTracks[0]);
      setIsPlaying(true);
    }
  };

  return (
    <div className="space-y-8">
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
        <div className="flex items-center justify-between mb-2">
          <div>
            <h1 className="text-3xl font-display font-bold text-white">Your Library</h1>
            <p className="text-white/30 text-sm mt-1">Your music, organized and personalized</p>
          </div>
          <div className="flex items-center gap-2">
            <button className="p-2 rounded-xl glass text-white/30 hover:text-white/60 transition">
              <Search className="w-5 h-5" />
            </button>
            <button className="p-2 rounded-xl glass text-white/30 hover:text-white/60 transition">
              <Plus className="w-5 h-5" />
            </button>
          </div>
        </div>
      </motion.div>

      {/* Quick Stats Bar */}
      <div className="glass rounded-2xl p-4 flex items-center justify-around">
        <div className="text-center">
          <p className="text-xl font-bold text-white">{favTracks.length}</p>
          <p className="text-[9px] text-white/25 uppercase">Liked</p>
        </div>
        <div className="w-px h-8 bg-white/5" />
        <div className="text-center">
          <p className="text-xl font-bold text-white">{PLAYLISTS.length}</p>
          <p className="text-[9px] text-white/25 uppercase">Playlists</p>
        </div>
        <div className="w-px h-8 bg-white/5" />
        <div className="text-center">
          <p className="text-xl font-bold text-white">342h</p>
          <p className="text-[9px] text-white/25 uppercase">Listened</p>
        </div>
        <div className="w-px h-8 bg-white/5 hidden sm:block" />
        <div className="text-center hidden sm:block">
          <p className="text-xl font-bold text-white">3</p>
          <p className="text-[9px] text-white/25 uppercase">Downloaded</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
        {TABS.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
              activeTab === tab.id ? 'bg-cent-500 text-white shadow-lg shadow-cent-500/20' : 'bg-white/5 text-white/40 hover:text-white/60'
            }`}>
            <tab.icon className="w-4 h-4" />
            {tab.label}
            {tab.count !== undefined && <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-white/10">{tab.count}</span>}
          </button>
        ))}
      </div>

      {/* Content */}
      <AnimatePresence mode="wait">
        <motion.div key={activeTab} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>

          {activeTab === 'playlists' && (
            <div className="space-y-6">
              {/* Create Playlist */}
              <motion.button whileHover={{ scale: 1.01 }} className="w-full flex items-center gap-4 p-4 rounded-2xl glass hover:bg-white/[0.06] transition-all group">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-cent-400 to-cent-600 flex items-center justify-center shadow-lg shadow-cent-500/20 group-hover:shadow-cent-500/30 transition-shadow">
                  <Plus className="w-6 h-6 text-white" />
                </div>
                <div className="text-left">
                  <p className="text-sm font-semibold text-white">Create New Playlist</p>
                  <p className="text-[10px] text-white/30">Start a new music collection</p>
                </div>
              </motion.button>

              {/* Liked Songs Card */}
              <motion.div whileHover={{ scale: 1.01 }} onClick={playAllFavorites}
                className="flex items-center gap-4 p-4 rounded-2xl overflow-hidden cursor-pointer group relative">
                <div className="absolute inset-0 bg-gradient-to-r from-pink-600/15 via-rose-600/10 to-transparent" />
                <div className="absolute inset-0 glass" />
                <div className="relative w-14 h-14 rounded-xl bg-gradient-to-br from-pink-500 to-rose-600 flex items-center justify-center shadow-lg shadow-pink-500/20">
                  <Heart className="w-6 h-6 text-white fill-white" />
                </div>
                <div className="relative flex-1">
                  <p className="text-sm font-semibold text-white">Liked Songs</p>
                  <p className="text-[10px] text-white/30">{favTracks.length} songs · {favTracks.length > 0 ? `${formatDuration(favTracks.reduce((a, t) => a + t.duration, 0))} total` : 'Add songs you love'}</p>
                </div>
                <div className="relative flex items-center gap-2">
                  <button className="p-2 rounded-full hover:bg-white/10 transition opacity-0 group-hover:opacity-100"><Shuffle className="w-4 h-4 text-white/40" /></button>
                  <div className="w-10 h-10 rounded-full bg-pink-500 flex items-center justify-center shadow-lg shadow-pink-500/30 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Play className="w-4 h-4 text-white fill-white ml-0.5" />
                  </div>
                </div>
              </motion.div>

              {/* Playlists Grid */}
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {PLAYLISTS.map((pl, i) => (
                  <motion.div key={pl.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }}
                    whileHover={{ y: -4 }} className="cursor-pointer group" onClick={() => { setSelectedPlaylist(pl); setPage('playlist'); }}>
                    <div className={`aspect-square rounded-2xl overflow-hidden mb-3 bg-gradient-to-br ${pl.gradient} p-4 flex flex-col justify-end shadow-lg relative`}>
                      <img src={pl.cover} alt="" className="absolute inset-0 w-full h-full object-cover opacity-30 mix-blend-overlay" />
                      <motion.div className="absolute bottom-3 right-3 w-11 h-11 rounded-full bg-white shadow-xl flex items-center justify-center opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition-all duration-300">
                        <Play className="w-4 h-4 text-black fill-black ml-0.5" />
                      </motion.div>
                      <p className="relative text-base font-bold text-white drop-shadow-lg">{pl.name}</p>
                      <p className="relative text-[10px] text-white/60">{pl.trackCount} tracks</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'favorites' && (
            <div>
              {favTracks.length > 0 ? (
                <div className="space-y-1">
                  <div className="flex items-center justify-between mb-4">
                    <p className="text-sm text-white/40">{favTracks.length} liked songs</p>
                    <div className="flex gap-2">
                      <button onClick={playAllFavorites} className="flex items-center gap-2 px-4 py-2 rounded-full bg-cent-500 text-white text-xs font-bold shadow-lg shadow-cent-500/20">
                        <Play className="w-3.5 h-3.5 fill-white" /> Play All
                      </button>
                      <button className="p-2 rounded-full glass text-white/30"><Shuffle className="w-4 h-4" /></button>
                    </div>
                  </div>
                  {favTracks.map((track, i) => (<TrackCard key={track.id} track={track} index={i} variant="list" />))}
                </div>
              ) : (
                <div className="text-center py-20">
                  <Heart className="w-16 h-16 text-white/10 mx-auto mb-4" />
                  <p className="text-white/40 mb-2 text-lg">No favorites yet</p>
                  <p className="text-white/20 text-sm mb-6">Tap the ♡ icon on any track to save it here</p>
                  <button onClick={() => setPage('explore')} className="px-6 py-2.5 rounded-full bg-cent-500 text-white text-sm font-semibold shadow-lg shadow-cent-500/20">
                    Discover Music
                  </button>
                </div>
              )}
            </div>
          )}

          {activeTab === 'history' && (
            <div className="space-y-1">
              <div className="flex items-center justify-between mb-4">
                <p className="text-sm text-white/40">Recently played</p>
                <button className="text-xs text-cent-400 font-medium">Clear History</button>
              </div>
              {historyItems.map((track, i) => (
                <motion.div key={track.id + i} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.04 }}
                  className="flex items-center gap-4 p-3 rounded-xl group cursor-pointer hover:bg-white/[0.02] transition-all"
                  onClick={() => { setCurrentTrack(track); setIsPlaying(true); }}>
                  <div className="relative w-11 h-11 rounded-lg overflow-hidden flex-shrink-0 shadow-md">
                    <img src={track.cover} alt="" className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <Play className="w-4 h-4 text-white fill-white ml-0.5" />
                    </div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white/80 truncate">{track.title}</p>
                    <p className="text-[10px] text-white/25">{track.artist}</p>
                  </div>
                  <div className="text-right hidden sm:block">
                    <p className="text-[10px] text-white/15 font-mono">{track.playedAt}</p>
                    <div className="w-16 h-1 bg-white/5 rounded-full mt-1">
                      <div className="h-full bg-cent-400/30 rounded-full" style={{ width: `${track.listenedPct}%` }} />
                    </div>
                  </div>
                  <button className="opacity-0 group-hover:opacity-100 transition-opacity p-1"><MoreHorizontal className="w-4 h-4 text-white/15" /></button>
                </motion.div>
              ))}
            </div>
          )}

          {activeTab === 'downloads' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm text-white/40">3 songs downloaded · 48 MB</p>
              </div>
              {TRACKS.slice(0, 3).map((track, i) => (
                <motion.div key={track.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}
                  className="flex items-center gap-4 p-4 rounded-2xl glass group cursor-pointer" onClick={() => { setCurrentTrack(track); setIsPlaying(true); }}>
                  <div className="relative w-14 h-14 rounded-xl overflow-hidden flex-shrink-0 shadow-lg">
                    <img src={track.cover} alt="" className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <Play className="w-5 h-5 text-white fill-white ml-0.5" />
                    </div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-white">{track.title}</p>
                    <p className="text-xs text-white/30">{track.artist} · {track.album}</p>
                    <div className="flex items-center gap-3 mt-1">
                      <span className="text-[10px] text-emerald-400/60 flex items-center gap-1"><Download className="w-3 h-3" /> Downloaded</span>
                      <span className="text-[10px] text-white/15">{formatDuration(track.duration)} · 16 MB</span>
                    </div>
                  </div>
                  <span className="text-[10px] px-2 py-1 rounded-full bg-emerald-500/10 text-emerald-400/70">FLAC</span>
                </motion.div>
              ))}

              <div className="text-center pt-8">
                <Download className="w-10 h-10 text-white/10 mx-auto mb-3" />
                <p className="text-sm text-white/30">Download more for offline listening</p>
                <button onClick={() => setPage('explore')} className="mt-3 px-6 py-2.5 rounded-full bg-cent-500 text-white text-sm font-semibold shadow-lg shadow-cent-500/20">
                  Browse Music
                </button>
              </div>
            </div>
          )}

          {activeTab === 'stats' && (
            <div className="space-y-6">
              {/* Overview Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { label: 'Total Plays', value: '12,847', icon: Music, color: '#7a5af8' },
                  { label: 'Listening Time', value: '342h', icon: Headphones, color: '#ec4899' },
                  { label: 'Liked Songs', value: String(favTracks.length), icon: Heart, color: '#ef4444' },
                  { label: 'This Week', value: '28h', icon: Calendar, color: '#10b981' },
                ].map((stat, i) => (
                  <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }} className="glass rounded-2xl p-5 text-center">
                    <stat.icon className="w-6 h-6 mx-auto mb-3" style={{ color: stat.color }} />
                    <p className="text-2xl font-bold text-white">{stat.value}</p>
                    <p className="text-[10px] text-white/30 mt-1">{stat.label}</p>
                  </motion.div>
                ))}
              </div>

              {/* Top Genres */}
              <div className="glass rounded-2xl p-6">
                <h3 className="text-sm font-semibold text-white/60 mb-4 uppercase tracking-wider flex items-center gap-2">
                  <Star className="w-4 h-4 text-cent-400" /> Top Genres
                </h3>
                <div className="space-y-3">
                  {[
                    { name: 'Electronic', pct: 42, plays: '5.4K', color: '#7a5af8' },
                    { name: 'Ambient', pct: 28, plays: '3.6K', color: '#3b82f6' },
                    { name: 'Synthwave', pct: 18, plays: '2.3K', color: '#ec4899' },
                    { name: 'Lo-fi', pct: 12, plays: '1.5K', color: '#10b981' },
                  ].map(g => (
                    <div key={g.name}>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-white/60">{g.name}</span>
                        <div className="flex items-center gap-3">
                          <span className="text-[10px] text-white/20 font-mono">{g.plays} plays</span>
                          <span className="text-white/30 font-mono text-xs">{g.pct}%</span>
                        </div>
                      </div>
                      <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                        <motion.div initial={{ width: 0 }} animate={{ width: `${g.pct}%` }} transition={{ duration: 1, delay: 0.3 }}
                          className="h-full rounded-full" style={{ background: g.color }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Top Artists */}
              <div className="glass rounded-2xl p-6">
                <h3 className="text-sm font-semibold text-white/60 mb-4 uppercase tracking-wider flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-cent-400" /> Your Top Artists
                </h3>
                <div className="space-y-3">
                  {TRACKS.slice(0, 5).map((track, i) => (
                    <div key={track.id} className="flex items-center gap-3">
                      <span className={`text-sm font-bold w-6 text-center ${i === 0 ? 'text-yellow-400' : i === 1 ? 'text-gray-400' : i === 2 ? 'text-amber-600' : 'text-white/15'}`}>
                        {i + 1}
                      </span>
                      <div className="w-8 h-8 rounded-full overflow-hidden">
                        <img src={track.cover} alt="" className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-white/70">{track.artist}</p>
                        <p className="text-[10px] text-white/20">{formatNumber(track.plays)} plays</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Listening Activity */}
              <div className="glass rounded-2xl p-6">
                <h3 className="text-sm font-semibold text-white/60 mb-4 uppercase tracking-wider">Weekly Activity</h3>
                <div className="flex items-end justify-between gap-2 h-24">
                  {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, i) => {
                    const heights = [45, 72, 55, 88, 62, 95, 78];
                    return (
                      <div key={day} className="flex-1 flex flex-col items-center gap-2">
                        <motion.div initial={{ height: 0 }} animate={{ height: `${heights[i]}%` }} transition={{ delay: i * 0.08, duration: 0.5 }}
                          className="w-full rounded-t-md" style={{ background: `linear-gradient(to top, rgba(122,90,248,0.2), rgba(122,90,248,0.8))` }} />
                        <span className="text-[8px] text-white/20">{day}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
