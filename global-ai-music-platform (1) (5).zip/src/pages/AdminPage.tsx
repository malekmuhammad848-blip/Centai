import { useState } from 'react';
import { motion } from 'framer-motion';
import { BarChart3, Users, Music, Disc3, Upload, Shield, TrendingUp, DollarSign, Activity, AlertTriangle, Eye, Play, Heart, Download, Plus, Search, Filter, MoreHorizontal, ChevronRight, CheckCircle2, XCircle, Clock, Globe, Headphones, Zap, Server, Database, Cpu, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { TRACKS, ARTISTS, formatNumber } from '../data/mock';

type AdminTab = 'overview' | 'music' | 'users' | 'artists' | 'analytics' | 'moderation';

function StatCard({ icon: Icon, label, value, change, color, subtitle }: { icon: typeof Users; label: string; value: string; change: string; color: string; subtitle?: string }) {
  const isPositive = change.startsWith('+');
  return (
    <motion.div whileHover={{ y: -3 }} className="glass rounded-2xl p-5 relative overflow-hidden group">
      <div className="absolute -top-6 -right-6 w-20 h-20 rounded-full opacity-5 group-hover:opacity-10 transition-opacity" style={{ background: color }} />
      <div className="flex items-start justify-between mb-4">
        <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: color + '12' }}>
          <Icon className="w-5 h-5" style={{ color }} />
        </div>
        <span className={`text-xs font-semibold px-2 py-1 rounded-full flex items-center gap-0.5 ${isPositive ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'}`}>
          {isPositive ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
          {change}
        </span>
      </div>
      <p className="text-2xl font-bold text-white">{value}</p>
      <p className="text-xs text-white/40 mt-1">{label}</p>
      {subtitle && <p className="text-[10px] text-white/20 mt-0.5">{subtitle}</p>}
    </motion.div>
  );
}

function MiniChart({ data, color, height = 48 }: { data: number[]; color: string; height?: number }) {
  const max = Math.max(...data);
  return (
    <div className="flex items-end gap-[2px]" style={{ height }}>
      {data.map((v, i) => (
        <motion.div key={i} initial={{ height: 0 }} animate={{ height: `${(v / max) * 100}%` }} transition={{ delay: i * 0.03, duration: 0.5 }}
          className="flex-1 rounded-t-sm min-w-[3px]" style={{ background: `linear-gradient(to top, ${color}30, ${color})` }} />
      ))}
    </div>
  );
}

function LiveCounter({ value, label }: { value: string; label: string }) {
  return (
    <div className="text-center">
      <div className="flex items-center justify-center gap-1 mb-1">
        <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
        <span className="text-lg font-bold text-white font-mono">{value}</span>
      </div>
      <p className="text-[9px] text-white/25 uppercase tracking-wider">{label}</p>
    </div>
  );
}

export function AdminPage() {
  const [activeTab, setActiveTab] = useState<AdminTab>('overview');
  const [searchQuery, setSearchQuery] = useState('');

  const ADMIN_TABS: { id: AdminTab; label: string; icon: typeof BarChart3 }[] = [
    { id: 'overview', label: 'Overview', icon: BarChart3 },
    { id: 'music', label: 'Music', icon: Music },
    { id: 'users', label: 'Users', icon: Users },
    { id: 'artists', label: 'Artists', icon: Disc3 },
    { id: 'analytics', label: 'Analytics', icon: TrendingUp },
    { id: 'moderation', label: 'Moderation', icon: Shield },
  ];

  const dailyData = [42, 68, 55, 82, 58, 93, 72, 88, 95, 63, 77, 91, 85, 79, 88, 93, 75, 98, 82, 91, 86, 94, 78, 97];
  const revenueData = [320, 450, 380, 520, 490, 610, 580, 720, 680, 810, 790, 920];
  const streamData = [45, 52, 48, 65, 58, 72, 68, 85, 78, 92, 88, 105, 98, 115, 108, 125];

  const recentUsers = [
    { name: 'Sarah Chen', email: 'sarah.c@gmail.com', plan: 'Premium', joined: '2m ago', country: '🇺🇸', streams: '2.4K' },
    { name: 'محمد العلي', email: 'moh@outlook.com', plan: 'Premium', joined: '8m ago', country: '🇸🇦', streams: '5.1K' },
    { name: 'Alex Rivera', email: 'alex.r@yahoo.com', plan: 'Free', joined: '15m ago', country: '🇲🇽', streams: '890' },
    { name: 'Yuki Tanaka', email: 'yuki.t@icloud.com', plan: 'Premium', joined: '32m ago', country: '🇯🇵', streams: '3.7K' },
    { name: 'Emma Wilson', email: 'emma.w@gmail.com', plan: 'Artist', joined: '1h ago', country: '🇬🇧', streams: '12.3K' },
    { name: 'Park Min-jun', email: 'mjpark@naver.com', plan: 'Free', joined: '2h ago', country: '🇰🇷', streams: '1.2K' },
  ];

  const recentActivity = [
    { action: 'New Premium subscription', detail: 'sarah.c@gmail.com — $9.99/mo', time: '2m ago', icon: DollarSign, color: '#10b981' },
    { action: 'Track uploaded', detail: '"Midnight Dreams" by AURORA — Verified', time: '5m ago', icon: Upload, color: '#3b82f6' },
    { action: 'Copyright claim filed', detail: 'Track #8847 — Universal Music Group', time: '12m ago', icon: AlertTriangle, color: '#f59e0b' },
    { action: 'Artist verified', detail: 'NOVA — 23.1M followers — Badge issued', time: '18m ago', icon: CheckCircle2, color: '#06b6d4' },
    { action: 'Payment processed', detail: '$12,847.00 — Artist royalties batch', time: '25m ago', icon: DollarSign, color: '#10b981' },
    { action: 'New user milestone', detail: '50,000,000th user registered! 🎉', time: '1h ago', icon: Users, color: '#7a5af8' },
    { action: 'Server scale-up', detail: 'Auto-scaled to 48 pods — Traffic surge', time: '2h ago', icon: Server, color: '#ef4444' },
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-cent-400 to-cent-600 flex items-center justify-center shadow-lg shadow-cent-500/25">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-display font-bold text-white">Admin Dashboard</h1>
              <p className="text-[10px] text-white/30">CENT Platform Management — Real-time</p>
            </div>
          </div>
          <div className="hidden sm:flex items-center gap-2">
            <div className="flex items-center gap-2 px-3 py-2 rounded-full glass text-xs text-white/30">
              <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              All Systems Operational
            </div>
          </div>
        </div>
      </motion.div>

      {/* Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
        {ADMIN_TABS.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium whitespace-nowrap transition-all ${
              activeTab === tab.id ? 'bg-cent-500 text-white shadow-lg shadow-cent-500/20' : 'bg-white/5 text-white/40 hover:text-white/70'
            }`}>
            <tab.icon className="w-4 h-4" /> {tab.label}
          </button>
        ))}
      </div>

      <motion.div key={activeTab} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Live Counters */}
            <div className="glass-premium rounded-2xl p-5 flex items-center justify-around">
              <LiveCounter value="142,847" label="Active Now" />
              <div className="w-px h-8 bg-white/5" />
              <LiveCounter value="2,847" label="Streams/sec" />
              <div className="w-px h-8 bg-white/5 hidden sm:block" />
              <div className="hidden sm:block"><LiveCounter value="23ms" label="Avg Latency" /></div>
              <div className="w-px h-8 bg-white/5 hidden md:block" />
              <div className="hidden md:block"><LiveCounter value="99.99%" label="Uptime" /></div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <StatCard icon={Users} label="Total Users" value="50.2M" change="+12.5%" color="#7a5af8" subtitle="2.4M new this month" />
              <StatCard icon={Music} label="Total Tracks" value="104.7M" change="+3.8%" color="#3b82f6" subtitle="847K uploaded this month" />
              <StatCard icon={DollarSign} label="Revenue (MRR)" value="$4.2M" change="+23.1%" color="#10b981" subtitle="$1.2M from subscriptions" />
              <StatCard icon={Activity} label="Daily Streams" value="42.8M" change="+15.7%" color="#f59e0b" subtitle="Peak: 3.2M/hour" />
            </div>

            {/* Charts */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="glass rounded-2xl p-5">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-semibold text-white">Daily Active Users</h3>
                  <span className="text-[10px] text-cent-400 font-mono">24h</span>
                </div>
                <MiniChart data={dailyData} color="#7a5af8" height={56} />
              </div>
              <div className="glass rounded-2xl p-5">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-semibold text-white">Revenue</h3>
                  <span className="text-[10px] text-emerald-400 font-mono">12mo</span>
                </div>
                <MiniChart data={revenueData} color="#10b981" height={56} />
              </div>
              <div className="glass rounded-2xl p-5">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-semibold text-white">Streams</h3>
                  <span className="text-[10px] text-blue-400 font-mono">16w</span>
                </div>
                <MiniChart data={streamData} color="#3b82f6" height={56} />
              </div>
            </div>

            {/* Activity Feed */}
            <div className="glass rounded-2xl overflow-hidden">
              <div className="p-4 border-b border-white/5 flex items-center justify-between">
                <h3 className="text-sm font-semibold text-white">Real-time Activity</h3>
                <div className="flex items-center gap-1"><div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /><span className="text-[10px] text-white/20">LIVE</span></div>
              </div>
              <div className="divide-y divide-white/[0.03]">
                {recentActivity.map((item, i) => (
                  <motion.div key={i} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }}
                    className="flex items-center gap-3 p-4 hover:bg-white/[0.02] transition-colors">
                    <div className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: item.color + '15' }}>
                      <item.icon className="w-4 h-4" style={{ color: item.color }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-white font-medium">{item.action}</p>
                      <p className="text-[10px] text-white/25 truncate">{item.detail}</p>
                    </div>
                    <span className="text-[10px] text-white/15 flex-shrink-0">{item.time}</span>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Infrastructure */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { label: 'API Latency', value: '23ms', icon: Zap, status: 'healthy' },
                { label: 'CDN Hit Rate', value: '99.7%', icon: Globe, status: 'healthy' },
                { label: 'DB Pool', value: '847/2000', icon: Database, status: 'healthy' },
                { label: 'CPU Usage', value: '42%', icon: Cpu, status: 'healthy' },
              ].map(item => (
                <div key={item.label} className="glass rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <div className={`w-2 h-2 rounded-full ${item.status === 'healthy' ? 'bg-emerald-400' : 'bg-yellow-400'} animate-pulse`} />
                    <item.icon className="w-3.5 h-3.5 text-white/20" />
                    <span className="text-[10px] text-white/30">{item.label}</span>
                  </div>
                  <p className="text-lg font-bold text-white font-mono">{item.value}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'music' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row gap-3">
              <button className="flex items-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-cent-400 to-cent-600 text-white font-semibold text-sm shadow-lg shadow-cent-500/20">
                <Upload className="w-4 h-4" /> Upload Track
              </button>
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
                <input value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder="Search tracks..."
                  className="w-full pl-10 pr-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white text-sm placeholder:text-white/30 focus:outline-none focus:border-cent-400/50" />
              </div>
              <button className="flex items-center gap-2 px-4 py-3 rounded-xl glass text-white/50 text-sm"><Filter className="w-4 h-4" /> Filter</button>
            </div>

            <div className="glass rounded-2xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full min-w-[700px]">
                  <thead>
                    <tr className="border-b border-white/5">
                      <th className="text-left py-3 px-4 text-xs text-white/30 font-medium">Track</th>
                      <th className="text-left py-3 px-4 text-xs text-white/30 font-medium">Artist</th>
                      <th className="text-left py-3 px-4 text-xs text-white/30 font-medium">Genre</th>
                      <th className="text-right py-3 px-4 text-xs text-white/30 font-medium">Streams</th>
                      <th className="text-right py-3 px-4 text-xs text-white/30 font-medium">Revenue</th>
                      <th className="text-right py-3 px-4 text-xs text-white/30 font-medium">Status</th>
                      <th className="text-right py-3 px-4 text-xs text-white/30 font-medium"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {TRACKS.map((track, i) => (
                      <motion.tr key={track.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.03 }}
                        className="border-b border-white/[0.03] hover:bg-white/[0.02] transition-colors">
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-3">
                            <img src={track.cover} alt="" className="w-10 h-10 rounded-lg object-cover shadow-md" />
                            <div><p className="text-sm text-white font-medium">{track.title}</p><p className="text-[10px] text-white/25">{track.album}</p></div>
                          </div>
                        </td>
                        <td className="py-3 px-4 text-sm text-white/50">{track.artist}</td>
                        <td className="py-3 px-4"><span className="text-[10px] px-2 py-1 rounded-full bg-white/5 text-white/40">{track.genre}</span></td>
                        <td className="py-3 px-4 text-sm text-white/40 text-right font-mono">{formatNumber(track.plays)}</td>
                        <td className="py-3 px-4 text-sm text-emerald-400/70 text-right font-mono">${(track.plays * 0.004).toFixed(0)}</td>
                        <td className="py-3 px-4 text-right"><span className="text-[10px] px-2 py-1 rounded-full bg-emerald-500/10 text-emerald-400">Active</span></td>
                        <td className="py-3 px-4 text-right"><button className="p-1 rounded hover:bg-white/10 transition"><MoreHorizontal className="w-4 h-4 text-white/25" /></button></td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'users' && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <StatCard icon={Users} label="Total Users" value="50,247,102" change="+12.5%" color="#7a5af8" />
              <StatCard icon={Activity} label="Active Today" value="2,847,293" change="+5.2%" color="#3b82f6" />
              <StatCard icon={DollarSign} label="Premium" value="18,293,847" change="+18.7%" color="#10b981" subtitle="36.4% conversion" />
              <StatCard icon={Eye} label="Avg. Session" value="42 min" change="+3.1%" color="#f59e0b" />
            </div>

            <div className="glass rounded-2xl overflow-hidden">
              <div className="p-4 border-b border-white/5 flex items-center justify-between">
                <h3 className="text-sm font-semibold text-white">Recent Users</h3>
                <button className="text-xs text-cent-400 flex items-center gap-1">View All <ChevronRight className="w-3 h-3" /></button>
              </div>
              <div className="divide-y divide-white/[0.03]">
                {recentUsers.map((user, i) => (
                  <motion.div key={i} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.04 }}
                    className="flex items-center gap-4 p-4 hover:bg-white/[0.02] transition-colors">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cent-400/30 to-cent-600/30 flex items-center justify-center text-white font-bold text-sm border border-white/10">
                      {user.name.charAt(0)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="text-sm text-white font-medium">{user.name}</p>
                        <span className="text-xs">{user.country}</span>
                      </div>
                      <p className="text-[10px] text-white/25">{user.email}</p>
                    </div>
                    <span className={`text-[10px] px-2 py-1 rounded-full hidden sm:block ${
                      user.plan === 'Premium' ? 'bg-cent-500/10 text-cent-400' : user.plan === 'Artist' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-white/5 text-white/30'
                    }`}>{user.plan}</span>
                    <span className="text-[10px] text-white/15 hidden sm:block font-mono">{user.streams} streams</span>
                    <span className="text-[10px] text-white/15">{user.joined}</span>
                    <div className="w-2 h-2 rounded-full bg-emerald-400" />
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'artists' && (
          <div className="space-y-6">
            <div className="flex gap-3">
              <button className="flex items-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-cent-400 to-cent-600 text-white font-semibold text-sm"><Plus className="w-4 h-4" /> Add Artist</button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {ARTISTS.map((artist, i) => (
                <motion.div key={artist.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }} className="glass rounded-2xl p-5 flex items-center gap-4">
                  <div className="w-16 h-16 rounded-full overflow-hidden flex-shrink-0 ring-2 ring-white/5"><img src={artist.image} alt={artist.name} className="w-full h-full object-cover" /></div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2"><p className="text-base font-semibold text-white">{artist.name}</p>{artist.verified && <CheckCircle2 className="w-4 h-4 text-blue-400" />}</div>
                    <p className="text-xs text-white/30">{artist.genre} · {formatNumber(artist.followers)} followers</p>
                    <div className="flex gap-4 mt-2">
                      <span className="text-[10px] text-white/15 flex items-center gap-1"><Play className="w-3 h-3" /> {formatNumber(artist.followers * 3)} streams</span>
                      <span className="text-[10px] text-emerald-400/50 flex items-center gap-1"><DollarSign className="w-3 h-3" /> ${formatNumber(artist.followers * 0.01)}</span>
                    </div>
                  </div>
                  <button className="p-2 rounded-lg hover:bg-white/10 transition"><MoreHorizontal className="w-4 h-4 text-white/25" /></button>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'analytics' && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <StatCard icon={Play} label="Total Streams" value="1.2B" change="+15.3%" color="#7a5af8" />
              <StatCard icon={Download} label="Downloads" value="42.8M" change="+8.1%" color="#3b82f6" />
              <StatCard icon={Heart} label="Likes" value="891M" change="+22.4%" color="#ec4899" />
              <StatCard icon={Headphones} label="Hours Listened" value="2.1B" change="+11.6%" color="#f59e0b" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="glass rounded-2xl p-5">
                <h3 className="text-sm font-semibold text-white mb-4">Streams by Region</h3>
                <div className="space-y-3">
                  {[{ r: 'North America', p: 35, c: '#7a5af8' }, { r: 'Europe', p: 28, c: '#3b82f6' }, { r: 'Asia Pacific', p: 22, c: '#10b981' }, { r: 'Middle East & Africa', p: 10, c: '#f59e0b' }, { r: 'Latin America', p: 5, c: '#ec4899' }].map(r => (
                    <div key={r.r}>
                      <div className="flex justify-between text-sm mb-1"><span className="text-white/50">{r.r}</span><span className="text-white/25 font-mono">{r.p}%</span></div>
                      <div className="h-2 bg-white/5 rounded-full overflow-hidden"><motion.div initial={{ width: 0 }} animate={{ width: `${r.p}%` }} transition={{ duration: 1 }} className="h-full rounded-full" style={{ background: r.c }} /></div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="glass rounded-2xl p-5">
                <h3 className="text-sm font-semibold text-white mb-4">Top Genres</h3>
                <div className="space-y-3">
                  {[{ g: 'Electronic', p: 32, c: '#7a5af8' }, { g: 'Hip Hop', p: 24, c: '#ef4444' }, { g: 'Pop', p: 20, c: '#ec4899' }, { g: 'Rock', p: 14, c: '#f59e0b' }, { g: 'R&B', p: 10, c: '#8b5cf6' }].map(g => (
                    <div key={g.g}>
                      <div className="flex justify-between text-sm mb-1"><span className="text-white/50">{g.g}</span><span className="text-white/25 font-mono">{g.p}%</span></div>
                      <div className="h-2 bg-white/5 rounded-full overflow-hidden"><motion.div initial={{ width: 0 }} animate={{ width: `${g.p}%` }} transition={{ duration: 1 }} className="h-full rounded-full" style={{ background: g.c }} /></div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'moderation' && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <StatCard icon={AlertTriangle} label="Pending Reports" value="23" change="-8.2%" color="#f59e0b" />
              <StatCard icon={XCircle} label="Removed Today" value="7" change="+2" color="#ef4444" />
              <StatCard icon={CheckCircle2} label="Resolved (30d)" value="1,847" change="+24.3%" color="#10b981" />
              <StatCard icon={Clock} label="Avg. Response" value="2.4h" change="-15%" color="#3b82f6" />
            </div>
            <div className="glass rounded-2xl overflow-hidden">
              <div className="p-4 border-b border-white/5"><h3 className="text-sm font-semibold text-white">Content Reports Queue</h3></div>
              <div className="divide-y divide-white/[0.03]">
                {[
                  { type: 'Copyright', content: 'Track "Sample Beat" by DJ_X', reporter: 'Universal Music Group', severity: 'high', time: '15m ago' },
                  { type: 'Inappropriate', content: 'Playlist "Offensive Title #12"', reporter: 'AI Auto-detect', severity: 'high', time: '42m ago' },
                  { type: 'Spam', content: 'Artist "Bot_Music_123" — 500 tracks/hr', reporter: 'Rate Limiter', severity: 'medium', time: '1h ago' },
                  { type: 'Copyright', content: 'Track "Unauthorized Remix" — no license', reporter: 'Sony Music', severity: 'high', time: '2h ago' },
                  { type: 'Account', content: 'Suspicious login from 12 countries', reporter: 'Security System', severity: 'medium', time: '3h ago' },
                ].map((report, i) => (
                  <div key={i} className="flex items-center gap-4 p-4 hover:bg-white/[0.02] transition-colors">
                    <div className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${report.severity === 'high' ? 'bg-red-400' : 'bg-yellow-400'}`} />
                    <div className="flex-1 min-w-0">
                      <span className={`text-[10px] px-2 py-0.5 rounded-full ${report.severity === 'high' ? 'bg-red-500/10 text-red-400' : 'bg-yellow-500/10 text-yellow-400'}`}>{report.type}</span>
                      <p className="text-sm text-white mt-1">{report.content}</p>
                      <p className="text-[10px] text-white/25">Reported by: {report.reporter}</p>
                    </div>
                    <span className="text-[10px] text-white/15 hidden sm:block">{report.time}</span>
                    <div className="flex gap-1">
                      <button className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 transition"><CheckCircle2 className="w-3.5 h-3.5" /></button>
                      <button className="p-2 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 transition"><XCircle className="w-3.5 h-3.5" /></button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
}
