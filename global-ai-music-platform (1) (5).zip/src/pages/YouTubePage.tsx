import { useState, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Play, X, Flame, Clock, ExternalLink, Eye, Loader2, TrendingUp, Music2, ChevronRight, Heart, Share2, Bookmark, Grid3X3, List, Youtube } from 'lucide-react';
import { searchYouTubeMusic, getYouTubeTrending, formatViewCount, getTimeAgo, type YouTubeVideo } from '../services/youtube';

type Tab = 'search' | 'trending';
type ViewMode = 'grid' | 'list';

const CATEGORIES = [
  { label: '🎵 Top Hits 2024', query: 'Top Hits 2024' },
  { label: '🎤 Arabic Music', query: 'Arabic Music 2024' },
  { label: '🎧 Lo-fi Beats', query: 'Lofi hip hop beats' },
  { label: '🔥 Hip Hop', query: 'Hip Hop hits 2024' },
  { label: '💜 K-Pop', query: 'K-Pop best 2024' },
  { label: '⚡ EDM', query: 'EDM music mix 2024' },
  { label: '🎷 Jazz', query: 'Jazz piano relaxing' },
  { label: '🎸 Rock', query: 'Rock music best' },
  { label: '🎻 Classical', query: 'Classical music beautiful' },
  { label: '💃 Latin', query: 'Reggaeton Latin music 2024' },
  { label: '🌙 R&B', query: 'R&B soul music' },
  { label: '🎹 Piano', query: 'Piano music peaceful' },
];

export function YouTubePage() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<YouTubeVideo[]>([]);
  const [trending, setTrending] = useState<YouTubeVideo[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadingTrending, setLoadingTrending] = useState(false);
  const [activeTab, setActiveTab] = useState<Tab>('search');
  const [selectedVideo, setSelectedVideo] = useState<YouTubeVideo | null>(null);
  const [searched, setSearched] = useState(false);
  const [error, setError] = useState('');
  const [viewMode, setViewMode] = useState<ViewMode>('grid');
  const [savedVideos, setSavedVideos] = useState<string[]>([]);
  const [inlinePlayerId, setInlinePlayerId] = useState<string | null>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  const toggleSave = (id: string) => {
    setSavedVideos(prev => prev.includes(id) ? prev.filter(v => v !== id) : [...prev, id]);
  };

  const handleSearch = useCallback(async (searchQuery?: string) => {
    const q = searchQuery || query;
    if (!q.trim()) return;

    setLoading(true);
    setError('');
    setSearched(true);
    if (searchQuery) setQuery(searchQuery);

    try {
      const data = await searchYouTubeMusic(q, 24);
      setResults(data.items);
    } catch {
      setError('فشل البحث. حاول مرة أخرى.');
      setResults([]);
    } finally {
      setLoading(false);
    }
  }, [query]);

  const loadTrending = useCallback(async () => {
    if (trending.length > 0 || loadingTrending) return;
    setLoadingTrending(true);
    setError('');

    try {
      const data = await getYouTubeTrending(24);
      setTrending(data);
    } catch {
      setError('فشل تحميل الرائج.');
    } finally {
      setLoadingTrending(false);
    }
  }, [trending.length, loadingTrending]);

  const handleTabChange = (tab: Tab) => {
    setActiveTab(tab);
    if (tab === 'trending') loadTrending();
  };

  const playInline = (video: YouTubeVideo) => {
    if (inlinePlayerId === video.id) {
      setInlinePlayerId(null);
    } else {
      setInlinePlayerId(video.id);
    }
  };

  const videosToShow = activeTab === 'search' ? results : trending;

  return (
    <div className="space-y-6 pb-8">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-red-500/15 flex items-center justify-center shadow-lg shadow-red-500/10">
              <Youtube className="w-6 h-6 text-red-500" />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-display font-bold text-white flex items-center gap-2">
                YouTube <span className="text-gradient">Music</span>
              </h1>
              <p className="text-[10px] text-white/25">Search & play music videos • Powered by CENT</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setViewMode(viewMode === 'grid' ? 'list' : 'grid')}
              className="p-2 rounded-lg glass text-white/30 hover:text-white/60 transition"
            >
              {viewMode === 'grid' ? <List className="w-4 h-4" /> : <Grid3X3 className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </motion.div>

      {/* Tabs */}
      <div className="flex gap-2">
        <button
          onClick={() => handleTabChange('search')}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all ${
            activeTab === 'search' ? 'bg-red-500 text-white shadow-lg shadow-red-500/25' : 'glass text-white/40 hover:text-white/60'
          }`}
        >
          <Search className="w-4 h-4" /> Search
        </button>
        <button
          onClick={() => handleTabChange('trending')}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all ${
            activeTab === 'trending' ? 'bg-red-500 text-white shadow-lg shadow-red-500/25' : 'glass text-white/40 hover:text-white/60'
          }`}
        >
          <Flame className="w-4 h-4" /> Trending
        </button>
        {savedVideos.length > 0 && (
          <div className="flex items-center gap-1 px-3 py-2 rounded-xl glass text-white/25 text-xs">
            <Bookmark className="w-3 h-3" /> {savedVideos.length} saved
          </div>
        )}
      </div>

      {activeTab === 'search' && (
        <>
          {/* Search Input */}
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/30" />
            <input
              ref={searchInputRef}
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              placeholder="ابحث عن أي أغنية أو فنان..."
              className="w-full pl-12 pr-28 py-4 rounded-2xl bg-white/5 border border-white/10 text-white placeholder:text-white/25 focus:outline-none focus:border-red-500/50 focus:bg-white/8 transition-all text-base"
            />
            <div className="absolute right-2 top-1/2 -translate-y-1/2 flex gap-1">
              {query && (
                <button onClick={() => { setQuery(''); setResults([]); setSearched(false); }} className="p-2 rounded-lg hover:bg-white/10 transition">
                  <X className="w-4 h-4 text-white/30" />
                </button>
              )}
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => handleSearch()}
                disabled={loading || !query.trim()}
                className="px-5 py-2.5 rounded-xl bg-red-500 text-white text-sm font-bold disabled:opacity-50 flex items-center gap-2 shadow-lg shadow-red-500/20"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                بحث
              </motion.button>
            </div>
          </div>

          {/* Categories */}
          {!searched && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
              <div>
                <h3 className="text-sm font-semibold text-white/30 mb-3 flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-red-400" /> تصفح حسب النوع
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2">
                  {CATEGORIES.map((cat, i) => (
                    <motion.button
                      key={cat.label}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: i * 0.03 }}
                      whileHover={{ scale: 1.05, y: -2 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => handleSearch(cat.query)}
                      className="px-4 py-3 rounded-xl glass hover:bg-white/8 text-sm text-white/60 hover:text-white transition-all text-center border border-transparent hover:border-white/10"
                    >
                      {cat.label}
                    </motion.button>
                  ))}
                </div>
              </div>

              {/* CENT × YouTube Banner */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="relative rounded-3xl overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-red-600/20 via-cent-600/20 to-red-600/20 animate-gradient" />
                <div className="absolute inset-0 glass" />
                <div className="relative p-8 md:p-12 text-center">
                  <div className="flex items-center justify-center gap-4 mb-4">
                    <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-cent-400 to-cent-600 flex items-center justify-center shadow-xl">
                      <Music2 className="w-7 h-7 text-white" />
                    </div>
                    <span className="text-3xl text-white/10 font-thin">×</span>
                    <div className="w-14 h-14 rounded-2xl bg-red-500/15 flex items-center justify-center shadow-xl border border-red-500/20">
                      <Youtube className="w-7 h-7 text-red-500" />
                    </div>
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-2">
                    <span className="text-gradient">CENT</span> × <span className="text-red-400">YouTube</span>
                  </h3>
                  <p className="text-sm text-white/30 max-w-lg mx-auto leading-relaxed">
                    ابحث عن ملايين الفيديوهات الموسيقية من YouTube مباشرة داخل CENT.
                    شاهد، اكتشف، واستمتع بالموسيقى من جميع أنحاء العالم.
                  </p>
                </div>
              </motion.div>
            </motion.div>
          )}
        </>
      )}

      {/* Error */}
      {error && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm text-center">
          {error}
        </motion.div>
      )}

      {/* Loading */}
      {(loading || loadingTrending) && (
        <div className="flex items-center justify-center py-20">
          <div className="flex flex-col items-center gap-4">
            <motion.div
              className="w-14 h-14 rounded-full border-3 border-red-500/20 border-t-red-500"
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
            />
            <p className="text-sm text-white/30">جاري البحث في YouTube...</p>
          </div>
        </div>
      )}

      {/* Inline Video Player */}
      <AnimatePresence>
        {inlinePlayerId && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="glass-strong rounded-2xl overflow-hidden">
              <div className="flex items-center justify-between p-3 border-b border-white/5">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                  <span className="text-xs text-white/40">Now Playing</span>
                </div>
                <div className="flex items-center gap-2">
                  <a
                    href={`https://www.youtube.com/watch?v=${inlinePlayerId}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 px-2 py-1 rounded-lg text-xs text-red-400 hover:bg-red-500/10 transition"
                  >
                    <ExternalLink className="w-3 h-3" /> YouTube
                  </a>
                  <button
                    onClick={() => setInlinePlayerId(null)}
                    className="p-1.5 rounded-lg hover:bg-white/10 transition"
                  >
                    <X className="w-4 h-4 text-white/40" />
                  </button>
                </div>
              </div>
              <div className="aspect-video bg-black">
                <iframe
                  src={`https://www.youtube.com/embed/${inlinePlayerId}?autoplay=1&rel=0`}
                  title="YouTube Video"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  className="w-full h-full"
                />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Results */}
      {!loading && !loadingTrending && videosToShow.length > 0 && (searched || activeTab === 'trending') && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-white/40 flex items-center gap-2">
              {activeTab === 'trending' && <Flame className="w-4 h-4 text-orange-400" />}
              {activeTab === 'trending' ? 'Trending Music' : `${videosToShow.length} نتيجة`}
            </h3>
          </div>

          {viewMode === 'grid' ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {videosToShow.map((video, i) => (
                <VideoCard
                  key={video.id}
                  video={video}
                  index={i}
                  onPlay={playInline}
                  onExpand={setSelectedVideo}
                  onSave={toggleSave}
                  isSaved={savedVideos.includes(video.id)}
                  isPlaying={inlinePlayerId === video.id}
                  showRank={activeTab === 'trending'}
                />
              ))}
            </div>
          ) : (
            <div className="space-y-2">
              {videosToShow.map((video, i) => (
                <VideoListItem
                  key={video.id}
                  video={video}
                  index={i}
                  onPlay={playInline}
                  onExpand={setSelectedVideo}
                  onSave={toggleSave}
                  isSaved={savedVideos.includes(video.id)}
                  isPlaying={inlinePlayerId === video.id}
                  showRank={activeTab === 'trending'}
                />
              ))}
            </div>
          )}
        </motion.div>
      )}

      {/* No results */}
      {activeTab === 'search' && searched && !loading && results.length === 0 && !error && (
        <div className="text-center py-20">
          <Youtube className="w-16 h-16 text-white/10 mx-auto mb-4" />
          <p className="text-white/40">لا توجد نتائج لـ "{query}"</p>
          <p className="text-sm text-white/20 mt-1">جرب كلمات بحث مختلفة</p>
        </div>
      )}

      {/* Fullscreen Video Modal */}
      <AnimatePresence>
        {selectedVideo && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/85 backdrop-blur-md z-[100]"
              onClick={() => setSelectedVideo(null)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 40 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 40 }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              className="fixed inset-3 sm:inset-6 md:inset-10 lg:inset-16 z-[101] flex flex-col rounded-3xl overflow-hidden bg-surface-2 border border-white/5 shadow-2xl"
            >
              <div className="flex items-center justify-between p-3 sm:p-4 border-b border-white/5 bg-black/50">
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  <div className="w-8 h-8 rounded-lg bg-red-500/15 flex items-center justify-center flex-shrink-0">
                    <Youtube className="w-4 h-4 text-red-500" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold text-white truncate">{selectedVideo.title}</p>
                    <p className="text-[10px] text-white/30">{selectedVideo.channel}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0 ml-2">
                  <a
                    href={`https://www.youtube.com/watch?v=${selectedVideo.id}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-500/10 text-red-400 text-xs font-medium hover:bg-red-500/20 transition"
                  >
                    <ExternalLink className="w-3 h-3" /> YouTube
                  </a>
                  <button onClick={() => setSelectedVideo(null)} className="p-2 rounded-lg hover:bg-white/10 transition">
                    <X className="w-5 h-5 text-white/40" />
                  </button>
                </div>
              </div>

              <div className="flex-1 relative bg-black">
                <iframe
                  src={`https://www.youtube.com/embed/${selectedVideo.id}?autoplay=1&rel=0`}
                  title={selectedVideo.title}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  className="absolute inset-0 w-full h-full"
                />
              </div>

              <div className="p-3 sm:p-4 border-t border-white/5 bg-black/50 flex items-center justify-between">
                <div className="flex items-center gap-3 text-xs text-white/30">
                  {selectedVideo.viewCount && (
                    <span className="flex items-center gap-1"><Eye className="w-3 h-3" /> {formatViewCount(selectedVideo.viewCount)}</span>
                  )}
                  <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {getTimeAgo(selectedVideo.publishedAt)}</span>
                </div>
                <div className="flex items-center gap-2">
                  <button className="p-2 rounded-lg hover:bg-white/10 transition text-white/30">
                    <Heart className="w-4 h-4" />
                  </button>
                  <button className="p-2 rounded-lg hover:bg-white/10 transition text-white/30">
                    <Share2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ========== Video Card (Grid) ========== */
function VideoCard({ video, index, onPlay, onExpand, onSave, isSaved, isPlaying, showRank }: {
  video: YouTubeVideo; index: number; onPlay: (v: YouTubeVideo) => void; onExpand: (v: YouTubeVideo) => void;
  onSave: (id: string) => void; isSaved: boolean; isPlaying: boolean; showRank?: boolean;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.03 }}
      whileHover={{ y: -4 }}
      className={`group cursor-pointer ${isPlaying ? 'ring-2 ring-red-500/50 rounded-xl' : ''}`}
    >
      <div className="relative aspect-video rounded-xl overflow-hidden mb-3 bg-white/5 shadow-lg" onClick={() => onPlay(video)}>
        <img
          src={video.thumbnail}
          alt={video.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-all" />
        
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
          <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
            <div className="w-14 h-14 rounded-full bg-red-500/90 flex items-center justify-center shadow-2xl shadow-red-500/30 backdrop-blur-sm">
              <Play className="w-6 h-6 text-white fill-white ml-0.5" />
            </div>
          </motion.div>
        </div>

        {isPlaying && (
          <div className="absolute top-2 left-2 flex items-center gap-1.5 px-2 py-1 rounded-full bg-red-500/90 backdrop-blur-sm">
            <div className="flex items-end gap-[2px] h-3">
              {[0, 1, 2].map(i => (
                <motion.div
                  key={i}
                  className="w-[2px] bg-white rounded-full"
                  animate={{ height: ['30%', '100%', '30%'] }}
                  transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.15 }}
                />
              ))}
            </div>
            <span className="text-[9px] text-white font-medium">PLAYING</span>
          </div>
        )}

        {video.duration && (
          <span className="absolute bottom-2 right-2 px-1.5 py-0.5 rounded bg-black/80 text-[10px] text-white/90 font-mono backdrop-blur-sm">
            {video.duration}
          </span>
        )}

        {showRank && (
          <span className={`absolute top-2 left-2 w-7 h-7 rounded-lg flex items-center justify-center text-xs font-black shadow-lg ${
            index === 0 ? 'bg-yellow-400 text-black' :
            index === 1 ? 'bg-gray-300 text-black' :
            index === 2 ? 'bg-amber-600 text-white' :
            'bg-black/70 text-white/70 backdrop-blur-sm'
          }`}>
            {index + 1}
          </span>
        )}

        {/* Action buttons on hover */}
        <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={(e) => { e.stopPropagation(); onSave(video.id); }}
            className={`p-1.5 rounded-lg backdrop-blur-sm transition ${isSaved ? 'bg-cent-500/80 text-white' : 'bg-black/50 text-white/60 hover:bg-black/70'}`}
          >
            <Bookmark className={`w-3.5 h-3.5 ${isSaved ? 'fill-white' : ''}`} />
          </button>
          <button
            onClick={(e) => { e.stopPropagation(); onExpand(video); }}
            className="p-1.5 rounded-lg bg-black/50 backdrop-blur-sm text-white/60 hover:bg-black/70 transition"
          >
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <div onClick={() => onPlay(video)}>
        <p className="text-sm font-semibold text-white/80 line-clamp-2 group-hover:text-white transition-colors leading-snug">
          {video.title}
        </p>
        <p className="text-[11px] text-white/30 mt-1 flex items-center gap-1">
          {video.channel}
          <ChevronRight className="w-3 h-3" />
        </p>
        <div className="flex items-center gap-2 mt-1">
          {video.viewCount && (
            <span className="text-[10px] text-white/20 flex items-center gap-0.5">
              <Eye className="w-3 h-3" /> {formatViewCount(video.viewCount)}
            </span>
          )}
          <span className="text-[10px] text-white/20">{getTimeAgo(video.publishedAt)}</span>
        </div>
      </div>
    </motion.div>
  );
}

/* ========== Video List Item ========== */
function VideoListItem({ video, index, onPlay, onExpand, onSave, isSaved, isPlaying, showRank }: {
  video: YouTubeVideo; index: number; onPlay: (v: YouTubeVideo) => void; onExpand: (v: YouTubeVideo) => void;
  onSave: (id: string) => void; isSaved: boolean; isPlaying: boolean; showRank?: boolean;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.03 }}
      className={`flex items-center gap-3 p-2.5 rounded-xl group cursor-pointer transition-all hover:bg-white/[0.03] ${
        isPlaying ? 'bg-red-500/5 border border-red-500/20' : ''
      }`}
      onClick={() => onPlay(video)}
    >
      {showRank && (
        <span className={`text-sm font-black w-6 text-center ${
          index === 0 ? 'text-yellow-400' : index === 1 ? 'text-gray-400' : index === 2 ? 'text-amber-600' : 'text-white/15'
        }`}>
          {index + 1}
        </span>
      )}

      <div className="relative w-24 sm:w-32 aspect-video rounded-lg overflow-hidden flex-shrink-0 bg-white/5">
        <img src={video.thumbnail} alt="" className="w-full h-full object-cover" loading="lazy" />
        <div className="absolute inset-0 flex items-center justify-center bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity">
          <Play className="w-5 h-5 text-white fill-white" />
        </div>
        {isPlaying && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/40">
            <div className="flex items-end gap-[2px] h-4">
              {[0, 1, 2].map(i => (
                <motion.div
                  key={i}
                  className="w-[2px] bg-red-400 rounded-full"
                  animate={{ height: ['25%', '100%', '25%'] }}
                  transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.15 }}
                />
              ))}
            </div>
          </div>
        )}
        {video.duration && (
          <span className="absolute bottom-1 right-1 px-1 py-0.5 rounded bg-black/80 text-[8px] text-white/80 font-mono">
            {video.duration}
          </span>
        )}
      </div>

      <div className="flex-1 min-w-0">
        <p className={`text-sm font-medium line-clamp-2 leading-snug ${isPlaying ? 'text-red-400' : 'text-white/80'}`}>
          {video.title}
        </p>
        <p className="text-[11px] text-white/25 mt-0.5">{video.channel}</p>
        <div className="flex items-center gap-2 mt-0.5">
          {video.viewCount && (
            <span className="text-[10px] text-white/15">{formatViewCount(video.viewCount)} views</span>
          )}
          <span className="text-[10px] text-white/15">{getTimeAgo(video.publishedAt)}</span>
        </div>
      </div>

      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity" onClick={e => e.stopPropagation()}>
        <button onClick={() => onSave(video.id)} className={`p-1.5 rounded-lg transition ${isSaved ? 'text-cent-400' : 'text-white/20 hover:text-white/40'}`}>
          <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-current' : ''}`} />
        </button>
        <button onClick={() => onExpand(video)} className="p-1.5 rounded-lg text-white/20 hover:text-white/40 transition">
          <ExternalLink className="w-4 h-4" />
        </button>
      </div>
    </motion.div>
  );
}
