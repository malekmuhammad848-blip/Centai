import { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mic, MicOff, Music, Disc3, Heart, Play, Share2, RotateCcw, Waves, Radio, Fingerprint, Cpu, CheckCircle2, Loader2, Headphones } from 'lucide-react';
import { useStore } from '../store/useStore';
import { TRACKS } from '../data/mock';

type RecognitionStage = 'idle' | 'listening' | 'processing' | 'fingerprinting' | 'matching' | 'found' | 'not-found';

const STAGE_INFO: Record<RecognitionStage, { label: string; sublabel: string }> = {
  idle: { label: 'Tap to Identify', sublabel: 'Discover any song playing around you' },
  listening: { label: 'Listening...', sublabel: 'Hold your device near the music source' },
  processing: { label: 'Processing Audio', sublabel: 'Converting to spectrogram analysis' },
  fingerprinting: { label: 'Generating Fingerprint', sublabel: 'Creating audio signature vectors' },
  matching: { label: 'Matching Song', sublabel: 'Comparing against 100M+ tracks' },
  found: { label: 'Song Found!', sublabel: 'We identified your track' },
  'not-found': { label: 'No Match Found', sublabel: 'Try again in a quieter environment' },
};

const PIPELINE_STEPS = [
  { id: 'record', label: 'Record Audio', icon: Mic, detail: 'Capturing 10s audio sample' },
  { id: 'spectrogram', label: 'Spectrogram Analysis', icon: Waves, detail: 'FFT conversion & mel-spectrogram' },
  { id: 'fingerprint', label: 'Audio Fingerprinting', icon: Fingerprint, detail: 'Chromaprint hash generation' },
  { id: 'vector', label: 'Vector Embedding', icon: Cpu, detail: 'PostgreSQL pgvector search' },
  { id: 'match', label: 'ML Matching', icon: Radio, detail: 'Cosine similarity scoring' },
];

export function RecognizePage() {
  const [stage, setStage] = useState<RecognitionStage>('idle');
  const [currentStep, setCurrentStep] = useState(-1);
  const [waveformData, setWaveformData] = useState<number[]>(Array(64).fill(0.1));
  const [confidence, setConfidence] = useState(0);
  const [matchedTrack, setMatchedTrack] = useState(TRACKS[0]);
  const animFrameRef = useRef<number>(0);
  const { setCurrentTrack, setIsPlaying, toggleFavorite, favorites } = useStore();

  const animateWaveform = useCallback(() => {
    if (stage === 'listening') {
      setWaveformData(_prev => _prev.map(() => 0.1 + Math.random() * 0.9));
    } else if (stage === 'processing' || stage === 'fingerprinting') {
      setWaveformData(prev => prev.map((_v, i) => 0.3 + Math.sin(Date.now() / 200 + i * 0.3) * 0.4));
    } else {
      setWaveformData(prev => prev.map(v => v * 0.95 + 0.05));
    }
    animFrameRef.current = requestAnimationFrame(animateWaveform);
  }, [stage]);

  useEffect(() => {
    animFrameRef.current = requestAnimationFrame(animateWaveform);
    return () => cancelAnimationFrame(animFrameRef.current);
  }, [animateWaveform]);

  const startRecognition = () => {
    if (stage === 'listening') {
      setStage('idle');
      setCurrentStep(-1);
      return;
    }

    setStage('listening');
    setCurrentStep(0);
    setConfidence(0);

    const randomTrack = TRACKS[Math.floor(Math.random() * TRACKS.length)];
    setMatchedTrack(randomTrack);

    setTimeout(() => { setStage('processing'); setCurrentStep(1); }, 3000);
    setTimeout(() => { setStage('fingerprinting'); setCurrentStep(2); }, 4500);
    setTimeout(() => { setCurrentStep(3); }, 5500);
    setTimeout(() => { setStage('matching'); setCurrentStep(4); }, 6500);
    setTimeout(() => {
      const success = Math.random() > 0.1;
      if (success) {
        setStage('found');
        setConfidence(85 + Math.floor(Math.random() * 14));
      } else {
        setStage('not-found');
      }
    }, 8000);
  };

  const reset = () => {
    setStage('idle');
    setCurrentStep(-1);
    setConfidence(0);
  };

  const isActive = stage !== 'idle' && stage !== 'found' && stage !== 'not-found';
  const isFav = favorites.includes(matchedTrack.id);

  return (
    <div className="min-h-[calc(100vh-200px)] flex flex-col items-center">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-8 w-full">
        <h1 className="text-3xl md:text-4xl font-display font-bold text-white mb-2">
          Song <span className="text-gradient">Recognition</span>
        </h1>
        <p className="text-white/30 text-sm">Powered by CENT AI Audio Fingerprinting</p>
      </motion.div>

      <div className="flex-1 flex flex-col items-center justify-center w-full max-w-lg mx-auto">
        {/* Main button with ripples */}
        <div className="relative mb-10">
          {isActive && (
            <>
              {[0, 1, 2, 3].map(i => (
                <motion.div
                  key={i}
                  className="absolute inset-0 rounded-full border-2 border-cent-400/20"
                  initial={{ scale: 1, opacity: 0.4 }}
                  animate={{ scale: 2.5 + i * 0.5, opacity: 0 }}
                  transition={{ duration: 2.5, repeat: Infinity, delay: i * 0.5, ease: 'easeOut' }}
                />
              ))}
            </>
          )}

          <motion.div
            className="absolute inset-0 rounded-full bg-cent-500/20 blur-[50px]"
            animate={isActive ? { scale: [1, 1.6, 1], opacity: [0.15, 0.4, 0.15] } : { scale: 1, opacity: 0 }}
            transition={{ duration: 2, repeat: Infinity }}
          />

          <motion.button
            onClick={startRecognition}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className={`relative w-44 h-44 md:w-52 md:h-52 rounded-full flex items-center justify-center transition-all duration-500 overflow-hidden ${
              isActive
                ? 'bg-gradient-to-br from-cent-400 to-cent-600 shadow-2xl shadow-cent-500/50'
                : stage === 'found'
                ? 'bg-gradient-to-br from-emerald-400 to-emerald-600 shadow-2xl shadow-emerald-500/50'
                : stage === 'not-found'
                ? 'bg-gradient-to-br from-red-400 to-red-600 shadow-2xl shadow-red-500/40'
                : 'bg-gradient-to-br from-cent-500/80 to-cent-700/80 shadow-xl shadow-cent-500/25 hover:shadow-cent-500/40'
            }`}
          >
            <div className="absolute inset-0 bg-gradient-to-br from-white/20 via-transparent to-transparent" />
            
            <AnimatePresence mode="wait">
              {stage === 'idle' && (
                <motion.div key="mic" initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }}>
                  <Mic className="w-14 h-14 md:w-16 md:h-16 text-white relative z-10" />
                </motion.div>
              )}
              {stage === 'listening' && (
                <motion.div key="listening" initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }}>
                  <motion.div animate={{ scale: [1, 1.2, 1] }} transition={{ duration: 1, repeat: Infinity }}>
                    <Mic className="w-14 h-14 md:w-16 md:h-16 text-white relative z-10" />
                  </motion.div>
                </motion.div>
              )}
              {(stage === 'processing' || stage === 'fingerprinting' || stage === 'matching') && (
                <motion.div key="proc" initial={{ scale: 0 }} animate={{ scale: 1, rotate: 360 }} transition={{ rotate: { duration: 2, repeat: Infinity, ease: 'linear' } }} exit={{ scale: 0 }}>
                  <Disc3 className="w-14 h-14 md:w-16 md:h-16 text-white relative z-10" />
                </motion.div>
              )}
              {stage === 'found' && (
                <motion.div key="found" initial={{ scale: 0 }} animate={{ scale: [0, 1.3, 1] }}>
                  <CheckCircle2 className="w-14 h-14 md:w-16 md:h-16 text-white relative z-10" />
                </motion.div>
              )}
              {stage === 'not-found' && (
                <motion.div key="nf" initial={{ scale: 0 }} animate={{ scale: 1 }}>
                  <MicOff className="w-14 h-14 md:w-16 md:h-16 text-white relative z-10" />
                </motion.div>
              )}
            </AnimatePresence>
          </motion.button>
        </div>

        {/* Status */}
        <motion.div key={stage} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-8">
          <h2 className="text-xl font-bold text-white mb-1">{STAGE_INFO[stage].label}</h2>
          <p className="text-sm text-white/30">{STAGE_INFO[stage].sublabel}</p>
        </motion.div>

        {/* Waveform */}
        {(isActive || stage === 'found') && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="w-full mb-8">
            <div className="flex items-center justify-center gap-[2px] h-16">
              {waveformData.map((v, i) => (
                <motion.div
                  key={i}
                  className="w-1 rounded-full"
                  style={{
                    height: `${v * 100}%`,
                    background: stage === 'found'
                      ? 'linear-gradient(to top, #10b981, #34d399)'
                      : `linear-gradient(to top, ${matchedTrack.color}40, ${matchedTrack.color})`,
                  }}
                  animate={{ height: `${v * 100}%` }}
                  transition={{ duration: 0.1 }}
                />
              ))}
            </div>
          </motion.div>
        )}

        {/* ML Pipeline */}
        {isActive && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full glass rounded-2xl p-5 mb-6">
            <h3 className="text-xs font-semibold text-white/25 uppercase tracking-wider mb-4">ML Pipeline</h3>
            <div className="space-y-3">
              {PIPELINE_STEPS.map((step, i) => {
                const isCompleted = i < currentStep;
                const isCurrent = i === currentStep;
                return (
                  <div key={step.id} className="flex items-center gap-3">
                    <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 transition-all ${
                      isCompleted ? 'bg-emerald-500/15 text-emerald-400' : isCurrent ? 'bg-cent-500/15 text-cent-400' : 'bg-white/5 text-white/15'
                    }`}>
                      {isCompleted ? <CheckCircle2 className="w-4 h-4" /> : isCurrent ? <Loader2 className="w-4 h-4 animate-spin" /> : <step.icon className="w-4 h-4" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className={`text-sm font-medium ${isCompleted ? 'text-emerald-400' : isCurrent ? 'text-white' : 'text-white/20'}`}>{step.label}</p>
                      <p className="text-[10px] text-white/15">{step.detail}</p>
                    </div>
                    {isCompleted && <span className="text-xs text-emerald-400 font-bold">✓</span>}
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}

        {/* Result Card */}
        <AnimatePresence>
          {stage === 'found' && (
            <motion.div
              initial={{ opacity: 0, y: 30, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 30 }}
              className="w-full"
            >
              <div className="glass-strong rounded-3xl overflow-hidden">
                <div className="relative h-36 overflow-hidden">
                  <img src={matchedTrack.cover} alt="" className="w-full h-full object-cover scale-125 blur-md" />
                  <div className="absolute inset-0 bg-gradient-to-b from-black/30 to-black/70" />
                  <div className="absolute top-3 right-3 px-3 py-1.5 rounded-full bg-emerald-500/20 border border-emerald-500/30">
                    <span className="text-xs font-bold text-emerald-400">{confidence}% Match</span>
                  </div>
                </div>

                <div className="p-6 -mt-14 relative">
                  <div className="flex gap-4">
                    <motion.div
                      initial={{ rotate: -10, scale: 0.8 }}
                      animate={{ rotate: 0, scale: 1 }}
                      className="w-28 h-28 rounded-2xl overflow-hidden shadow-2xl flex-shrink-0 ring-4 ring-surface-2"
                    >
                      <img src={matchedTrack.cover} alt="" className="w-full h-full object-cover" />
                    </motion.div>
                    <div className="flex-1 min-w-0 pt-10">
                      <h3 className="text-xl font-bold text-white truncate">{matchedTrack.title}</h3>
                      <p className="text-sm text-white/40">{matchedTrack.artist}</p>
                      <p className="text-xs text-white/20 mt-1">{matchedTrack.album} · {matchedTrack.genre}</p>
                    </div>
                  </div>

                  {/* Fingerprint visualization */}
                  <div className="mt-5 mb-4">
                    <p className="text-[10px] text-white/15 uppercase tracking-wider mb-2">Audio Fingerprint Match</p>
                    <div className="h-14 rounded-xl overflow-hidden bg-white/[0.03] flex items-end gap-px px-1 py-1">
                      {Array.from({ length: 48 }, (_, i) => (
                        <motion.div
                          key={i}
                          className="flex-1 rounded-t-sm"
                          initial={{ height: 0 }}
                          animate={{ height: `${20 + Math.sin(i * 0.5) * 30 + Math.random() * 40}%` }}
                          transition={{ delay: i * 0.02, duration: 0.5 }}
                          style={{ background: `linear-gradient(to top, ${matchedTrack.color}25, ${matchedTrack.color})` }}
                        />
                      ))}
                    </div>
                  </div>

                  <div className="flex gap-3 mt-5">
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => { setCurrentTrack(matchedTrack); setIsPlaying(true); }}
                      className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-xl bg-gradient-to-r from-cent-400 to-cent-600 text-white font-semibold text-sm shadow-lg shadow-cent-500/25"
                    >
                      <Play className="w-4 h-4" /> Play Now
                    </motion.button>
                    <button
                      onClick={() => toggleFavorite(matchedTrack.id)}
                      className={`px-4 py-3.5 rounded-xl glass ${isFav ? 'text-cent-400' : 'text-white/30'}`}
                    >
                      <Heart className={`w-5 h-5 ${isFav ? 'fill-current' : ''}`} />
                    </button>
                    <button className="px-4 py-3.5 rounded-xl glass text-white/30">
                      <Share2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </div>

              <button onClick={reset} className="w-full mt-4 flex items-center justify-center gap-2 py-3.5 rounded-xl glass text-white/40 hover:text-white transition-colors">
                <RotateCcw className="w-4 h-4" /> Recognize Another Song
              </button>
            </motion.div>
          )}

          {stage === 'not-found' && (
            <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="w-full text-center">
              <div className="glass rounded-2xl p-10">
                <Music className="w-20 h-20 text-white/8 mx-auto mb-4" />
                <p className="text-white/50 text-lg mb-1">Couldn't identify the song</p>
                <p className="text-sm text-white/20 mb-8">Make sure music is playing clearly nearby</p>
                <button onClick={reset} className="px-8 py-3.5 rounded-xl bg-cent-500 text-white font-semibold text-sm flex items-center gap-2 mx-auto shadow-lg shadow-cent-500/20">
                  <RotateCcw className="w-4 h-4" /> Try Again
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Idle content */}
        {stage === 'idle' && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="w-full mt-8">
            <h3 className="text-sm font-semibold text-white/25 uppercase tracking-wider mb-4">Recent Recognitions</h3>
            <div className="space-y-2">
              {TRACKS.slice(0, 4).map((track, i) => (
                <motion.div
                  key={track.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 + i * 0.1 }}
                  className="flex items-center gap-3 p-3 rounded-xl glass hover:bg-white/6 cursor-pointer transition-all"
                  onClick={() => { setCurrentTrack(track); setIsPlaying(true); }}
                >
                  <div className="w-12 h-12 rounded-lg overflow-hidden flex-shrink-0 shadow-md">
                    <img src={track.cover} alt="" className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white truncate">{track.title}</p>
                    <p className="text-xs text-white/30">{track.artist}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] text-cent-400 font-semibold">97% match</p>
                    <p className="text-[10px] text-white/15">{i + 1}h ago</p>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Tech info */}
            <div className="mt-8 glass rounded-2xl p-6">
              <h3 className="text-xs font-semibold text-white/25 uppercase tracking-wider mb-4">CENT Recognition Technology</h3>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { label: 'Audio Fingerprinting', detail: 'Chromaprint', icon: Fingerprint },
                  { label: 'Spectrogram', detail: 'Librosa FFT', icon: Waves },
                  { label: 'Vector DB', detail: 'PostgreSQL pgvector', icon: Cpu },
                  { label: 'ML Backend', detail: 'Python FastAPI', icon: Headphones },
                ].map(tech => (
                  <div key={tech.label} className="p-3 rounded-xl bg-white/[0.03] border border-white/[0.04]">
                    <tech.icon className="w-4 h-4 text-cent-400 mb-2" />
                    <p className="text-xs font-medium text-white/50">{tech.label}</p>
                    <p className="text-[10px] text-cent-400">{tech.detail}</p>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
