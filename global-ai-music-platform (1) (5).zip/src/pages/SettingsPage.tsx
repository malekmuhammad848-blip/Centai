import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Settings, Volume2, Wifi, Download, Bell, Shield, Palette, Globe, Headphones, Music, Smartphone, Moon, Sun, Eye, HardDrive, Zap, ChevronRight, Check, Info, CheckCircle2 } from 'lucide-react';
import { useStore } from '../store/useStore';
import { useSettings } from '../store/useSettings';
import { t, LANGUAGE_NAMES, type Language } from '../i18n/translations';

interface SettingToggleProps {
  label: string;
  description?: string;
  enabled: boolean;
  onToggle: () => void;
  icon: typeof Volume2;
  color: string;
}

function SettingToggle({ label, description, enabled, onToggle, icon: Icon, color }: SettingToggleProps) {
  return (
    <div className="flex items-center justify-between py-4 border-b border-white/[0.03] last:border-0">
      <div className="flex items-center gap-3 flex-1 min-w-0">
        <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: color + '12' }}>
          <Icon className="w-4 h-4" style={{ color }} />
        </div>
        <div className="min-w-0">
          <p className="text-sm font-medium text-white">{label}</p>
          {description && <p className="text-[10px] text-white/25 mt-0.5">{description}</p>}
        </div>
      </div>
      <button
        onClick={onToggle}
        className={`relative w-12 h-7 rounded-full transition-all duration-300 flex-shrink-0 ${
          enabled ? 'bg-cent-500' : 'bg-white/10'
        }`}
      >
        <motion.div
          className="absolute top-1 w-5 h-5 rounded-full bg-white shadow-md"
          animate={{ left: enabled ? 26 : 4 }}
          transition={{ type: 'spring', stiffness: 500, damping: 30 }}
        />
      </button>
    </div>
  );
}

interface SettingSelectProps {
  label: string;
  description?: string;
  value: string;
  options: { value: string; label: string }[];
  onChange: (v: string) => void;
  icon: typeof Volume2;
  color: string;
}

function SettingSelect({ label, description, value, options, onChange, icon: Icon, color }: SettingSelectProps) {
  const [open, setOpen] = useState(false);
  const selectedLabel = options.find(o => o.value === value)?.label || value;

  return (
    <div className="py-4 border-b border-white/[0.03] last:border-0">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center justify-between w-full text-left"
      >
        <div className="flex items-center gap-3 flex-1 min-w-0">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: color + '12' }}>
            <Icon className="w-4 h-4" style={{ color }} />
          </div>
          <div className="min-w-0">
            <p className="text-sm font-medium text-white">{label}</p>
            {description && <p className="text-[10px] text-white/25 mt-0.5">{description}</p>}
          </div>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          <span className="text-xs text-cent-400 font-medium">{selectedLabel}</span>
          <ChevronRight className={`w-4 h-4 text-white/20 transition-transform ${open ? 'rotate-90' : ''}`} />
        </div>
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="mt-3 ml-12 space-y-1">
              {options.map(opt => (
                <button
                  key={opt.value}
                  onClick={() => { onChange(opt.value); setOpen(false); }}
                  className={`flex items-center justify-between w-full px-4 py-2.5 rounded-xl text-sm transition-all ${
                    value === opt.value ? 'bg-cent-500/10 text-cent-400' : 'text-white/40 hover:bg-white/5'
                  }`}
                >
                  {opt.label}
                  {value === opt.value && <Check className="w-4 h-4" />}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export function SettingsPage() {
  const { theme, toggleTheme, volume, setVolume, equalizerPreset, setEqualizerPreset } = useStore();
  const settings = useSettings();
  const lang = settings.language;
  const [showSaved, setShowSaved] = useState('');

  const showSaveToast = (msg: string) => {
    setShowSaved(msg);
    setTimeout(() => setShowSaved(''), 2000);
  };

  const languageOptions = (Object.entries(LANGUAGE_NAMES) as [Language, string][]).map(([value, label]) => ({
    value,
    label: `${label}${value === lang ? ' ✓' : ''}`,
  }));

  const qualityOptions = [
    { value: 'Low (96kbps)', label: 'Low (96kbps)' },
    { value: 'Normal (160kbps)', label: 'Normal (160kbps)' },
    { value: 'High (320kbps)', label: 'High (320kbps)' },
    { value: 'Very High (FLAC)', label: 'Very High (FLAC)' },
  ];

  const eqOptions = [
    { value: 'flat', label: 'Flat' },
    { value: 'Bass Boost', label: 'Bass Boost' },
    { value: 'Treble', label: 'Treble' },
    { value: 'Vocal', label: 'Vocal' },
    { value: 'Electronic', label: 'Electronic' },
    { value: 'Rock', label: 'Rock' },
  ];

  const storageOptions = [
    { value: '2 GB', label: '2 GB' },
    { value: '5 GB', label: '5 GB' },
    { value: '10 GB', label: '10 GB' },
    { value: '20 GB', label: '20 GB' },
    { value: 'Unlimited', label: 'Unlimited' },
  ];

  return (
    <div className="space-y-8 max-w-2xl mx-auto pb-16">
      {/* Save Toast */}
      <AnimatePresence>
        {showSaved && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.9 }}
            className="fixed top-4 left-1/2 -translate-x-1/2 z-[200] flex items-center gap-2 px-5 py-3 rounded-2xl bg-emerald-500/90 backdrop-blur-lg text-white text-sm font-medium shadow-2xl shadow-emerald-500/30"
          >
            <CheckCircle2 className="w-4 h-4" />
            {showSaved}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
        <div className="flex items-center gap-3 mb-2">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-cent-400 to-cent-600 flex items-center justify-center shadow-lg shadow-cent-500/25">
            <Settings className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-2xl md:text-3xl font-display font-bold text-white">{t('settingsTitle', lang)}</h1>
            <p className="text-[10px] text-white/25">{t('customizeExperience', lang)}</p>
          </div>
        </div>
      </motion.div>

      {/* Profile Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-premium rounded-2xl p-5 flex items-center gap-4"
      >
        <div className="w-14 h-14 rounded-full bg-gradient-to-br from-cent-400 to-cent-600 flex items-center justify-center text-white font-bold text-xl shadow-lg">
          C
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-base font-bold text-white">CENT User</p>
          <p className="text-xs text-white/30">Premium Subscriber</p>
        </div>
        <div className="px-3 py-1.5 rounded-full bg-gradient-to-r from-cent-400/20 to-cent-500/20 border border-cent-400/20">
          <span className="text-[10px] text-cent-400 font-bold">PRO</span>
        </div>
      </motion.div>

      {/* Audio Settings */}
      <motion.section initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
        <h2 className="text-sm font-bold text-white/50 uppercase tracking-wider mb-3 flex items-center gap-2">
          <Headphones className="w-4 h-4 text-cent-400" /> {t('audio', lang)}
        </h2>
        <div className="glass rounded-2xl px-5">
          <SettingSelect
            label={t('streamingQuality', lang)}
            description={lang === 'ar' ? 'جودة أعلى تستهلك بيانات أكثر' : 'Higher quality uses more data'}
            value={settings.audioQuality}
            options={qualityOptions}
            onChange={(v) => { settings.setAudioQuality(v); showSaveToast('✓ Streaming quality updated'); }}
            icon={Music}
            color="#7a5af8"
          />
          <SettingSelect
            label={t('downloadQuality', lang)}
            description={lang === 'ar' ? 'جودة التنزيل للاستماع بدون إنترنت' : 'Quality for offline downloads'}
            value={settings.downloadQuality}
            options={qualityOptions}
            onChange={(v) => { settings.setDownloadQuality(v); showSaveToast('✓ Download quality updated'); }}
            icon={Download}
            color="#3b82f6"
          />
          <SettingSelect
            label={t('equalizerPreset', lang)}
            value={equalizerPreset}
            options={eqOptions}
            onChange={(v) => { setEqualizerPreset(v); showSaveToast('✓ Equalizer preset updated'); }}
            icon={Zap}
            color="#f59e0b"
          />

          {/* Volume */}
          <div className="py-4 border-b border-white/[0.03]">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-9 h-9 rounded-xl bg-cent-500/12 flex items-center justify-center">
                <Volume2 className="w-4 h-4 text-cent-400" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-white">{t('volume', lang)}</p>
              </div>
              <span className="text-xs text-cent-400 font-mono font-bold">{volume}%</span>
            </div>
            <div className="ml-12">
              <input
                type="range"
                min={0}
                max={100}
                value={volume}
                onChange={(e) => setVolume(Number(e.target.value))}
                className="w-full"
              />
            </div>
          </div>

          <SettingToggle label={t('spatialAudio', lang)} description={lang === 'ar' ? 'تجربة صوت مكاني ثلاثي الأبعاد' : '3D immersive audio experience'} enabled={settings.spatialAudio} onToggle={() => { settings.toggleSpatialAudio(); showSaveToast('✓ Spatial audio updated'); }} icon={Headphones} color="#8b5cf6" />
          <SettingToggle label={t('autoPlay', lang)} description={lang === 'ar' ? 'تشغيل أغاني مشابهة تلقائياً' : 'Play similar tracks automatically'} enabled={settings.autoPlay} onToggle={() => { settings.toggleAutoPlay(); showSaveToast('✓ Auto-play updated'); }} icon={Music} color="#10b981" />
          <SettingToggle label={t('crossfade', lang)} description={lang === 'ar' ? 'انتقال سلس بين الأغاني' : 'Smooth transitions between tracks'} enabled={settings.crossfade} onToggle={() => { settings.toggleCrossfade(); showSaveToast('✓ Crossfade updated'); }} icon={Zap} color="#06b6d4" />
          <SettingToggle label={t('volumeNormalization', lang)} description={lang === 'ar' ? 'موازنة الصوت بين الأغاني' : 'Balance volume across tracks'} enabled={settings.normalizeVolume} onToggle={() => { settings.toggleNormalizeVolume(); showSaveToast('✓ Volume normalization updated'); }} icon={Volume2} color="#f97316" />
        </div>
      </motion.section>

      {/* Display */}
      <motion.section initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
        <h2 className="text-sm font-bold text-white/50 uppercase tracking-wider mb-3 flex items-center gap-2">
          <Palette className="w-4 h-4 text-cent-400" /> {t('display', lang)}
        </h2>
        <div className="glass rounded-2xl px-5">
          <div className="flex items-center justify-between py-4 border-b border-white/[0.03]">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-amber-500/12 flex items-center justify-center">
                {theme === 'dark' ? <Moon className="w-4 h-4 text-amber-400" /> : <Sun className="w-4 h-4 text-amber-400" />}
              </div>
              <div>
                <p className="text-sm font-medium text-white">{t('theme', lang)}</p>
                <p className="text-[10px] text-white/25">{theme === 'dark' ? t('darkMode', lang) : t('lightMode', lang)}</p>
              </div>
            </div>
            <button
              onClick={toggleTheme}
              className="px-4 py-2 rounded-xl glass text-xs text-white/50 font-medium hover:bg-white/10 transition flex items-center gap-2"
            >
              {theme === 'dark' ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
              {t('switchTheme', lang)}
            </button>
          </div>
          <SettingToggle label={t('showLyrics', lang)} description={lang === 'ar' ? 'عرض كلمات متزامنة أثناء التشغيل' : 'Display synced lyrics during playback'} enabled={settings.showLyrics} onToggle={() => { settings.toggleShowLyrics(); showSaveToast('✓ Show lyrics updated'); }} icon={Eye} color="#ec4899" />

          {/* Language - Most important fix */}
          <SettingSelect
            label={t('language', lang)}
            description={lang === 'ar' ? 'لغة واجهة التطبيق' : 'App interface language'}
            value={settings.language}
            options={languageOptions}
            onChange={(v) => {
              settings.setLanguage(v as Language);
              showSaveToast(`✓ Language changed to ${LANGUAGE_NAMES[v as Language]}`);
            }}
            icon={Globe}
            color="#3b82f6"
          />
        </div>
      </motion.section>

      {/* Data & Storage */}
      <motion.section initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
        <h2 className="text-sm font-bold text-white/50 uppercase tracking-wider mb-3 flex items-center gap-2">
          <HardDrive className="w-4 h-4 text-cent-400" /> {t('dataStorage', lang)}
        </h2>
        <div className="glass rounded-2xl px-5">
          <SettingToggle label={t('wifiOnly', lang)} description={lang === 'ar' ? 'تنزيل فقط عبر Wi-Fi' : 'Download only on Wi-Fi'} enabled={settings.wifiOnly} onToggle={() => { settings.toggleWifiOnly(); showSaveToast('✓ Wi-Fi only updated'); }} icon={Wifi} color="#10b981" />
          <SettingToggle label={t('offlineMode', lang)} description={lang === 'ar' ? 'تمكين التشغيل بدون إنترنت' : 'Enable offline playback'} enabled={settings.offlineMode} onToggle={() => { settings.toggleOfflineMode(); showSaveToast('✓ Offline mode updated'); }} icon={Download} color="#3b82f6" />
          <SettingSelect
            label={t('storageLimit', lang)}
            value={settings.storageLimit}
            options={storageOptions}
            onChange={(v) => { settings.setStorageLimit(v); showSaveToast('✓ Storage limit updated'); }}
            icon={HardDrive}
            color="#8b5cf6"
          />

          {/* Storage usage */}
          <div className="py-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-white/40">{t('storageUsed', lang)}</span>
              <span className="text-xs text-white/40">2.4 GB / {settings.storageLimit}</span>
            </div>
            <div className="h-2 bg-white/5 rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-cent-400 to-cent-600 rounded-full" style={{ width: '24%' }} />
            </div>
            <div className="flex gap-3 mt-2">
              <span className="text-[10px] text-white/20 flex items-center gap-1"><div className="w-2 h-2 rounded bg-cent-400" /> Music (1.8 GB)</span>
              <span className="text-[10px] text-white/20 flex items-center gap-1"><div className="w-2 h-2 rounded bg-accent-pink" /> Cache (0.6 GB)</span>
            </div>
          </div>
        </div>
      </motion.section>

      {/* Notifications */}
      <motion.section initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
        <h2 className="text-sm font-bold text-white/50 uppercase tracking-wider mb-3 flex items-center gap-2">
          <Bell className="w-4 h-4 text-cent-400" /> {t('notifications', lang)}
        </h2>
        <div className="glass rounded-2xl px-5">
          <SettingToggle
            label={t('pushNotifications', lang)}
            description={lang === 'ar' ? 'إصدارات جديدة وتوصيات' : 'New releases & recommendations'}
            enabled={settings.notifications}
            onToggle={() => {
              settings.toggleNotifications();
              // Request notification permission if enabling
              if (!settings.notifications && 'Notification' in window) {
                Notification.requestPermission();
              }
              showSaveToast('✓ Notifications updated');
            }}
            icon={Bell}
            color="#f59e0b"
          />
        </div>
      </motion.section>

      {/* Security */}
      <motion.section initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
        <h2 className="text-sm font-bold text-white/50 uppercase tracking-wider mb-3 flex items-center gap-2">
          <Shield className="w-4 h-4 text-cent-400" /> {t('security', lang)}
        </h2>
        <div className="glass rounded-2xl px-5">
          <div className="flex items-center justify-between py-4 border-b border-white/[0.03]">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/12 flex items-center justify-center">
                <Shield className="w-4 h-4 text-emerald-400" />
              </div>
              <div>
                <p className="text-sm font-medium text-white">{t('privacy', lang)}</p>
                <p className="text-[10px] text-white/25">{lang === 'ar' ? 'إدارة إعدادات الخصوصية' : 'Manage your privacy settings'}</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-white/20" />
          </div>
          <div className="flex items-center justify-between py-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-red-500/12 flex items-center justify-center">
                <Smartphone className="w-4 h-4 text-red-400" />
              </div>
              <div>
                <p className="text-sm font-medium text-white">{t('connectedDevices', lang)}</p>
                <p className="text-[10px] text-white/25">{lang === 'ar' ? '2 أجهزة متصلة' : '2 devices connected'}</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-white/20" />
          </div>
        </div>
      </motion.section>

      {/* About */}
      <motion.section initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }}>
        <div className="glass rounded-2xl p-5 text-center">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cent-400 to-cent-600 flex items-center justify-center mx-auto mb-3 shadow-lg shadow-cent-500/25">
            <Music className="w-6 h-6 text-white" />
          </div>
          <h3 className="font-display text-xl font-bold text-gradient mb-1">CENT</h3>
          <p className="text-[10px] text-white/20 mb-3">Version 7.0.0 · Build 2025.07</p>
          <div className="flex items-center justify-center gap-1 text-[9px] text-white/10">
            <Info className="w-3 h-3" />
            <span>{t('allRightsReserved', lang)}</span>
          </div>
        </div>
      </motion.section>
    </div>
  );
}
