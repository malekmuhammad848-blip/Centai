import { motion } from 'framer-motion';
import { Music, Globe, Shield, Cpu, Zap, Headphones, Mic, Heart, ExternalLink, Smartphone, Monitor, Server, Database, Cloud, Lock, Waves, Radio, Sparkles, TrendingUp, Users, Play, Award, Target, Star, Code, Layers, Disc3, BarChart3, MessageCircle, Download, Eye, CheckCircle2 } from 'lucide-react';

/* Instagram SVG */
function IGIcon({ size = 28 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <rect x="2" y="2" width="20" height="20" rx="6" stroke="white" strokeWidth="2.5" />
      <circle cx="12" cy="12" r="5" stroke="white" strokeWidth="2.5" />
      <circle cx="17.5" cy="6.5" r="1.5" fill="white" />
    </svg>
  );
}

const FOUNDERS = [
  {
    handle: '@cx0hl',
    name: 'CX0HL',
    url: 'https://www.instagram.com/cx0hl?igsh=dGx1dXZ1anhuajRl',
    role: 'Co-Founder & CEO',
    avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=300&h=300&fit=crop',
    bio: 'Product visionary driving CENT\'s mission to democratize music globally. Expert in brand strategy, growth, and user experience design.',
    skills: ['Product Strategy', 'Brand Design', 'Growth', 'Business Dev'],
    gradient: 'from-violet-500 via-purple-500 to-fuchsia-500',
    bgGradient: 'from-violet-500/8 to-fuchsia-500/4',
    color: '#8b5cf6',
  },
  {
    handle: '@vkz7t',
    name: 'VKZ7T',
    url: 'https://www.instagram.com/vkz7t?igsh=MTc1cjJjbm1tMHh5cg==',
    role: 'Co-Founder & CTO',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=300&fit=crop',
    bio: 'Technical architect building scalable systems at global scale. Specializes in AI/ML, distributed systems, and audio engineering.',
    skills: ['AI/ML', 'System Design', 'Full-Stack', 'Cloud Infra'],
    gradient: 'from-blue-500 via-cyan-500 to-teal-500',
    bgGradient: 'from-blue-500/8 to-teal-500/4',
    color: '#06b6d4',
  },
];

const STATS = [
  { value: '100M+', label: 'Tracks', icon: Music, color: '#7a5af8' },
  { value: '50M+', label: 'Active Users', icon: Users, color: '#ec4899' },
  { value: '195', label: 'Countries', icon: Globe, color: '#3b82f6' },
  { value: '99.99%', label: 'Uptime SLA', icon: Zap, color: '#10b981' },
  { value: '1B+', label: 'Monthly Streams', icon: Play, color: '#f59e0b' },
  { value: '97.8%', label: 'AI Accuracy', icon: Award, color: '#06b6d4' },
];

const FEATURES = [
  { icon: Headphones, title: 'Spatial Audio', desc: 'Dolby Atmos & 3D immersive sound with head tracking', color: '#7a5af8' },
  { icon: Mic, title: 'AI Recognition', desc: 'Identify any song in seconds with ML audio fingerprinting', color: '#ec4899' },
  { icon: Cpu, title: 'AI Discovery', desc: 'Deep learning taste profiling with 500+ signal features', color: '#3b82f6' },
  { icon: Shield, title: 'DRM Protection', desc: 'Enterprise-grade content protection & rights management', color: '#10b981' },
  { icon: Waves, title: 'Lossless Audio', desc: '24-bit/192kHz FLAC & Hi-Res audio streaming', color: '#f59e0b' },
  { icon: Globe, title: 'Global CDN', desc: '280+ edge nodes across 195 countries, <50ms latency', color: '#06b6d4' },
  { icon: Sparkles, title: 'Mood AI', desc: 'Real-time emotion detection for contextual playlists', color: '#8b5cf6' },
  { icon: Download, title: 'Offline Mode', desc: 'Smart download with auto quality optimization', color: '#ef4444' },
  { icon: Layers, title: 'Pro Equalizer', desc: '10-band parametric EQ with custom presets', color: '#a855f7' },
  { icon: MessageCircle, title: 'Synced Lyrics', desc: 'Real-time word-by-word synchronized lyrics display', color: '#fbbf24' },
  { icon: Code, title: 'Developer API', desc: 'RESTful & GraphQL APIs for third-party integrations', color: '#14b8a6' },
  { icon: Radio, title: 'Live Radio', desc: 'AI-curated infinite stations by mood, genre, activity', color: '#f97316' },
];

const TECH = [
  { cat: 'Frontend', items: ['Next.js 14 (SSR/ISR)', 'React Native Expo', 'TypeScript Strict', 'Tailwind CSS 4', 'Framer Motion', 'Zustand + TanStack'], icon: Monitor, color: '#7a5af8' },
  { cat: 'Backend', items: ['NestJS Microservices', 'PostgreSQL + pgvector', 'Prisma ORM', 'Redis Cluster', 'WebSocket Gateway', 'FastAPI ML Service'], icon: Server, color: '#3b82f6' },
  { cat: 'Cloud', items: ['Vercel Edge Network', 'Railway Containers', 'Supabase Realtime', 'AWS S3 + CloudFront', 'Cloudinary CDN', 'Docker + K8s'], icon: Cloud, color: '#10b981' },
  { cat: 'AI / ML', items: ['Librosa + Chromaprint', 'pgvector Embeddings', 'TensorFlow Serving', 'ONNX Runtime', 'Scikit-learn Pipeline', 'Custom Audio CNN'], icon: Cpu, color: '#f59e0b' },
];

const DB_TABLES = [
  { table: 'Users', fields: ['id UUID PK', 'email UNIQUE', 'name VARCHAR', 'avatar_url', 'subscription ENUM', 'created_at TIMESTAMP'], color: '#7a5af8' },
  { table: 'Tracks', fields: ['id UUID PK', 'title VARCHAR', 'artist_id FK → Artists', 'album_id FK → Albums', 'audio_url TEXT', 'duration INT', 'genre VARCHAR'], color: '#3b82f6' },
  { table: 'Artists', fields: ['id UUID PK', 'name VARCHAR', 'bio TEXT', 'image_url', 'verified BOOLEAN', 'followers_count INT'], color: '#ec4899' },
  { table: 'Albums', fields: ['id UUID PK', 'title VARCHAR', 'artist_id FK → Artists', 'cover_url', 'release_date DATE', 'track_count INT'], color: '#f59e0b' },
  { table: 'Playlists', fields: ['id UUID PK', 'name VARCHAR', 'user_id FK → Users', 'is_public BOOLEAN', 'description TEXT'], color: '#10b981' },
  { table: 'Favorites', fields: ['id UUID PK', 'user_id FK → Users', 'track_id FK → Tracks', 'created_at TIMESTAMP'], color: '#8b5cf6' },
  { table: 'History', fields: ['id UUID PK', 'user_id FK → Users', 'track_id FK → Tracks', 'played_at TIMESTAMP', 'duration_played INT'], color: '#06b6d4' },
  { table: 'Fingerprints', fields: ['id UUID PK', 'track_id FK → Tracks', 'hash BYTEA', 'embedding VECTOR(512)', 'spectrogram_url TEXT'], color: '#a855f7' },
  { table: 'Payments', fields: ['id UUID PK', 'user_id FK → Users', 'stripe_id VARCHAR', 'amount DECIMAL', 'plan VARCHAR', 'status ENUM'], color: '#ef4444' },
];

const MILESTONES = [
  { year: '2024 Q1', event: 'Company founded & seed funding ($2M)', icon: Star },
  { year: '2024 Q2', event: 'MVP launch — 10K beta users', icon: Zap },
  { year: '2024 Q3', event: 'AI Recognition engine deployed', icon: Cpu },
  { year: '2024 Q4', event: 'Series A — $12M raised', icon: TrendingUp },
  { year: '2025 Q1', event: '1M users milestone', icon: Users },
  { year: '2025 Q2', event: 'Global launch — 195 countries', icon: Globe },
  { year: '2025 Q3', event: 'Series B — $50M raised', icon: Award },
  { year: '2025 Q4', event: '50M users & 1B+ streams/month', icon: BarChart3 },
];

export function AboutPage() {
  return (
    <div className="space-y-20 sm:space-y-28 pb-20 max-w-6xl mx-auto">

      {/* ═══ HERO ═══ */}
      <motion.section initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center pt-8 sm:pt-16 relative">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <motion.div className="absolute w-[400px] sm:w-[600px] h-[400px] sm:h-[600px] rounded-full bg-cent-500/8 blur-[120px] -top-32 left-1/4"
            animate={{ x: [0, 80, -60, 0], y: [0, -50, 40, 0], scale: [1, 1.2, 0.85, 1] }} transition={{ duration: 15, repeat: Infinity, ease: 'easeInOut' }} />
        </div>

        <motion.div initial={{ scale: 0, rotate: -180 }} animate={{ scale: 1, rotate: 0 }} transition={{ type: 'spring', stiffness: 100, damping: 12 }} className="relative inline-block mb-8">
          <motion.div className="absolute -inset-8 rounded-[40px] bg-cent-400/15 blur-[50px] -z-10" animate={{ scale: [1, 1.4, 1], opacity: [0.2, 0.5, 0.2] }} transition={{ duration: 4, repeat: Infinity }} />
          <div className="w-32 h-32 sm:w-40 sm:h-40 rounded-[28px] bg-gradient-to-br from-cent-400 via-cent-500 to-cent-700 flex items-center justify-center shadow-2xl shadow-cent-500/40 mx-auto relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-white/25 via-transparent to-transparent" />
            <Music className="w-16 h-16 sm:w-20 sm:h-20 text-white relative z-10 drop-shadow-lg" />
          </div>
        </motion.div>

        <motion.h1 initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
          className="text-7xl sm:text-9xl md:text-[11rem] font-display font-black tracking-tighter mb-4 leading-none">
          <span className="text-gradient animate-text-glow">CENT</span>
        </motion.h1>

        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }} className="text-lg sm:text-2xl text-white/40 font-light mb-4 tracking-wide">
          Global AI Music Platform
        </motion.p>
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6 }} className="text-xs sm:text-sm text-white/15 max-w-2xl mx-auto leading-relaxed px-4">
          Next-generation music streaming powered by artificial intelligence. Discover, stream, recognize, and experience music like never before — available in 195 countries worldwide.
        </motion.p>

        <motion.div initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ delay: 0.7, duration: 0.8 }} className="w-32 h-px bg-gradient-to-r from-transparent via-cent-400/50 to-transparent mx-auto mt-10" />

        {/* Stats */}
        <div className="grid grid-cols-3 lg:grid-cols-6 gap-3 mt-14 max-w-5xl mx-auto">
          {STATS.map((stat, i) => (
            <motion.div key={stat.label} initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 + i * 0.08 }} whileHover={{ y: -4 }}
              className="glass rounded-2xl p-4 sm:p-5 cursor-default">
              <stat.icon className="w-5 h-5 mx-auto mb-2" style={{ color: stat.color }} />
              <p className="text-xl sm:text-3xl font-black text-white">{stat.value}</p>
              <p className="text-[9px] sm:text-[10px] text-white/25 uppercase tracking-wider">{stat.label}</p>
            </motion.div>
          ))}
        </div>
      </motion.section>


      {/* ═══ FOUNDERS ═══ */}
      <section>
        <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-14">
          <h2 className="text-4xl sm:text-6xl font-display font-bold text-white mb-4">Meet the <span className="text-gradient">Founders</span></h2>
          <p className="text-white/20 text-sm sm:text-base">The visionaries building the future of music</p>
        </motion.div>

        <div className="flex flex-col md:flex-row items-stretch justify-center gap-6 sm:gap-8 max-w-4xl mx-auto">
          {FOUNDERS.map((f, i) => (
            <motion.div key={f.handle} initial={{ opacity: 0, y: 60 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 + i * 0.25, duration: 0.8 }}
              whileHover={{ y: -8 }} className="relative w-full md:w-[400px] group">
              <motion.div className={`absolute -inset-1 rounded-[28px] bg-gradient-to-br ${f.gradient} opacity-0 group-hover:opacity-20 blur-xl transition-opacity duration-700 -z-10`} />
              <div className={`relative rounded-[24px] overflow-hidden bg-gradient-to-br ${f.bgGradient} border border-white/[0.06] group-hover:border-white/[0.12] transition-all duration-500`}>
                <div className="absolute inset-0 backdrop-blur-xl" />
                <div className="relative z-10 p-7 sm:p-10">
                  {/* Avatar */}
                  <div className="relative mx-auto mb-7 w-32 h-32 sm:w-40 sm:h-40">
                    <motion.div className={`absolute -inset-3 rounded-full bg-gradient-to-br ${f.gradient} opacity-20 group-hover:opacity-50 transition-opacity`}
                      animate={{ rotate: 360 }} transition={{ duration: 20, repeat: Infinity, ease: 'linear' }} />
                    <div className="relative w-full h-full rounded-full overflow-hidden ring-[3px] ring-white/10 shadow-2xl">
                      <img src={f.avatar} alt={f.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                    </div>
                    <div className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-emerald-400 border-[3px] border-surface flex items-center justify-center">
                      <CheckCircle2 className="w-4 h-4 text-white" />
                    </div>
                  </div>

                  <div className="text-center">
                    <h3 className="text-2xl font-bold text-white mb-1">{f.name}</h3>
                    <p className="text-sm font-semibold mb-4" style={{ color: f.color }}>{f.role}</p>
                    <p className="text-xs text-white/30 leading-relaxed mb-6">{f.bio}</p>

                    <div className="flex flex-wrap gap-1.5 justify-center mb-8">
                      {f.skills.map(s => (
                        <span key={s} className="px-3 py-1 rounded-full bg-white/[0.04] border border-white/[0.06] text-[10px] text-white/40 font-medium">{s}</span>
                      ))}
                    </div>

                    {/* INSTAGRAM BUTTON - Large & Clear */}
                    <a href={f.url} target="_blank" rel="noopener noreferrer" className="block">
                      <motion.div whileHover={{ scale: 1.06, y: -2 }} whileTap={{ scale: 0.95 }}
                        className="relative flex items-center justify-center gap-3 py-5 px-8 rounded-2xl overflow-hidden shadow-2xl cursor-pointer group/btn"
                        style={{ background: 'linear-gradient(45deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888)' }}>
                        <div className="absolute inset-0 bg-gradient-to-br from-white/15 via-transparent to-transparent" />
                        <div className="absolute inset-0 bg-black/0 group-hover/btn:bg-black/5 transition-colors" />
                        <IGIcon size={32} />
                        <span className="text-xl font-black text-white tracking-wider relative z-10 drop-shadow-lg">{f.handle}</span>
                        <ExternalLink className="w-5 h-5 text-white/90 relative z-10" />
                      </motion.div>
                    </a>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1 }} className="text-center mt-10 text-xs text-white/15">
          Follow us on Instagram for updates & behind-the-scenes 📸
        </motion.p>
      </section>


      {/* ═══ TIMELINE ═══ */}
      <section>
        <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-14">
          <h2 className="text-4xl sm:text-6xl font-display font-bold text-white mb-4">Our <span className="text-gradient">Journey</span></h2>
          <p className="text-white/20 text-sm">From idea to $50M funded platform</p>
        </motion.div>

        <div className="relative max-w-2xl mx-auto">
          <div className="absolute left-6 sm:left-8 top-0 bottom-0 w-px bg-gradient-to-b from-cent-400/30 via-cent-400/10 to-transparent" />
          <div className="space-y-6">
            {MILESTONES.map((m, i) => (
              <motion.div key={m.year} initial={{ opacity: 0, x: -30 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 + i * 0.08 }}
                className="flex items-start gap-4 sm:gap-6 pl-1">
                <div className="relative flex-shrink-0">
                  <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl bg-gradient-to-br from-cent-400/10 to-cent-600/10 border border-cent-400/20 flex items-center justify-center relative z-10 backdrop-blur-sm">
                    <m.icon className="w-5 h-5 text-cent-400" />
                  </div>
                </div>
                <div className="pt-2">
                  <p className="text-xs font-bold text-cent-400 mb-1">{m.year}</p>
                  <p className="text-sm text-white/60">{m.event}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>


      {/* ═══ FEATURES ═══ */}
      <section>
        <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-14">
          <h2 className="text-4xl sm:text-6xl font-display font-bold text-white mb-4">Platform <span className="text-gradient">Features</span></h2>
          <p className="text-white/20 text-sm">Enterprise-grade technology, consumer-grade experience</p>
        </motion.div>
        <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4">
          {FEATURES.map((f, i) => (
            <motion.div key={f.title} initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 + i * 0.04 }}
              whileHover={{ y: -6 }} className="glass rounded-2xl p-5 sm:p-6 hover-lift group relative overflow-hidden cursor-default">
              <div className="absolute -top-8 -right-8 w-24 h-24 rounded-full blur-3xl opacity-0 group-hover:opacity-15 transition-opacity duration-700" style={{ background: f.color }} />
              <div className="relative z-10">
                <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-xl flex items-center justify-center mb-3 sm:mb-4" style={{ background: f.color + '12' }}>
                  <f.icon className="w-5 h-5 sm:w-6 sm:h-6" style={{ color: f.color }} />
                </div>
                <h3 className="text-sm sm:text-base font-bold text-white mb-1">{f.title}</h3>
                <p className="text-[10px] sm:text-xs text-white/25 leading-relaxed">{f.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>


      {/* ═══ ARCHITECTURE ═══ */}
      <section>
        <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-14">
          <h2 className="text-4xl sm:text-6xl font-display font-bold text-white mb-4">System <span className="text-gradient">Architecture</span></h2>
        </motion.div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 mb-8">
          {([
            { icon: Monitor, label: 'Web App', detail: 'Next.js 14 SSR', color: '#7a5af8' },
            { icon: Smartphone, label: 'Mobile', detail: 'React Native', color: '#ec4899' },
            { icon: Server, label: 'API Gateway', detail: 'NestJS + GraphQL', color: '#3b82f6' },
            { icon: Cpu, label: 'ML Service', detail: 'FastAPI + ONNX', color: '#f59e0b' },
            { icon: Database, label: 'Database', detail: 'PostgreSQL + pgvector', color: '#10b981' },
            { icon: Disc3, label: 'Cache', detail: 'Redis Cluster', color: '#ef4444' },
            { icon: Cloud, label: 'Storage', detail: 'S3 + CloudFront', color: '#06b6d4' },
            { icon: Lock, label: 'Security', detail: 'JWT + DRM + RBAC', color: '#8b5cf6' },
          ]).map((a, i) => (
            <motion.div key={a.label} initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.1 + i * 0.06 }}
              whileHover={{ y: -4 }} className="glass rounded-2xl p-4 sm:p-6 text-center hover-lift cursor-default">
              <div className="w-14 h-14 rounded-2xl mx-auto mb-3 flex items-center justify-center" style={{ background: a.color + '12' }}>
                <a.icon className="w-7 h-7" style={{ color: a.color }} />
              </div>
              <p className="text-sm font-bold text-white">{a.label}</p>
              <p className="text-[10px] text-white/20 mt-1">{a.detail}</p>
            </motion.div>
          ))}
        </div>

        {/* Data Flow */}
        <div className="glass rounded-2xl p-6 text-center">
          <p className="text-xs text-white/20 uppercase tracking-wider mb-4">Request Flow</p>
          <div className="flex items-center justify-center gap-2 flex-wrap text-xs text-white/40">
            {['Client', '→', 'CDN Edge', '→', 'API Gateway', '→', 'Auth + RBAC', '→', 'Service Mesh', '→', 'Database / Cache', '→', 'Response'].map((item, i) => (
              <span key={i} className={item === '→' ? 'text-cent-400' : 'px-3 py-1.5 rounded-lg bg-white/[0.04] border border-white/[0.06] font-mono'}>{item}</span>
            ))}
          </div>
        </div>
      </section>


      {/* ═══ TECH STACK ═══ */}
      <section>
        <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-14">
          <h2 className="text-4xl sm:text-6xl font-display font-bold text-white mb-4">Tech <span className="text-gradient">Stack</span></h2>
        </motion.div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {TECH.map((t, i) => (
            <motion.div key={t.cat} initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 + i * 0.1 }} className="glass rounded-2xl p-6">
              <div className="flex items-center gap-3 mb-5">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: t.color + '12' }}>
                  <t.icon className="w-5 h-5" style={{ color: t.color }} />
                </div>
                <h3 className="text-sm font-bold text-white uppercase tracking-wider">{t.cat}</h3>
              </div>
              <div className="space-y-2">
                {t.items.map(item => (
                  <div key={item} className="flex items-center gap-2 text-xs text-white/35">
                    <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: t.color + '60' }} />
                    {item}
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </section>


      {/* ═══ DATABASE ═══ */}
      <section>
        <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-14">
          <h2 className="text-4xl sm:text-6xl font-display font-bold text-white mb-4">Database <span className="text-gradient">Schema</span></h2>
          <p className="text-white/20 text-sm">PostgreSQL with pgvector extension for ML embeddings</p>
        </motion.div>
        <div className="glass rounded-2xl p-4 sm:p-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {DB_TABLES.map((s, i) => (
              <motion.div key={s.table} initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.05 + i * 0.04 }}
                className="bg-white/[0.02] rounded-xl p-4 hover:bg-white/[0.04] transition-all border border-transparent hover:border-white/5">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-7 h-7 rounded-md flex items-center justify-center" style={{ background: s.color + '15' }}>
                    <Database className="w-3.5 h-3.5" style={{ color: s.color }} />
                  </div>
                  <p className="text-sm font-bold" style={{ color: s.color }}>{s.table}</p>
                </div>
                <div className="space-y-1">
                  {s.fields.map(f => (
                    <p key={f} className="text-[10px] text-white/20 font-mono pl-3 border-l border-white/5 py-0.5">
                      {f.includes('PK') ? `🔑 ${f}` : f.includes('FK') ? `🔗 ${f}` : f}
                    </p>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>


      {/* ═══ WHY CENT ═══ */}
      <section>
        <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-14">
          <h2 className="text-4xl sm:text-6xl font-display font-bold text-white mb-4">Why <span className="text-gradient">CENT</span>?</h2>
        </motion.div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {[
            { title: 'For Listeners', desc: 'AI-powered discovery, spatial audio, personalized daily mixes, offline mode, and lossless quality. Music that truly understands you.', icon: Headphones, gradient: 'from-violet-500/10 to-purple-600/5', color: '#7a5af8' },
            { title: 'For Artists', desc: 'Reach 50M+ listeners globally with real-time analytics, fair transparent revenue sharing, promotional tools, and direct fan engagement.', icon: Music, gradient: 'from-pink-500/10 to-rose-600/5', color: '#ec4899' },
            { title: 'For the Future', desc: 'AI recognition, blockchain royalties, immersive 3D audio, cross-platform sync, and open developer APIs. The future is here.', icon: TrendingUp, gradient: 'from-blue-500/10 to-cyan-600/5', color: '#3b82f6' },
          ].map((item, i) => (
            <motion.div key={item.title} initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 + i * 0.12 }}
              whileHover={{ y: -6 }} className={`relative rounded-3xl p-8 sm:p-10 bg-gradient-to-br ${item.gradient} border border-white/5 hover:border-white/10 transition-all group overflow-hidden`}>
              <div className="relative z-10">
                <div className="w-14 h-14 rounded-2xl flex items-center justify-center mb-6" style={{ background: item.color + '12' }}>
                  <item.icon className="w-7 h-7" style={{ color: item.color }} />
                </div>
                <h3 className="text-xl sm:text-2xl font-bold text-white mb-3">{item.title}</h3>
                <p className="text-xs sm:text-sm text-white/30 leading-relaxed">{item.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>


      {/* ═══ SECURITY ═══ */}
      <section>
        <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-10">
          <h2 className="text-4xl sm:text-5xl font-display font-bold text-white mb-4">Security & <span className="text-gradient">Compliance</span></h2>
        </motion.div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {[
            { label: 'JWT Rotation', icon: Lock },
            { label: 'DRM Encryption', icon: Shield },
            { label: 'Rate Limiting', icon: Target },
            { label: 'CSRF Protection', icon: Eye },
            { label: 'Device Fingerprint', icon: Smartphone },
            { label: 'RBAC Policies', icon: Users },
          ].map((s, i) => (
            <motion.div key={s.label} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 + i * 0.05 }}
              className="glass rounded-xl p-4 text-center cursor-default">
              <s.icon className="w-5 h-5 text-cent-400 mx-auto mb-2" />
              <p className="text-[10px] text-white/40 font-medium">{s.label}</p>
            </motion.div>
          ))}
        </div>
      </section>


      {/* ═══ FOOTER ═══ */}
      <section className="text-center pt-12">
        <div className="w-full h-px bg-gradient-to-r from-transparent via-white/8 to-transparent mb-16" />

        <div className="flex items-center justify-center gap-4 mb-8">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-cent-400 to-cent-600 flex items-center justify-center shadow-lg shadow-cent-500/30">
            <Music className="w-7 h-7 text-white" />
          </div>
          <span className="font-display text-4xl font-black text-gradient">CENT</span>
        </div>

        <p className="text-base text-white/25 mb-10">The future of music is here.</p>

        {/* Instagram Links */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12 px-4">
          <motion.a href="https://www.instagram.com/cx0hl?igsh=dGx1dXZ1anhuajRl" target="_blank" rel="noopener noreferrer"
            whileHover={{ scale: 1.08, y: -3 }} whileTap={{ scale: 0.95 }}
            className="w-full sm:w-auto flex items-center justify-center gap-3 px-8 py-4 rounded-2xl cursor-pointer group relative overflow-hidden"
            style={{ background: 'linear-gradient(45deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888)' }}>
            <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors" />
            <IGIcon size={22} />
            <span className="text-sm font-bold text-white relative z-10">@cx0hl</span>
            <ExternalLink className="w-3.5 h-3.5 text-white/70 relative z-10" />
          </motion.a>

          <motion.a href="https://www.instagram.com/vkz7t?igsh=MTc1cjJjbm1tMHh5cg==" target="_blank" rel="noopener noreferrer"
            whileHover={{ scale: 1.08, y: -3 }} whileTap={{ scale: 0.95 }}
            className="w-full sm:w-auto flex items-center justify-center gap-3 px-8 py-4 rounded-2xl cursor-pointer group relative overflow-hidden"
            style={{ background: 'linear-gradient(45deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888)' }}>
            <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors" />
            <IGIcon size={22} />
            <span className="text-sm font-bold text-white relative z-10">@vkz7t</span>
            <ExternalLink className="w-3.5 h-3.5 text-white/70 relative z-10" />
          </motion.a>
        </div>

        <p className="text-xs text-white/10 mb-2">© 2025 CENT Music Technologies Inc. All rights reserved.</p>
        <p className="text-[10px] text-white/[0.06] tracking-[0.3em] uppercase mb-8">Enterprise Grade · Scalable · Secure · Global · v8.0.0</p>
        <div className="flex items-center justify-center gap-1.5">
          <span className="text-[10px] text-white/10">Made with</span>
          <Heart className="w-3 h-3 text-cent-400 fill-cent-400" />
          <span className="text-[10px] text-white/10">for the world</span>
        </div>
      </section>
    </div>
  );
}
