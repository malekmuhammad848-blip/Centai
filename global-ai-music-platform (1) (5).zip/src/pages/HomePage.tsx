import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Play, TrendingUp, Clock, Sparkles, ChevronRight, Headphones, Radio, Flame, Music2, Zap, Heart, Music, Crown, Disc3, Youtube, Brain, Eye } from 'lucide-react';
import { useStore } from '../store/useStore';
import { TRACKS, PLAYLISTS, ARTISTS, MOODS, formatNumber } from '../data/mock';
import { TrackCard } from '../components/TrackCard';
import { getYouTubeTrending, formatViewCount, type YouTubeVideo } from '../services/youtube';

/* ============ HERO ============ */
function HeroSection() {
  const { setCurrentTrack, setIsPlaying } = useStore();
  const [activeIndex, setActiveIndex] = useState(0);
  const featured = [TRACKS[5], TRACKS[0], TRACKS[7]];
  const track = featured[activeIndex];

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveIndex(i => (i + 1) % featured.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [featured.length]);

  return (
    <motion.section
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="relative rounded-3xl overflow-hidden mb-10"
    >
      {/* Background layers */}
      <div className="absolute inset-0">
        <AnimatePresence mode="wait">
          <motion.img
            key={track.id}
            src={track.cover}
            alt=""
            className="w-full h-full object-cover"
            initial={{ scale: 1.2, opacity: 0 }}
            animate={{ scale: 1.05, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            transition={{ duration: 1.2 }}
          />
        </AnimatePresence>
        <div className="absolute inset-0 bg-gradient-to-r from-black/95 via-black/75 to-black/30" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-black/40" />
        <div className="absolute inset-0" style={{
          background: `radial-gradient(ellipse at 20% 80%, ${track.color}30, transparent 60%)`
        }} />
      </div>

      <div className="relative p-5 sm:p-6 md:p-10 lg:p-14 min-h-[280px] sm:min-h-[360px] md:min-h-[480px] flex flex-col justify-end">
        <AnimatePresence mode="wait">
          <motion.div
            key={track.id}
            initial={{ y: 50, opacity: 0, filter: 'blur(8px)' }}
            animate={{ y: 0, opacity: 1, filter: 'blur(0px)' }}
            exit={{ y: -30, opacity: 0, filter: 'blur(4px)' }}
            transition={{ duration: 0.7, ease: 'easeOut' }}
          >
            <div className="flex items-center gap-2 mb-5">
              <span className="px-3 py-1.5 rounded-full bg-white/10 backdrop-blur-sm border border-white/10 text-white text-[11px] font-semibold flex items-center gap-1.5">
                <Sparkles className="w-3 h-3 text-cent-400" /> Featured
              </span>
              <span className="px-3 py-1.5 rounded-full bg-white/5 text-white/50 text-[11px]">{track.genre}</span>
              <span className="px-3 py-1.5 rounded-full bg-white/5 text-white/50 text-[11px] flex items-center gap-1">
                <Headphones className="w-3 h-3" /> {formatNumber(track.plays)}
              </span>
            </div>

            <h1 className="text-3xl sm:text-4xl md:text-6xl lg:text-8xl font-display font-black text-white mb-2 sm:mb-3 leading-[0.95] tracking-tight">
              {track.title}
            </h1>
            <p className="text-sm sm:text-lg md:text-xl text-white/50 mb-5 sm:mb-8 font-light">
              {track.artist} <span className="text-white/15 mx-2">·</span> {track.album}
            </p>

            <div className="flex items-center gap-3">
              <motion.button
                whileHover={{ scale: 1.04 }}
                whileTap={{ scale: 0.96 }}
                onClick={() => { setCurrentTrack(track); setIsPlaying(true); }}
                className="flex items-center gap-2 sm:gap-2.5 px-5 sm:px-8 py-3 sm:py-4 rounded-full bg-white text-black font-bold text-xs sm:text-sm shadow-2xl shadow-white/10 hover:shadow-white/20 transition-shadow"
              >
                <Play className="w-4 h-4 sm:w-5 sm:h-5 fill-black" /> Play Now
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.04 }}
                whileTap={{ scale: 0.96 }}
                className="flex items-center gap-2 px-4 sm:px-6 py-3 sm:py-4 rounded-full glass text-white font-medium text-xs sm:text-sm border-white/10"
              >
                <Radio className="w-4 h-4" /> Radio
              </motion.button>
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Dots */}
        <div className="absolute bottom-6 right-6 md:bottom-10 md:right-10 flex gap-2">
          {featured.map((_, i) => (
            <button
              key={i}
              onClick={() => setActiveIndex(i)}
              className={`h-1.5 rounded-full transition-all duration-500 ${
                i === activeIndex ? 'w-10 bg-white' : 'w-1.5 bg-white/20 hover:bg-white/40'
              }`}
            />
          ))}
        </div>
      </div>
    </motion.section>
  );
}

/* ============ WELCOME BANNER ============ */
function WelcomeBanner() {
  const hours = new Date().getHours();
  const greeting = hours < 12 ? 'Good Morning' : hours < 18 ? 'Good Afternoon' : 'Good Evening';
  
  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex items-center justify-between mb-8"
    >
      <div>
        <h2 className="text-2xl md:text-3xl font-bold text-white">{greeting} 👋</h2>
        <p className="text-sm text-white/30 mt-1">Here's what's trending on CENT today</p>
      </div>
      <div className="hidden md:flex items-center gap-2">
        <div className="flex items-center gap-2 px-4 py-2 rounded-full glass">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-xs text-white/40">142K listening now</span>
        </div>
      </div>
    </motion.div>
  );
}

/* ============ QUICK PICKS ============ */
function QuickPicks() {
  const { setCurrentTrack, setIsPlaying } = useStore();
  
  return (
    <section className="mb-10">
      <h2 className="text-xl font-bold text-white mb-5 flex items-center gap-2">
        <Zap className="w-5 h-5 text-cent-400" /> Quick Picks
      </h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2.5">
        {TRACKS.slice(0, 8).map((track, i) => (
          <motion.button
            key={track.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.04 }}
            whileHover={{ scale: 1.02, backgroundColor: 'rgba(255,255,255,0.06)' }}
            onClick={() => { setCurrentTrack(track); setIsPlaying(true); }}
            className="flex items-center gap-3 p-2.5 rounded-xl bg-white/[0.02] hover:bg-white/[0.05] transition-all group border border-transparent hover:border-white/5"
          >
            <img src={track.cover} alt="" className="w-12 h-12 rounded-lg object-cover shadow-md group-hover:shadow-lg transition-shadow" />
            <div className="flex-1 min-w-0 text-left">
              <p className="text-sm font-semibold text-white truncate">{track.title}</p>
              <p className="text-[11px] text-white/25 truncate">{track.artist}</p>
            </div>
            <div className="opacity-0 group-hover:opacity-100 transition-opacity mr-1">
              <div className="w-8 h-8 rounded-full bg-cent-500 flex items-center justify-center shadow-lg shadow-cent-500/30">
                <Play className="w-3.5 h-3.5 text-white fill-white ml-0.5" />
              </div>
            </div>
          </motion.button>
        ))}
      </div>
    </section>
  );
}

/* ============ MOODS ============ */
function MoodSection() {
  return (
    <section className="mb-10">
      <h2 className="text-xl font-bold text-white mb-5 flex items-center gap-2">
        <Sparkles className="w-5 h-5 text-cent-400" /> Mood Playlists
      </h2>
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
        {MOODS.map((mood, i) => (
          <motion.button
            key={mood.name}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.06 }}
            whileHover={{ scale: 1.08, y: -4 }}
            whileTap={{ scale: 0.95 }}
            className={`relative p-5 md:p-6 rounded-2xl bg-gradient-to-br ${mood.gradient} flex flex-col items-center gap-2 shadow-lg overflow-hidden group`}
          >
            <div className="absolute inset-0 bg-black/10 group-hover:bg-black/0 transition-colors" />
            <span className="text-3xl md:text-4xl relative z-10 drop-shadow-lg group-hover:scale-110 transition-transform">{mood.emoji}</span>
            <span className="text-xs font-bold text-white relative z-10 drop-shadow">{mood.name}</span>
          </motion.button>
        ))}
      </div>
    </section>
  );
}

/* ============ PLAYLISTS ============ */
function PlaylistSection() {
  const { setPage, setSelectedPlaylist } = useStore();
  return (
    <section className="mb-10">
      <div className="flex items-center justify-between mb-5">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <Music2 className="w-5 h-5 text-cent-400" /> Made For You
        </h2>
        <button className="text-sm text-cent-400 flex items-center gap-1 hover:gap-2 transition-all font-medium">
          See All <ChevronRight className="w-4 h-4" />
        </button>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-4">
        {PLAYLISTS.map((pl, i) => (
          <motion.div
            key={pl.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.08 }}
            whileHover={{ y: -6 }}
            className="cursor-pointer group"
            onClick={() => { setSelectedPlaylist(pl); setPage('playlist'); }}
          >
            <div className={`relative aspect-square rounded-2xl overflow-hidden mb-3 bg-gradient-to-br ${pl.gradient} shadow-lg group-hover:shadow-xl group-hover:shadow-cent-500/10 transition-all`}>
              <img src={pl.cover} alt="" className="absolute inset-0 w-full h-full object-cover opacity-30 group-hover:opacity-40 transition-opacity mix-blend-overlay scale-110" />
              <div className="absolute inset-0 flex flex-col justify-end p-4">
                <p className="text-base font-bold text-white drop-shadow-lg">{pl.name}</p>
                <p className="text-[11px] text-white/60 mt-0.5">{pl.trackCount} tracks</p>
              </div>
              <motion.div className="absolute bottom-3 right-3 w-10 h-10 rounded-full bg-white shadow-xl flex items-center justify-center opacity-0 group-hover:opacity-100 translate-y-3 group-hover:translate-y-0 transition-all duration-300">
                <Play className="w-4 h-4 text-black fill-black ml-0.5" />
              </motion.div>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

/* ============ TRENDING ============ */
function TrendingSection() {
  return (
    <section className="mb-10">
      <div className="flex items-center justify-between mb-5">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <Flame className="w-5 h-5 text-orange-400" /> Trending Now
        </h2>
        <button className="text-sm text-cent-400 flex items-center gap-1 hover:gap-2 transition-all font-medium">
          See All <ChevronRight className="w-4 h-4" />
        </button>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
        {TRACKS.slice(0, 6).map((track, i) => (
          <TrackCard key={track.id} track={track} index={i} />
        ))}
      </div>
    </section>
  );
}

/* ============ TOP ARTISTS ============ */
function TopArtists() {
  const { setSelectedArtist, setPage } = useStore();
  return (
    <section className="mb-10">
      <div className="flex items-center justify-between mb-5">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-cent-400" /> Popular Artists
        </h2>
      </div>
      <div className="flex gap-5 overflow-x-auto pb-4 no-scrollbar">
        {ARTISTS.map((artist, i) => (
          <motion.div
            key={artist.id}
            initial={{ opacity: 0, scale: 0.85 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.06 }}
            whileHover={{ y: -6 }}
            className="flex-shrink-0 cursor-pointer text-center group"
            onClick={() => { setSelectedArtist(artist); setPage('artist'); }}
          >
            <div className="relative">
              <motion.div
                className="absolute -inset-1 rounded-full bg-gradient-to-br from-cent-400/20 to-accent-pink/20 opacity-0 group-hover:opacity-100 blur-lg transition-opacity duration-500"
              />
              <div className="relative w-28 h-28 md:w-36 md:h-36 rounded-full overflow-hidden ring-2 ring-white/5 group-hover:ring-cent-400/50 transition-all duration-500 shadow-xl">
                <img src={artist.image} alt={artist.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
              </div>
              <div className="absolute bottom-1 right-1 w-5 h-5 rounded-full bg-green-400 border-2 border-surface shadow-sm" />
            </div>
            <p className="text-sm font-semibold text-white mt-3">{artist.name}</p>
            <p className="text-[11px] text-white/25">{formatNumber(artist.followers)}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

/* ============ NEW RELEASES ============ */
function NewReleasesBanner() {
  const { setCurrentTrack, setIsPlaying } = useStore();
  const track = TRACKS[3];

  return (
    <section className="mb-10">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        whileHover={{ scale: 1.005 }}
        className="relative rounded-3xl overflow-hidden cursor-pointer group"
        onClick={() => { setCurrentTrack(track); setIsPlaying(true); }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-cent-600/20 via-accent-pink/15 to-accent-blue/20 animate-gradient" />
        <div className="absolute inset-0 glass" />
        <div className="relative flex items-center gap-6 p-6 md:p-8">
          <div className="w-20 h-20 md:w-24 md:h-24 rounded-2xl overflow-hidden shadow-2xl flex-shrink-0 group-hover:shadow-cent-500/20 transition-shadow">
            <img src={track.cover} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
          </div>
          <div className="flex-1 min-w-0">
            <span className="text-[11px] text-cent-400 font-semibold uppercase tracking-wider">New Release</span>
            <h3 className="text-xl md:text-2xl font-bold text-white mt-1">{track.title}</h3>
            <p className="text-sm text-white/35">{track.artist} · {track.album}</p>
          </div>
          <motion.div
            className="w-14 h-14 rounded-full bg-white flex items-center justify-center shadow-xl opacity-80 group-hover:opacity-100 transition-opacity flex-shrink-0"
            whileHover={{ scale: 1.1 }}
          >
            <Play className="w-6 h-6 text-black fill-black ml-0.5" />
          </motion.div>
        </div>
      </motion.div>
    </section>
  );
}

/* ============ TOP CHARTS ============ */
function TopCharts() {
  const { setCurrentTrack, setIsPlaying, favorites, toggleFavorite } = useStore();
  const topTracks = [...TRACKS].sort((a, b) => b.plays - a.plays).slice(0, 5);

  return (
    <section className="mb-10">
      <div className="flex items-center justify-between mb-5">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <Crown className="w-5 h-5 text-yellow-400" /> Top Charts
        </h2>
      </div>
      <div className="glass rounded-2xl overflow-hidden">
        {topTracks.map((track, i) => (
          <motion.div
            key={track.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.06 }}
            className="flex items-center gap-4 p-4 hover:bg-white/[0.03] transition-colors cursor-pointer border-b border-white/[0.03] last:border-0 group"
            onClick={() => { setCurrentTrack(track); setIsPlaying(true); }}
          >
            <span className={`text-2xl font-black w-8 text-center ${i === 0 ? 'text-yellow-400' : i === 1 ? 'text-gray-400' : i === 2 ? 'text-amber-600' : 'text-white/15'}`}>
              {i + 1}
            </span>
            <div className={`w-1 h-8 rounded-full ${i === 0 ? 'bg-yellow-400' : i === 1 ? 'bg-gray-400' : i === 2 ? 'bg-amber-600' : 'bg-white/10'}`} />
            <div className="relative w-12 h-12 rounded-xl overflow-hidden flex-shrink-0">
              <img src={track.cover} alt="" className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <Play className="w-4 h-4 text-white fill-white ml-0.5" />
              </div>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-white truncate">{track.title}</p>
              <p className="text-xs text-white/30 truncate">{track.artist}</p>
            </div>
            <div className="hidden sm:flex items-center gap-3">
              <span className="text-xs text-white/20 font-mono">{formatNumber(track.plays)} plays</span>
              <button
                onClick={(e) => { e.stopPropagation(); toggleFavorite(track.id); }}
                className="opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <Heart className={`w-4 h-4 ${favorites.includes(track.id) ? 'fill-cent-400 text-cent-400' : 'text-white/20'}`} />
              </button>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

/* ============ RECENTLY PLAYED ============ */
function RecentlyPlayed() {
  return (
    <section className="mb-10">
      <div className="flex items-center justify-between mb-5">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <Clock className="w-5 h-5 text-cent-400" /> Recently Played
        </h2>
      </div>
      <div className="glass rounded-2xl overflow-hidden divide-y divide-white/[0.03]">
        {TRACKS.slice(6, 12).map((track, i) => (
          <TrackCard key={track.id} track={track} index={i} variant="list" />
        ))}
      </div>
    </section>
  );
}

/* ============ CENT BRAND BANNER ============ */
function CentBanner() {
  const { setPage } = useStore();
  return (
    <section className="mb-10">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative rounded-3xl overflow-hidden"
      >
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-br from-cent-700 via-cent-600 to-cent-800 animate-gradient" />
          <motion.div
            className="absolute w-[300px] h-[300px] rounded-full bg-accent-pink/20 blur-[100px] -top-20 -right-20"
            animate={{ x: [0, 30, -20, 0], y: [0, -20, 10, 0] }}
            transition={{ duration: 10, repeat: Infinity }}
          />
          <motion.div
            className="absolute w-[200px] h-[200px] rounded-full bg-accent-blue/20 blur-[80px] -bottom-10 -left-10"
            animate={{ x: [0, -20, 10, 0], y: [0, 10, -10, 0] }}
            transition={{ duration: 8, repeat: Infinity }}
          />
        </div>
        
        <div className="relative p-8 md:p-12 flex flex-col md:flex-row items-center gap-6">
          <div className="flex-1 text-center md:text-left">
            <div className="flex items-center gap-3 justify-center md:justify-start mb-4">
              <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center">
                <Music className="w-6 h-6 text-white" />
              </div>
              <span className="font-display text-3xl font-black text-white tracking-tight">CENT</span>
              <span className="px-2 py-0.5 rounded-full bg-white/15 text-[10px] text-white font-bold">PRO</span>
            </div>
            <p className="text-sm text-white/50 mb-6 max-w-md">
              Unlock unlimited skips, offline mode, spatial audio, hi-fi lossless quality, and AI-powered discovery.
            </p>
            <div className="flex items-center gap-3 justify-center md:justify-start">
              <button className="px-6 py-3 rounded-full bg-white text-cent-700 font-bold text-sm shadow-lg hover:shadow-xl transition-shadow">
                Get Premium
              </button>
              <button onClick={() => setPage('about')} className="px-6 py-3 rounded-full bg-white/10 text-white font-medium text-sm hover:bg-white/15 transition-colors">
                Learn More
              </button>
            </div>
          </div>
          <div className="flex-shrink-0">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 30, repeat: Infinity, ease: 'linear' }}
              className="w-32 h-32 md:w-40 md:h-40 rounded-full bg-gradient-to-br from-white/10 to-white/5 flex items-center justify-center"
            >
              <Disc3 className="w-16 h-16 md:w-20 md:h-20 text-white/30" />
            </motion.div>
          </div>
        </div>
      </motion.div>
    </section>
  );
}

/* ============ CENT FEATURES CARDS ============ */
function FeaturesQuickAccess() {
  const { setPage } = useStore();
  
  return (
    <section className="mb-10">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* YouTube Music Card */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          whileHover={{ scale: 1.02, y: -3 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => setPage('youtube')}
          className="relative rounded-2xl overflow-hidden cursor-pointer group"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-red-600/15 to-red-900/15" />
          <div className="absolute inset-0 glass" />
          <div className="relative flex items-center gap-4 p-5">
            <div className="w-12 h-12 rounded-xl bg-red-500/15 flex items-center justify-center flex-shrink-0 group-hover:bg-red-500/25 transition-colors">
              <Youtube className="w-6 h-6 text-red-500" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-sm font-bold text-white">YouTube Music</h3>
              <p className="text-[10px] text-white/30">ابحث وشاهد ملايين الفيديوهات الموسيقية</p>
            </div>
            <ChevronRight className="w-4 h-4 text-white/15 group-hover:text-white/30 group-hover:translate-x-1 transition-all" />
          </div>
        </motion.div>

        {/* Search with YouTube Card */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          whileHover={{ scale: 1.02, y: -3 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => setPage('search')}
          className="relative rounded-2xl overflow-hidden cursor-pointer group"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-emerald-600/15 to-emerald-900/15" />
          <div className="absolute inset-0 glass" />
          <div className="relative flex items-center gap-4 p-5">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/15 flex items-center justify-center flex-shrink-0 group-hover:bg-emerald-500/25 transition-colors">
              <Music2 className="w-6 h-6 text-emerald-400" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-sm font-bold text-white">Smart Search</h3>
              <p className="text-[10px] text-white/30">بحث موحّد: أغاني CENT + YouTube</p>
            </div>
            <ChevronRight className="w-4 h-4 text-white/15 group-hover:text-white/30 group-hover:translate-x-1 transition-all" />
          </div>
        </motion.div>

        {/* AI Chat Card */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          whileHover={{ scale: 1.02, y: -3 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => setPage('aichat')}
          className="relative rounded-2xl overflow-hidden cursor-pointer group"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-cent-600/15 to-cent-900/15" />
          <div className="absolute inset-0 glass" />
          <div className="relative flex items-center gap-4 p-5">
            <div className="w-12 h-12 rounded-xl bg-cent-500/15 flex items-center justify-center flex-shrink-0 group-hover:bg-cent-500/25 transition-colors">
              <Brain className="w-6 h-6 text-cent-400" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-sm font-bold text-white">CENT AI</h3>
              <p className="text-[10px] text-white/30">مساعد الموسيقى الذكي بالذكاء الاصطناعي</p>
            </div>
            <ChevronRight className="w-4 h-4 text-white/15 group-hover:text-white/30 group-hover:translate-x-1 transition-all" />
          </div>
        </motion.div>
      </div>
    </section>
  );
}

/* ============ YOUTUBE TRENDING ON HOME ============ */
function YouTubeTrending() {
  const [videos, setVideos] = useState<YouTubeVideo[]>([]);
  const [loading, setLoading] = useState(true);
  const [playingId, setPlayingId] = useState<string | null>(null);
  const { setPage } = useStore();

  const loadTrending = useCallback(async () => {
    setLoading(true);
    try {
      const data = await getYouTubeTrending(8);
      setVideos(data);
    } catch {
      // silently fail — fallback UI shown
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadTrending(); }, [loadTrending]);

  if (loading) {
    return (
      <section className="mb-10">
        <h2 className="text-xl font-bold text-white mb-5 flex items-center gap-2">
          <Youtube className="w-5 h-5 text-red-500" /> YouTube Trending
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {[0,1,2,3].map(i => (
            <div key={i} className="space-y-2">
              <div className="aspect-video rounded-xl skeleton" />
              <div className="h-3 w-3/4 skeleton rounded" />
              <div className="h-2 w-1/2 skeleton rounded" />
            </div>
          ))}
        </div>
      </section>
    );
  }

  if (videos.length === 0) return null;

  return (
    <section className="mb-10">
      <div className="flex items-center justify-between mb-5">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <Youtube className="w-5 h-5 text-red-500" /> YouTube Trending
        </h2>
        <button onClick={() => setPage('youtube')} className="text-sm text-red-400 flex items-center gap-1 hover:gap-2 transition-all font-medium">
          See All <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Inline Player */}
      <AnimatePresence>
        {playingId && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden mb-4">
            <div className="glass-strong rounded-2xl overflow-hidden">
              <div className="aspect-video bg-black">
                <iframe src={`https://www.youtube.com/embed/${playingId}?autoplay=1&rel=0`} title="YouTube" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen className="w-full h-full" />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
        {videos.slice(0, 8).map((video, i) => (
          <motion.div key={video.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
            whileHover={{ y: -4 }} className="group cursor-pointer" onClick={() => setPlayingId(p => p === video.id ? null : video.id)}>
            <div className={`relative aspect-video rounded-xl overflow-hidden mb-2 bg-white/5 shadow-lg ${playingId === video.id ? 'ring-2 ring-red-500/50' : ''}`}>
              <img src={video.thumbnail} alt={video.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" loading="lazy" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-all" />
              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="w-10 h-10 rounded-full bg-red-500/90 flex items-center justify-center shadow-xl"><Play className="w-4 h-4 text-white fill-white ml-0.5" /></div>
              </div>
              {video.duration && <span className="absolute bottom-1.5 right-1.5 px-1.5 py-0.5 rounded bg-black/80 text-[9px] text-white/90 font-mono">{video.duration}</span>}
              {i < 3 && (
                <span className={`absolute top-1.5 left-1.5 w-5 h-5 rounded-md flex items-center justify-center text-[9px] font-black ${
                  i === 0 ? 'bg-yellow-400 text-black' : i === 1 ? 'bg-gray-300 text-black' : 'bg-amber-600 text-white'
                }`}>{i + 1}</span>
              )}
            </div>
            <p className="text-xs font-semibold text-white/80 line-clamp-2 group-hover:text-white transition-colors leading-snug">{video.title}</p>
            <div className="flex items-center gap-2 mt-1">
              <p className="text-[10px] text-white/25">{video.channel}</p>
              {video.viewCount && <span className="text-[9px] text-white/15 flex items-center gap-0.5"><Eye className="w-2.5 h-2.5" /> {formatViewCount(video.viewCount)}</span>}
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

/* ============ HOME PAGE ============ */
export function HomePage() {
  return (
    <div>
      <WelcomeBanner />
      <HeroSection />
      <FeaturesQuickAccess />
      <QuickPicks />
      <MoodSection />
      <YouTubeTrending />
      <PlaylistSection />
      <TrendingSection />
      <NewReleasesBanner />
      <TopCharts />
      <TopArtists />
      <CentBanner />
      <RecentlyPlayed />
    </div>
  );
}
