import { motion } from 'framer-motion';
import { Play, UserPlus, Share2, CheckCircle2, ChevronLeft, Disc3 } from 'lucide-react';
import { useStore } from '../store/useStore';
import { TRACKS, formatNumber } from '../data/mock';
import { TrackCard } from '../components/TrackCard';

export function ArtistPage() {
  const { selectedArtist, setPage, setCurrentTrack, setIsPlaying, setQueue } = useStore();
  const artist = selectedArtist;

  if (!artist) {
    return (
      <div className="text-center py-20">
        <p className="text-white/40">No artist selected</p>
        <button onClick={() => setPage('home')} className="mt-4 text-cent-400 text-sm">Go Home</button>
      </div>
    );
  }

  const artistTracks = TRACKS.filter(t => t.artist === artist.name).length > 0
    ? TRACKS.filter(t => t.artist === artist.name)
    : TRACKS.slice(0, 6);

  const playAll = () => {
    setQueue(artistTracks);
    setCurrentTrack(artistTracks[0]);
    setIsPlaying(true);
  };

  return (
    <div className="space-y-8">
      {/* Back */}
      <button onClick={() => setPage('explore')} className="flex items-center gap-2 text-white/40 hover:text-white transition text-sm">
        <ChevronLeft className="w-4 h-4" /> Back
      </button>

      {/* Hero */}
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="relative rounded-3xl overflow-hidden">
        <div className="absolute inset-0">
          <img src={artist.image} alt="" className="w-full h-full object-cover scale-125 blur-xl opacity-40" />
          <div className="absolute inset-0 bg-gradient-to-t from-surface via-surface/80 to-transparent" />
        </div>
        <div className="relative px-8 pt-20 pb-8 md:px-12 md:pt-32 md:pb-12 flex flex-col md:flex-row items-center md:items-end gap-6">
          <motion.div
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            className="w-40 h-40 md:w-52 md:h-52 rounded-full overflow-hidden shadow-2xl ring-4 ring-cent-400/20 flex-shrink-0"
          >
            <img src={artist.image} alt={artist.name} className="w-full h-full object-cover" />
          </motion.div>
          <div className="text-center md:text-left flex-1">
            <div className="flex items-center justify-center md:justify-start gap-2 mb-2">
              {artist.verified && (
                <span className="px-3 py-1 rounded-full bg-blue-500/20 text-blue-400 text-xs font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> Verified Artist
                </span>
              )}
            </div>
            <h1 className="text-4xl md:text-6xl font-display font-bold text-white mb-2">{artist.name}</h1>
            <div className="flex items-center justify-center md:justify-start gap-4 text-sm text-white/40">
              <span>{formatNumber(artist.followers)} followers</span>
              <span>·</span>
              <span>{artist.genre}</span>
              <span>·</span>
              <span>{artistTracks.length} tracks</span>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Actions */}
      <div className="flex items-center gap-3">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={playAll}
          className="flex items-center gap-2 px-8 py-3 rounded-full bg-gradient-to-r from-cent-400 to-cent-600 text-white font-semibold shadow-lg shadow-cent-500/30"
        >
          <Play className="w-5 h-5" /> Play All
        </motion.button>
        <button className="flex items-center gap-2 px-6 py-3 rounded-full glass text-white font-medium text-sm hover:bg-white/10 transition">
          <UserPlus className="w-4 h-4" /> Follow
        </button>
        <button className="p-3 rounded-full glass text-white/40 hover:text-white transition">
          <Share2 className="w-5 h-5" />
        </button>
      </div>

      {/* Popular Tracks */}
      <section>
        <h2 className="text-xl font-bold text-white mb-4">Popular Tracks</h2>
        <div className="space-y-1">
          {artistTracks.map((track, i) => (
            <TrackCard key={track.id} track={track} index={i} variant="list" />
          ))}
        </div>
      </section>

      {/* Albums */}
      <section>
        <h2 className="text-xl font-bold text-white mb-4">Albums</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { name: artistTracks[0]?.album || 'Debut Album', year: '2024', tracks: 12 },
            { name: 'Deluxe Edition', year: '2023', tracks: 16 },
            { name: 'Live Sessions', year: '2023', tracks: 8 },
          ].map((album, i) => (
            <motion.div
              key={album.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              whileHover={{ y: -4 }}
              className="cursor-pointer group"
            >
              <div className="aspect-square rounded-2xl overflow-hidden mb-3 bg-gradient-to-br from-cent-500/20 to-cent-700/20 border border-white/5 flex items-center justify-center group-hover:border-cent-400/30 transition-all shadow-lg">
                <Disc3 className="w-16 h-16 text-white/10 group-hover:text-cent-400/30 transition-colors" />
              </div>
              <p className="text-sm font-semibold text-white">{album.name}</p>
              <p className="text-xs text-white/40">{album.year} · {album.tracks} tracks</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* About */}
      <section className="glass rounded-2xl p-6">
        <h2 className="text-lg font-bold text-white mb-3">About</h2>
        <p className="text-sm text-white/50 leading-relaxed">
          {artist.name} is a visionary {artist.genre.toLowerCase()} artist with {formatNumber(artist.followers)} followers worldwide.
          Known for pushing the boundaries of sound and creating immersive sonic experiences that transcend genres.
          Their work has been featured across major streaming platforms and has garnered critical acclaim from music
          critics and fans alike.
        </p>
        <div className="grid grid-cols-3 gap-4 mt-6">
          <div className="text-center">
            <p className="text-2xl font-bold text-gradient">{formatNumber(artist.followers)}</p>
            <p className="text-xs text-white/30">Followers</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-gradient">{formatNumber(artist.followers * 3)}</p>
            <p className="text-xs text-white/30">Monthly Listeners</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-gradient">#{Math.floor(Math.random() * 50) + 1}</p>
            <p className="text-xs text-white/30">Global Rank</p>
          </div>
        </div>
      </section>
    </div>
  );
}
