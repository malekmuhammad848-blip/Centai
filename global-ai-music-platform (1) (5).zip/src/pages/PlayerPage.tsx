import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Play, Pause, SkipBack, SkipForward, Heart, Shuffle, Repeat, Repeat1, Volume2, VolumeX, ChevronDown, Share2, ListMusic, Sliders, MessageCircle, Music } from 'lucide-react';
import { useStore } from '../store/useStore';
import { AudioVisualizer } from '../components/AudioVisualizer';
import { formatDuration, TRACKS } from '../data/mock';
import { useAudio } from '../App';

const LYRICS = [
  { time: 0, text: "In the silence of the night" },
  { time: 8, text: "I hear your voice calling out" },
  { time: 16, text: "Through the static and the noise" },
  { time: 24, text: "You're the signal I've been searching for" },
  { time: 32, text: "Neon lights flash overhead" },
  { time: 40, text: "Painting stories left unsaid" },
  { time: 48, text: "Every beat that fills this room" },
  { time: 56, text: "Brings me closer back to you" },
  { time: 64, text: "We're frequencies aligned" },
  { time: 72, text: "Resonating through time" },
  { time: 80, text: "In this digital divide" },
  { time: 88, text: "You're my analog lifeline" },
];

const EQ_PRESETS: Record<string, number[]> = {
  'Flat': [50, 50, 50, 50, 50, 50, 50, 50],
  'Bass Boost': [85, 75, 60, 45, 40, 45, 50, 50],
  'Treble': [40, 45, 50, 55, 65, 75, 85, 90],
  'Vocal': [35, 45, 65, 80, 80, 65, 45, 35],
  'Electronic': [70, 80, 50, 35, 45, 65, 80, 75],
  'Rock': [70, 60, 45, 55, 65, 75, 70, 65],
};

export function PlayerPage() {
  const {
    currentTrack, isPlaying, togglePlay, setPage, progress,
    favorites, toggleFavorite, shuffle, toggleShuffle,
    repeatMode, cycleRepeat, volume, setVolume,
    setCurrentTrack,
  } = useStore();
  const { seekTo, playNext, playPrev, getCurrentTime, getDuration } = useAudio();
  const [showLyrics, setShowLyrics] = useState(false);
  const [showEQ, setShowEQ] = useState(false);
  const [activeEQ, setActiveEQ] = useState('Flat');
  const [eqBands, setEqBands] = useState(EQ_PRESETS['Flat']);

  const track = currentTrack || TRACKS[0];
  const isFav = favorites.includes(track.id);

  // Only set a default track if nothing is loaded - don't auto-play
  useEffect(() => {
    if (!currentTrack) {
      setCurrentTrack(TRACKS[0]);
    }
  }, [currentTrack, setCurrentTrack]);

  const currentTime = getCurrentTime();
  const duration = getDuration();
  const activeLyricIndex = LYRICS.findLastIndex(l => currentTime >= l.time);

  const handleEqPreset = useCallback((preset: string) => {
    setActiveEQ(preset);
    setEqBands(EQ_PRESETS[preset] || EQ_PRESETS['Flat']);
  }, []);

  const handleEqChange = useCallback((index: number, value: number) => {
    setEqBands(prev => {
      const next = [...prev];
      next[index] = value;
      return next;
    });
  }, []);

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const pct = ((e.clientX - rect.left) / rect.width) * 100;
    seekTo(Math.max(0, Math.min(100, pct)));
  };

  const handleTouchSeek = (e: React.TouchEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const touch = e.touches[0];
    const pct = ((touch.clientX - rect.left) / rect.width) * 100;
    seekTo(Math.max(0, Math.min(100, pct)));
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 overflow-y-auto"
      style={{ background: '#030308' }}
    >
      {/* Dynamic background */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.img
          key={track.id}
          src={track.cover}
          alt=""
          className="w-full h-full object-cover blur-[140px] opacity-15 scale-150"
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.15 }}
          transition={{ duration: 1.5 }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/50 to-black/95" />
        <div className="absolute inset-0" style={{
          background: `radial-gradient(ellipse at 30% 20%, ${track.color}08, transparent 60%), radial-gradient(ellipse at 70% 80%, ${track.color}05, transparent 50%)`
        }} />
      </div>

      <div className="relative max-w-lg mx-auto px-5 sm:px-6 py-4 sm:py-6 min-h-screen flex flex-col safe-area-bottom">
        {/* Header */}
        <div className="flex items-center justify-between mb-4 sm:mb-6">
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={() => {
              // Go back to home - audio keeps playing because AudioManager is a singleton
              setPage('home');
            }}
            className="p-2 -ml-2 rounded-full hover:bg-white/5 transition"
          >
            <ChevronDown className="w-6 h-6 text-white/50" />
          </motion.button>
          <div className="text-center flex-1 mx-4">
            <p className="text-[10px] text-white/15 uppercase tracking-[0.25em]">Playing From</p>
            <p className="text-xs font-medium text-white/40 truncate">{track.album}</p>
          </div>
          <button className="p-2 rounded-full hover:bg-white/5 transition">
            <Share2 className="w-4 h-4 text-white/25" />
          </button>
        </div>

        {/* Album Art */}
        <div className="flex-1 flex items-center justify-center py-2 sm:py-4">
          <div className="relative w-full max-w-[280px] sm:max-w-[320px] md:max-w-[360px] aspect-square">
            {/* Glow */}
            <motion.div
              className="absolute -inset-10 sm:-inset-12 rounded-full blur-[80px] opacity-15"
              style={{ background: track.color }}
              animate={isPlaying ? { scale: [1, 1.2, 1], opacity: [0.1, 0.25, 0.1] } : { scale: 1, opacity: 0.05 }}
              transition={{ duration: 4, repeat: Infinity }}
            />

            {/* Art container */}
            <motion.div
              className="relative w-full h-full overflow-hidden shadow-2xl shadow-black/50"
              animate={isPlaying ? { borderRadius: '50%' } : { borderRadius: '28px' }}
              transition={{ duration: 0.8, ease: 'easeInOut' }}
            >
              <motion.img
                src={track.cover}
                alt={track.title}
                className="w-full h-full object-cover"
                animate={isPlaying ? { rotate: 360 } : { rotate: 0 }}
                transition={isPlaying ? { duration: 25, repeat: Infinity, ease: 'linear' } : { duration: 0.5 }}
              />
              {isPlaying && (
                <>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-[#030308] border-4 border-[#0a0a12] shadow-inner flex items-center justify-center">
                      <Music className="w-5 h-5 sm:w-6 sm:h-6 text-white/10" />
                    </div>
                  </div>
                  <div className="absolute inset-0 vinyl-grooves rounded-full" />
                </>
              )}
            </motion.div>

            {/* Circle visualizer */}
            {isPlaying && (
              <div className="absolute -inset-8 sm:-inset-10 flex items-center justify-center pointer-events-none opacity-40">
                <AudioVisualizer size="lg" color={track.color} type="circle" />
              </div>
            )}
          </div>
        </div>

        {/* Track Info */}
        <div className="flex items-center justify-between mb-4 sm:mb-5 mt-3 sm:mt-4">
          <motion.div
            key={track.title}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="min-w-0 flex-1"
          >
            <h2 className="text-xl sm:text-2xl font-bold text-white truncate">{track.title}</h2>
            <p className="text-sm sm:text-base text-white/30 mt-0.5">{track.artist}</p>
          </motion.div>
          <motion.button
            whileTap={{ scale: 0.7 }}
            onClick={() => toggleFavorite(track.id)}
            className="p-2 -mr-2"
          >
            <Heart className={`w-6 h-6 transition-all ${isFav ? 'fill-cent-400 text-cent-400 scale-110' : 'text-white/20'}`} />
          </motion.button>
        </div>

        {/* Progress */}
        <div className="mb-4 sm:mb-5">
          <div
            className="relative h-[6px] sm:h-[5px] bg-white/6 rounded-full cursor-pointer group touch-none"
            onClick={handleSeek}
            onTouchMove={handleTouchSeek}
          >
            <div
              className="h-full rounded-full relative transition-all"
              style={{
                width: `${progress}%`,
                background: `linear-gradient(90deg, ${track.color}, ${track.color}cc)`,
                boxShadow: `0 0 12px ${track.color}40`,
              }}
            >
              <motion.div
                className="absolute right-0 top-1/2 -translate-y-1/2 w-5 h-5 sm:w-4 sm:h-4 rounded-full bg-white shadow-lg shadow-black/30"
                style={{ transform: 'translate(50%, -50%)' }}
              />
            </div>
          </div>
          <div className="flex justify-between mt-2">
            <span className="text-[11px] text-white/20 font-mono">{formatDuration(Math.floor(currentTime))}</span>
            <span className="text-[11px] text-white/20 font-mono">{formatDuration(Math.floor(duration))}</span>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center justify-between mb-5 sm:mb-6">
          <motion.button whileTap={{ scale: 0.85 }} onClick={toggleShuffle} className={`p-3 ${shuffle ? 'text-cent-400' : 'text-white/20'}`}>
            <Shuffle className="w-5 h-5" />
          </motion.button>
          <motion.button whileTap={{ scale: 0.85 }} onClick={playPrev} className="p-3 text-white/50 hover:text-white transition active:text-white">
            <SkipBack className="w-6 h-6 sm:w-7 sm:h-7" />
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.08 }}
            whileTap={{ scale: 0.9 }}
            onClick={togglePlay}
            className="rounded-full bg-white flex items-center justify-center shadow-2xl shadow-white/10"
            style={{ width: 68, height: 68 }}
          >
            {isPlaying ? <Pause className="w-7 h-7 text-black" /> : <Play className="w-7 h-7 text-black ml-1" />}
          </motion.button>
          <motion.button whileTap={{ scale: 0.85 }} onClick={playNext} className="p-3 text-white/50 hover:text-white transition active:text-white">
            <SkipForward className="w-6 h-6 sm:w-7 sm:h-7" />
          </motion.button>
          <motion.button whileTap={{ scale: 0.85 }} onClick={cycleRepeat} className={`p-3 ${repeatMode !== 'off' ? 'text-cent-400' : 'text-white/20'}`}>
            {repeatMode === 'one' ? <Repeat1 className="w-5 h-5" /> : <Repeat className="w-5 h-5" />}
          </motion.button>
        </div>

        {/* Volume - Hidden on very small screens */}
        <div className="hidden sm:flex items-center gap-3 mb-5">
          <button onClick={() => setVolume(volume > 0 ? 0 : 80)}>
            {volume === 0 ? <VolumeX className="w-4 h-4 text-white/20" /> : <Volume2 className="w-4 h-4 text-white/20" />}
          </button>
          <div
            className="flex-1 h-[3px] bg-white/6 rounded-full cursor-pointer group"
            onClick={(e) => {
              const rect = e.currentTarget.getBoundingClientRect();
              setVolume(Math.round(((e.clientX - rect.left) / rect.width) * 100));
            }}
          >
            <div className="h-full bg-white/25 rounded-full relative" style={{ width: `${volume}%` }}>
              <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-white opacity-0 group-hover:opacity-100 transition-opacity" style={{ transform: 'translate(50%, -50%)' }} />
            </div>
          </div>
          <span className="text-[10px] text-white/10 w-7 text-right font-mono">{volume}</span>
        </div>

        {/* Bottom Actions */}
        <div className="flex items-center justify-around py-2.5 sm:py-3 glass rounded-2xl mb-3 sm:mb-4">
          <button onClick={() => setShowLyrics(!showLyrics)} className={`flex flex-col items-center gap-1 px-4 py-1 rounded-xl transition ${showLyrics ? 'text-cent-400' : 'text-white/25'}`}>
            <MessageCircle className="w-5 h-5" />
            <span className="text-[9px] font-medium">Lyrics</span>
          </button>
          <button onClick={() => setShowEQ(!showEQ)} className={`flex flex-col items-center gap-1 px-4 py-1 rounded-xl transition ${showEQ ? 'text-cent-400' : 'text-white/25'}`}>
            <Sliders className="w-5 h-5" />
            <span className="text-[9px] font-medium">EQ</span>
          </button>
          <button className="flex flex-col items-center gap-1 px-4 py-1 rounded-xl text-white/25">
            <ListMusic className="w-5 h-5" />
            <span className="text-[9px] font-medium">Queue</span>
          </button>
        </div>

        {/* Lyrics Panel */}
        <AnimatePresence>
          {showLyrics && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="glass rounded-2xl overflow-hidden mb-3 sm:mb-4"
            >
              <div className="p-5 sm:p-6">
                <h3 className="text-[11px] font-semibold text-white/20 mb-4 uppercase tracking-[0.2em]">Lyrics</h3>
                <div className="space-y-3 sm:space-y-4 max-h-56 sm:max-h-64 overflow-y-auto no-scrollbar">
                  {LYRICS.map((line, i) => (
                    <motion.p
                      key={i}
                      animate={{
                        scale: i === activeLyricIndex ? 1.03 : 1,
                        opacity: i === activeLyricIndex ? 1 : i < activeLyricIndex ? 0.15 : 0.06,
                      }}
                      transition={{ duration: 0.5 }}
                      className={`text-base sm:text-lg font-semibold transition-all origin-left ${
                        i === activeLyricIndex ? 'text-white text-shadow-glow' : 'text-white/15'
                      }`}
                    >
                      {line.text}
                    </motion.p>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Equalizer Panel */}
        <AnimatePresence>
          {showEQ && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="glass rounded-2xl overflow-hidden mb-3 sm:mb-4"
            >
              <div className="p-5 sm:p-6">
                <h3 className="text-[11px] font-semibold text-white/20 mb-3 sm:mb-4 uppercase tracking-[0.2em]">Equalizer</h3>
                <div className="flex gap-1.5 sm:gap-2 mb-5 sm:mb-6 overflow-x-auto no-scrollbar pb-1">
                  {Object.keys(EQ_PRESETS).map(p => (
                    <button
                      key={p}
                      onClick={() => handleEqPreset(p)}
                      className={`px-3 py-1.5 rounded-full text-[11px] font-medium whitespace-nowrap transition-all ${
                        activeEQ === p
                          ? 'bg-cent-500 text-white shadow-lg shadow-cent-500/20'
                          : 'bg-white/5 text-white/25 hover:text-white/40'
                      }`}
                    >
                      {p}
                    </button>
                  ))}
                </div>
                <div className="flex items-end justify-between gap-2 sm:gap-3 h-24 sm:h-28">
                  {['60', '150', '400', '1k', '2.4k', '6k', '10k', '15k'].map((freq, i) => (
                    <div key={freq} className="flex-1 flex flex-col items-center gap-1.5 sm:gap-2">
                      <div className="relative w-full h-16 sm:h-20 flex items-end justify-center bg-white/[0.02] rounded-lg overflow-hidden">
                        <motion.div
                          className="w-full rounded-t-sm cursor-pointer"
                          style={{
                            height: `${eqBands[i]}%`,
                            background: `linear-gradient(to top, ${track.color}40, ${track.color})`,
                          }}
                          animate={{ height: `${eqBands[i]}%` }}
                          transition={{ duration: 0.3 }}
                          drag="y"
                          dragConstraints={{ top: 0, bottom: 0 }}
                          onDrag={(_e, info) => handleEqChange(i, Math.max(10, Math.min(100, eqBands[i] - info.delta.y)))}
                        />
                      </div>
                      <span className="text-[7px] sm:text-[8px] text-white/15 font-mono">{freq}</span>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* CENT Branding */}
        <div className="text-center mt-2 sm:mt-4 mb-2 sm:mb-4">
          <p className="text-[9px] text-white/[0.06] tracking-[0.3em] uppercase font-display">Powered by CENT</p>
        </div>
      </div>
    </motion.div>
  );
}
