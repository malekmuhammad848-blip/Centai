// CENT Service Worker — Background Audio + Offline + PWA
const CACHE_NAME = 'cent-v14';
const OFFLINE_URLS = ['/'];

// Install — cache core assets
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(OFFLINE_URLS))
  );
  self.skipWaiting();
});

// Activate — clean old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// Fetch — serve from cache, fallback to network
self.addEventListener('fetch', (event) => {
  // Skip non-GET and API requests
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  
  // Don't cache API calls, YouTube, or Jamendo
  if (url.hostname.includes('googleapis.com') ||
      url.hostname.includes('youtube.com') ||
      url.hostname.includes('jamendo.com') ||
      url.hostname.includes('openrouter.ai') ||
      url.hostname.includes('soundhelix.com')) {
    return;
  }

  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;
      return fetch(event.request).then((response) => {
        if (response.status === 200) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
        }
        return response;
      }).catch(() => caches.match('/'));
    })
  );
});

// Background Sync for offline actions
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-favorites') {
    // Sync favorites when back online
    event.waitUntil(Promise.resolve());
  }
});
