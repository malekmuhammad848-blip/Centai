import { useEffect, useRef, useCallback } from 'react';
import { useStore, type Track } from '../store/useStore';
import { TRACKS } from '../data/mock';

// Free audio sources
const AUDIO_URLS: Record<string, string> = {};
for (let i = 1; i <= 12; i++) {
  AUDIO_URLS[String(i)] = `https://www.soundhelix.com/examples/mp3/SoundHelix-Song-${i}.mp3`;
}

// Request notification permission for media controls
if ('Notification' in window && Notification.permission === 'default') {
  // Don't block — just request when user interacts
  document.addEventListener('click', function requestNotifPerm() {
    Notification.requestPermission().catch(() => {});
    document.removeEventListener('click', requestNotifPerm);
  }, { once: true });
}

/* ===== GLOBAL AUDIO ELEMENT - Never garbage collected ===== */
const globalAudio = new Audio();
globalAudio.preload = 'auto';
globalAudio.volume = 0.8;
// Allow background playback
(globalAudio as any).mozAudioChannelType = 'content';

let currentLoadedId: string | null = null;
let isInitialized = false;

/* ===== MEDIA SESSION SETUP ===== */
function updateMediaSession(track: Track) {
  if (!('mediaSession' in navigator)) return;
  try {
    navigator.mediaSession.metadata = new MediaMetadata({
      title: track.title,
      artist: track.artist,
      album: track.album || 'CENT Music',
      artwork: [
        { src: track.cover, sizes: '96x96', type: 'image/jpeg' },
        { src: track.cover, sizes: '128x128', type: 'image/jpeg' },
        { src: track.cover, sizes: '256x256', type: 'image/jpeg' },
        { src: track.cover, sizes: '512x512', type: 'image/jpeg' },
      ],
    });
  } catch { /* ignore */ }
}

function setupMediaSession() {
  if (!('mediaSession' in navigator) || isInitialized) return;
  isInitialized = true;

  const ms = navigator.mediaSession;

  const getNextTrack = (direction: 'next' | 'prev') => {
    const s = useStore.getState();
    const tracks = s.queue.length > 0 ? s.queue : TRACKS;
    const idx = tracks.findIndex(t => t.id === s.currentTrack?.id);
    if (direction === 'next') {
      if (s.shuffle) {
        let ni = Math.floor(Math.random() * tracks.length);
        while (ni === idx && tracks.length > 1) ni = Math.floor(Math.random() * tracks.length);
        return tracks[ni];
      }
      return tracks[(idx + 1) % tracks.length];
    }
    return tracks[idx <= 0 ? tracks.length - 1 : idx - 1];
  };

  ms.setActionHandler('play', () => {
    const s = useStore.getState();
    s.setIsPlaying(true);
    if (!s.currentTrack?.id.startsWith('yt_')) {
      globalAudio.play().catch(() => {});
    }
    ms.playbackState = 'playing';
  });

  ms.setActionHandler('pause', () => {
    const s = useStore.getState();
    s.setIsPlaying(false);
    if (!s.currentTrack?.id.startsWith('yt_')) {
      globalAudio.pause();
    }
    ms.playbackState = 'paused';
  });

  ms.setActionHandler('nexttrack', () => {
    const next = getNextTrack('next');
    const s = useStore.getState();
    s.setCurrentTrack(next);
    s.setIsPlaying(true);
  });

  ms.setActionHandler('previoustrack', () => {
    if (globalAudio.currentTime > 3) {
      globalAudio.currentTime = 0;
      return;
    }
    const prev = getNextTrack('prev');
    const s = useStore.getState();
    s.setCurrentTrack(prev);
    s.setIsPlaying(true);
  });

  ms.setActionHandler('seekto', (details) => {
    if (details.seekTime !== undefined && globalAudio.duration) {
      globalAudio.currentTime = details.seekTime;
      useStore.getState().setProgress((details.seekTime / globalAudio.duration) * 100);
    }
  });

  try { ms.setActionHandler('seekbackward', (d) => { globalAudio.currentTime = Math.max(0, globalAudio.currentTime - (d.seekOffset || 10)); }); } catch {}
  try { ms.setActionHandler('seekforward', (d) => { globalAudio.currentTime = Math.min(globalAudio.duration || 0, globalAudio.currentTime + (d.seekOffset || 10)); }); } catch {}
}

/* ===== Track loading ===== */
function loadTrack(track: Track) {
  if (currentLoadedId === track.id) return;
  currentLoadedId = track.id;

  // Update media session for ALL tracks (including YouTube)
  updateMediaSession(track);

  // YouTube tracks play via iframe, not audio element
  if (track.id.startsWith('yt_')) {
    globalAudio.pause();
    globalAudio.removeAttribute('src');
    globalAudio.load();
    return;
  }

  // Jamendo tracks have their own audio URL
  let src: string;
  if (track.audioUrl) {
    // Jamendo or any track with a direct audio URL
    src = track.audioUrl;
  } else {
    src = AUDIO_URLS[track.id] || AUDIO_URLS['1'];
  }
  console.log('[CENT Audio] Loading:', track.title, '| Source:', src.substring(0, 60) + '...');
  globalAudio.src = src;
  globalAudio.load();
}

/* ===== Auto-play when ready ===== */
globalAudio.addEventListener('canplay', () => {
  const s = useStore.getState();
  if (s.isPlaying && s.currentTrack && currentLoadedId === s.currentTrack.id && !s.currentTrack.id.startsWith('yt_')) {
    globalAudio.play().catch(() => {});
    if ('mediaSession' in navigator) navigator.mediaSession.playbackState = 'playing';
  }
});

/* ===== Auto-next on end ===== */
globalAudio.addEventListener('ended', () => {
  const s = useStore.getState();
  if (s.repeatMode === 'one') {
    globalAudio.currentTime = 0;
    globalAudio.play().catch(() => {});
    return;
  }
  const tracks = s.queue.length > 0 ? s.queue : TRACKS;
  const idx = tracks.findIndex(t => t.id === s.currentTrack?.id);
  let nextIdx: number;
  if (s.shuffle) {
    nextIdx = Math.floor(Math.random() * tracks.length);
    while (nextIdx === idx && tracks.length > 1) nextIdx = Math.floor(Math.random() * tracks.length);
  } else {
    nextIdx = (idx + 1) % tracks.length;
  }
  s.setCurrentTrack(tracks[nextIdx]);
  s.setIsPlaying(true);
});

/* ===== Progress tracking ===== */
setInterval(() => {
  const s = useStore.getState();
  if (!s.isPlaying || !s.currentTrack) return;
  if (s.currentTrack.id.startsWith('yt_')) return;

  if (globalAudio.duration && !isNaN(globalAudio.duration) && globalAudio.duration > 0) {
    const pct = (globalAudio.currentTime / globalAudio.duration) * 100;
    s.setProgress(pct);

    if ('mediaSession' in navigator) {
      try {
        navigator.mediaSession.setPositionState({
          duration: globalAudio.duration,
          playbackRate: 1,
          position: Math.min(globalAudio.currentTime, globalAudio.duration),
        });
      } catch {}
    }
  }
}, 200);

/* ===== Initialize media session immediately ===== */
setupMediaSession();

/* ===== REACT HOOK ===== */
export function useAudioPlayer() {
  const currentTrack = useStore(s => s.currentTrack);
  const isPlaying = useStore(s => s.isPlaying);
  const volume = useStore(s => s.volume);
  const trackId = currentTrack?.id;
  const initRef = useRef(false);

  // One-time setup
  useEffect(() => {
    if (!initRef.current) {
      setupMediaSession();
      initRef.current = true;
    }
  }, []);

  // Load track when it changes
  useEffect(() => {
    if (currentTrack) {
      loadTrack(currentTrack);
    }
  }, [trackId]); // eslint-disable-line

  // Play/Pause
  useEffect(() => {
    if (!currentTrack) return;
    if (currentTrack.id.startsWith('yt_')) {
      // YouTube tracks: just update media session state
      if ('mediaSession' in navigator) {
        navigator.mediaSession.playbackState = isPlaying ? 'playing' : 'paused';
      }
      return;
    }
    if (isPlaying) {
      if (globalAudio.src && globalAudio.readyState >= 2) {
        globalAudio.play().catch(() => {});
      }
      if ('mediaSession' in navigator) navigator.mediaSession.playbackState = 'playing';
    } else {
      globalAudio.pause();
      if ('mediaSession' in navigator) navigator.mediaSession.playbackState = 'paused';
    }
  }, [isPlaying, trackId]); // eslint-disable-line

  // Volume
  useEffect(() => {
    globalAudio.volume = Math.max(0, Math.min(1, volume / 100));
  }, [volume]);

  const seekTo = useCallback((pct: number) => {
    const clamped = Math.max(0, Math.min(100, pct));
    if (globalAudio.duration && !isNaN(globalAudio.duration)) {
      globalAudio.currentTime = (clamped / 100) * globalAudio.duration;
      useStore.getState().setProgress(clamped);
    }
  }, []);

  const playNext = useCallback(() => {
    const s = useStore.getState();
    if (s.repeatMode === 'one') {
      globalAudio.currentTime = 0;
      globalAudio.play().catch(() => {});
      return;
    }
    const tracks = s.queue.length > 0 ? s.queue : TRACKS;
    const idx = tracks.findIndex(t => t.id === s.currentTrack?.id);
    let ni: number;
    if (s.shuffle) {
      ni = Math.floor(Math.random() * tracks.length);
      while (ni === idx && tracks.length > 1) ni = Math.floor(Math.random() * tracks.length);
    } else {
      ni = (idx + 1) % tracks.length;
    }
    s.setCurrentTrack(tracks[ni]);
    s.setIsPlaying(true);
  }, []);

  const playPrev = useCallback(() => {
    if (globalAudio.currentTime > 3) {
      globalAudio.currentTime = 0;
      return;
    }
    const s = useStore.getState();
    const tracks = s.queue.length > 0 ? s.queue : TRACKS;
    const idx = tracks.findIndex(t => t.id === s.currentTrack?.id);
    const pi = idx <= 0 ? tracks.length - 1 : idx - 1;
    s.setCurrentTrack(tracks[pi]);
    s.setIsPlaying(true);
  }, []);

  const getCurrentTime = useCallback(() => globalAudio.currentTime || 0, []);
  const getDuration = useCallback(() => {
    if (globalAudio.duration && !isNaN(globalAudio.duration)) return globalAudio.duration;
    return useStore.getState().currentTrack?.duration || 0;
  }, []);

  return { seekTo, playNext, playPrev, getCurrentTime, getDuration };
}
