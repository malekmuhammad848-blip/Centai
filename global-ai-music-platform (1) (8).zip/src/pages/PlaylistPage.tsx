import { motion } from 'framer-motion';
import { Play, Shuffle, Heart, Share2, Clock, MoreHorizontal, ChevronLeft, Download } from 'lucide-react';
import { useStore } from '../store/useStore';
import { TRACKS, formatDuration, formatNumber } from '../data/mock';
import { TrackCard } from '../components/TrackCard';

export function PlaylistPage() {
  const { selectedPlaylist, setPage, setCurrentTrack, setIsPlaying, setQueue } = useStore();
  const playlist = selectedPlaylist;

  if (!playlist) {
    return (
      <div className="text-center py-20">
        <p className="text-white/40">No playlist selected</p>
        <button onClick={() => setPage('home')} className="mt-4 text-cent-400 text-sm">Go Home</button>
      </div>
    );
  }

  const playlistTracks = TRACKS.slice(0, Math.min(playlist.trackCount, TRACKS.length));
  const totalDuration = playlistTracks.reduce((a, t) => a + t.duration, 0);

  const playAll = () => {
    setQueue(playlistTracks);
    setCurrentTrack(playlistTracks[0]);
    setIsPlaying(true);
  };

  return (
    <div className="space-y-6">
      {/* Back Button */}
      <button onClick={() => setPage('library')} className="flex items-center gap-2 text-white/40 hover:text-white transition-colors text-sm">
        <ChevronLeft className="w-4 h-4" /> Back to Library
      </button>

      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className={`relative rounded-3xl overflow-hidden bg-gradient-to-br ${playlist.gradient} p-8 md:p-12`}
      >
        <img src={playlist.cover} alt="" className="absolute inset-0 w-full h-full object-cover opacity-20 mix-blend-overlay" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
        <div className="relative flex flex-col md:flex-row items-start md:items-end gap-6">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-48 h-48 rounded-2xl overflow-hidden shadow-2xl flex-shrink-0"
          >
            <img src={playlist.cover} alt="" className="w-full h-full object-cover" />
          </motion.div>
          <div className="flex-1 min-w-0">
            <p className="text-xs text-white/60 uppercase tracking-wider mb-1">Playlist</p>
            <h1 className="text-3xl md:text-5xl font-display font-bold text-white mb-2">{playlist.name}</h1>
            <p className="text-sm text-white/60 mb-4">{playlist.description}</p>
            <div className="flex items-center gap-4 text-sm text-white/40">
              <span>{playlist.trackCount} tracks</span>
              <span>·</span>
              <span>{formatDuration(totalDuration)}</span>
              <span>·</span>
              <span>{formatNumber(2400000)} plays</span>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Actions */}
      <div className="flex items-center gap-3">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={playAll}
          className="flex items-center gap-2 px-8 py-3 rounded-full bg-gradient-to-r from-cent-400 to-cent-600 text-white font-semibold shadow-lg shadow-cent-500/30"
        >
          <Play className="w-5 h-5" /> Play
        </motion.button>
        <button className="p-3 rounded-full glass text-white/40 hover:text-white transition">
          <Shuffle className="w-5 h-5" />
        </button>
        <button className="p-3 rounded-full glass text-white/40 hover:text-white transition">
          <Heart className="w-5 h-5" />
        </button>
        <button className="p-3 rounded-full glass text-white/40 hover:text-white transition">
          <Download className="w-5 h-5" />
        </button>
        <button className="p-3 rounded-full glass text-white/40 hover:text-white transition">
          <Share2 className="w-5 h-5" />
        </button>
        <button className="p-3 rounded-full glass text-white/40 hover:text-white transition ml-auto">
          <MoreHorizontal className="w-5 h-5" />
        </button>
      </div>

      {/* Track List Header */}
      <div className="flex items-center gap-4 px-3 py-2 border-b border-white/5 text-xs text-white/30">
        <span className="w-6 text-right">#</span>
        <span className="flex-1">Title</span>
        <span className="hidden sm:block w-24">Plays</span>
        <Clock className="w-4 h-4" />
      </div>

      {/* Track List */}
      <div className="space-y-1">
        {playlistTracks.map((track, i) => (
          <TrackCard key={track.id} track={track} index={i} variant="list" />
        ))}
      </div>
    </div>
  );
}
