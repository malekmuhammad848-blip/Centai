import { useState, useCallback, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, X, TrendingUp, Clock, Play, Eye, Loader2, Youtube, Music2, Mic, ExternalLink, Bookmark, ChevronRight, Sparkles, Flame, Headphones } from 'lucide-react';
import { TRACKS, ARTISTS, GENRES, formatNumber } from '../data/mock';
import { TrackCard } from '../components/TrackCard';
import { useStore } from '../store/useStore';
import { searchYouTubeMusic, cancelPendingSearch, formatViewCount, getTimeAgo, type YouTubeVideo } from '../services/youtube';
import { playYouTubeVideo } from '../services/youtubePlayer';

type SearchTab = 'all' | 'tracks' | 'artists' | 'genres' | 'youtube';

export function SearchPage() {
  const [query, setQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<SearchTab>('all');
  const { setSelectedArtist, setPage } = useStore();

  const [ytResults, setYtResults] = useState<YouTubeVideo[]>([]);
  const [ytLoading, setYtLoading] = useState(false);
  const [ytSearched, setYtSearched] = useState(false);
  const [ytError, setYtError] = useState('');
  const [inlinePlayerId, setInlinePlayerId] = useState<string | null>(null);
  const [savedVideos, setSavedVideos] = useState<string[]>([]);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastQueryRef = useRef('');
  const searchingRef = useRef(false);

  useEffect(() => {
    return () => {
      cancelPendingSearch();
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, []);

  const filteredTracks = query
    ? TRACKS.filter(t =>
        t.title.toLowerCase().includes(query.toLowerCase()) ||
        t.artist.toLowerCase().includes(query.toLowerCase()) ||
        t.genre.toLowerCase().includes(query.toLowerCase())
      )
    : [];

  const filteredArtists = query
    ? ARTISTS.filter(a =>
        a.name.toLowerCase().includes(query.toLowerCase()) ||
        a.genre.toLowerCase().includes(query.toLowerCase())
      )
    : [];

  const filteredGenres = query
    ? GENRES.filter(g => g.name.toLowerCase().includes(query.toLowerCase()))
    : [];

  const hasResults = query.length > 0;

  const doYouTubeSearch = useCallback(async (q: string) => {
    if (!q.trim() || searchingRef.current) return;
    const normalized = q.trim().toLowerCase();
    if (normalized === lastQueryRef.current && ytResults.length > 0) return;
    
    searchingRef.current = true;
    lastQueryRef.current = normalized;
    setYtLoading(true);
    setYtError('');
    setYtSearched(true);

    try {
      const data = await searchYouTubeMusic(q, 12);
      setYtResults(data.items);
      setYtError('');
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') {
        // Search was cancelled - don't show error
        searchingRef.current = false;
        return;
      }
      console.error('YouTube search error:', err);
      setYtError('Search failed. Tap retry.');
    } finally {
      setYtLoading(false);
      searchingRef.current = false;
    }
  }, [ytResults.length]);

  const handleQueryChange = (val: string) => {
    setQuery(val);
    if (debounceRef.current) clearTimeout(debounceRef.current);

    if (val.trim().length >= 2) {
      debounceRef.current = setTimeout(() => doYouTubeSearch(val), 1500);
    } else {
      cancelPendingSearch();
      setYtResults([]);
      setYtSearched(false);
      lastQueryRef.current = '';
    }
  };

  const handleSubmit = () => {
    if (!query.trim()) return;
    lastQueryRef.current = '';
    searchingRef.current = false;
    doYouTubeSearch(query);
  };

  const clearSearch = () => {
    setQuery('');
    setYtResults([]);
    setYtSearched(false);
    setYtError('');
    setActiveFilter('all');
    lastQueryRef.current = '';
    searchingRef.current = false;
    cancelPendingSearch();
    if (debounceRef.current) clearTimeout(debounceRef.current);
  };

  const toggleSave = (id: string) => setSavedVideos(p => p.includes(id) ? p.filter(v => v !== id) : [...p, id]);
  const playInline = (v: YouTubeVideo) => {
    const newId = inlinePlayerId === v.id ? null : v.id;
    setInlinePlayerId(newId);
    if (newId) playYouTubeVideo(v); // Register in store for MiniPlayer & notifications
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
        <div className="flex items-center gap-3 mb-6">
          <h1 className="text-3xl font-display font-bold text-white">Search</h1>
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full glass text-[10px] text-white/25">
            <Music2 className="w-3 h-3 text-cent-400" />
            <span>CENT + YouTube</span>
          </div>
        </div>

        {/* Search Input */}
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/30" />
          <input
            type="text"
            value={query}
            onChange={(e) => handleQueryChange(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
            placeholder="Search songs, artists, YouTube videos..."
            className="w-full pl-12 pr-28 py-4 rounded-2xl bg-white/5 border border-white/10 text-white placeholder:text-white/25 focus:outline-none focus:border-cent-400/50 focus:bg-white/8 transition-all text-base"
            dir="auto"
          />
          <div className="absolute right-2 top-1/2 -translate-y-1/2 flex gap-1">
            {query && (
              <button onClick={clearSearch} className="p-2 rounded-lg hover:bg-white/10 transition">
                <X className="w-4 h-4 text-white/30" />
              </button>
            )}
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={handleSubmit}
              disabled={ytLoading || !query.trim()}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-cent-400 to-cent-600 text-white text-sm font-bold disabled:opacity-50 flex items-center gap-1.5 shadow-lg shadow-cent-500/20"
            >
              {ytLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
              Search
            </motion.button>
          </div>
        </div>

        {/* Filters */}
        {hasResults && (
          <div className="flex gap-2 mt-4 overflow-x-auto no-scrollbar pb-1">
            {([
              { id: 'all' as const, label: 'All', icon: Sparkles },
              { id: 'tracks' as const, label: 'Tracks', icon: Music2 },
              { id: 'artists' as const, label: 'Artists', icon: Headphones },
              { id: 'genres' as const, label: 'Genres', icon: Flame },
              { id: 'youtube' as const, label: 'YouTube', icon: Youtube },
            ]).map(f => (
              <button
                key={f.id}
                onClick={() => {
                  setActiveFilter(f.id);
                  if (f.id === 'youtube' && !ytSearched && query.trim()) doYouTubeSearch(query);
                }}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-medium capitalize transition-all whitespace-nowrap ${
                  activeFilter === f.id
                    ? f.id === 'youtube' ? 'bg-red-500 text-white shadow-lg shadow-red-500/25' : 'bg-cent-500 text-white shadow-lg shadow-cent-500/25'
                    : 'bg-white/5 text-white/50 hover:text-white/80'
                }`}
              >
                <f.icon className="w-3.5 h-3.5" />
                {f.label}
                {f.id === 'youtube' && ytResults.length > 0 && (
                  <span className="ml-1 px-1.5 py-0.5 rounded-full bg-white/20 text-[10px]">{ytResults.length}</span>
                )}
              </button>
            ))}
          </div>
        )}
      </motion.div>

      <AnimatePresence mode="wait">
        {!hasResults ? (
          <motion.div key="idle" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            {/* Trending */}
            <section className="mb-8">
              <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-cent-400" /> Trending
              </h2>
              <div className="flex flex-wrap gap-2">
                {['Ed Sheeran', 'BTS', 'Drake', 'Taylor Swift', 'Bad Bunny', 'Chill Vibes', 'Lo-fi Beats', 'K-Pop hits', 'Arabic music', 'Rock classics'].map(t => (
                  <button key={t} onClick={() => handleQueryChange(t)} className="px-4 py-2 rounded-full glass text-sm text-white/60 hover:text-white hover:bg-white/10 transition-all">
                    {t}
                  </button>
                ))}
              </div>
            </section>

            {/* Recent */}
            <section className="mb-8">
              <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <Clock className="w-5 h-5 text-cent-400" /> Recent Searches
              </h2>
              <div className="space-y-2">
                {['Electronic', 'Ambient', 'Phantom', 'Top Hits 2024'].map(s => (
                  <button key={s} onClick={() => handleQueryChange(s)} className="flex items-center gap-3 w-full p-3 rounded-xl hover:bg-white/5 text-left transition-all">
                    <Clock className="w-4 h-4 text-white/20" />
                    <span className="text-sm text-white/60">{s}</span>
                  </button>
                ))}
              </div>
            </section>

            {/* Quick Actions */}
            <section className="mb-8">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} onClick={() => setPage('youtube')} className="relative rounded-2xl overflow-hidden p-5 text-left group">
                  <div className="absolute inset-0 bg-gradient-to-r from-red-600/15 to-red-900/15" />
                  <div className="absolute inset-0 glass" />
                  <div className="relative flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-red-500/15 flex items-center justify-center group-hover:bg-red-500/25 transition-colors"><Youtube className="w-6 h-6 text-red-500" /></div>
                    <div><h3 className="text-sm font-bold text-white">YouTube Music</h3><p className="text-[10px] text-white/30">Search & watch videos</p></div>
                    <ChevronRight className="w-4 h-4 text-white/15 ml-auto" />
                  </div>
                </motion.button>
                <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} onClick={() => setPage('recognize')} className="relative rounded-2xl overflow-hidden p-5 text-left group">
                  <div className="absolute inset-0 bg-gradient-to-r from-cent-600/15 to-cent-900/15" />
                  <div className="absolute inset-0 glass" />
                  <div className="relative flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-cent-500/15 flex items-center justify-center group-hover:bg-cent-500/25 transition-colors"><Mic className="w-6 h-6 text-cent-400" /></div>
                    <div><h3 className="text-sm font-bold text-white">Song Recognition</h3><p className="text-[10px] text-white/30">Identify songs with microphone</p></div>
                    <ChevronRight className="w-4 h-4 text-white/15 ml-auto" />
                  </div>
                </motion.button>
              </div>
            </section>

            {/* Genres */}
            <section>
              <h2 className="text-lg font-semibold text-white mb-4">Browse All</h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                {GENRES.map((genre, i) => (
                  <motion.button key={genre.name} initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.05 }}
                    onClick={() => handleQueryChange(genre.name)}
                    className="relative h-24 rounded-2xl overflow-hidden group"
                    style={{ background: `linear-gradient(135deg, ${genre.color}, ${genre.color}88)` }}>
                    <div className="absolute inset-0 bg-black/10 group-hover:bg-black/0 transition-colors" />
                    <span className="absolute top-4 left-4 text-sm font-bold text-white">{genre.name}</span>
                    <span className="absolute bottom-2 right-3 text-3xl opacity-50 rotate-12 group-hover:scale-125 transition-transform">{genre.icon}</span>
                  </motion.button>
                ))}
              </div>
            </section>
          </motion.div>
        ) : (
          <motion.div key="results" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-8">

            {/* Inline YouTube Player */}
            <AnimatePresence>
              {inlinePlayerId && (
                <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
                  <div className="glass-strong rounded-2xl overflow-hidden">
                    <div className="flex items-center justify-between p-3 border-b border-white/5">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                        <span className="text-xs text-white/40">Now Playing</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <a href={`https://www.youtube.com/watch?v=${inlinePlayerId}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 px-2 py-1 rounded-lg text-xs text-red-400 hover:bg-red-500/10 transition">
                          <ExternalLink className="w-3 h-3" /> YouTube
                        </a>
                        <button onClick={() => setInlinePlayerId(null)} className="p-1.5 rounded-lg hover:bg-white/10 transition"><X className="w-4 h-4 text-white/40" /></button>
                      </div>
                    </div>
                    <div className="aspect-video bg-black">
                      <iframe src={`https://www.youtube.com/embed/${inlinePlayerId}?autoplay=1&rel=0`} title="YouTube" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen className="w-full h-full" />
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* YouTube Results */}
            {(activeFilter === 'all' || activeFilter === 'youtube') && (
              <>
                {ytLoading && (
                  <div className="flex items-center justify-center py-10">
                    <div className="flex flex-col items-center gap-3">
                      <motion.div className="w-10 h-10 rounded-full border-2 border-red-500/20 border-t-red-500" animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }} />
                      <p className="text-xs text-white/25">Searching YouTube...</p>
                    </div>
                  </div>
                )}

                {ytError && (
                  <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-xs text-center">
                    {ytError}
                    <button onClick={() => { lastQueryRef.current = ''; searchingRef.current = false; doYouTubeSearch(query); }} className="ml-2 underline font-semibold">Retry</button>
                  </div>
                )}

                {!ytLoading && ytResults.length > 0 && (
                  <section>
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                        <Youtube className="w-5 h-5 text-red-500" /> YouTube <span className="text-xs text-white/20 font-normal">({ytResults.length})</span>
                      </h3>
                      <button onClick={() => setPage('youtube')} className="text-xs text-red-400 flex items-center gap-1 hover:gap-2 transition-all font-medium">
                        See All <ChevronRight className="w-3 h-3" />
                      </button>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
                      {ytResults.slice(0, activeFilter === 'youtube' ? 24 : 8).map((video, i) => (
                        <motion.div key={video.id} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }} whileHover={{ y: -3 }}
                          className={`group cursor-pointer ${inlinePlayerId === video.id ? 'ring-2 ring-red-500/50 rounded-xl' : ''}`}>
                          <div className="relative aspect-video rounded-xl overflow-hidden mb-2.5 bg-white/5 shadow-lg" onClick={() => playInline(video)}>
                            <img src={video.thumbnail} alt={video.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" loading="lazy" />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-all" />
                            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                              <div className="w-12 h-12 rounded-full bg-red-500/90 flex items-center justify-center shadow-2xl"><Play className="w-5 h-5 text-white fill-white ml-0.5" /></div>
                            </div>
                            {inlinePlayerId === video.id && (
                              <div className="absolute top-2 left-2 flex items-center gap-1.5 px-2 py-1 rounded-full bg-red-500/90">
                                <div className="flex items-end gap-[2px] h-3">{[0,1,2].map(j => (<motion.div key={j} className="w-[2px] bg-white rounded-full" animate={{ height: ['30%','100%','30%'] }} transition={{ duration: 0.6, repeat: Infinity, delay: j * 0.15 }} />))}</div>
                                <span className="text-[8px] text-white font-bold">LIVE</span>
                              </div>
                            )}
                            {video.duration && <span className="absolute bottom-2 right-2 px-1.5 py-0.5 rounded bg-black/80 text-[9px] text-white/90 font-mono">{video.duration}</span>}
                            <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                              <button onClick={(e) => { e.stopPropagation(); toggleSave(video.id); }} className={`p-1.5 rounded-lg backdrop-blur-sm transition ${savedVideos.includes(video.id) ? 'bg-cent-500/80 text-white' : 'bg-black/50 text-white/60'}`}>
                                <Bookmark className={`w-3 h-3 ${savedVideos.includes(video.id) ? 'fill-white' : ''}`} />
                              </button>
                            </div>
                          </div>
                          <div onClick={() => playInline(video)}>
                            <p className="text-xs font-semibold text-white/80 line-clamp-2 group-hover:text-white transition-colors leading-snug">{video.title}</p>
                            <p className="text-[10px] text-white/25 mt-1">{video.channel}</p>
                            <div className="flex items-center gap-2 mt-0.5">
                              {video.viewCount && <span className="text-[9px] text-white/15 flex items-center gap-0.5"><Eye className="w-2.5 h-2.5" /> {formatViewCount(video.viewCount)}</span>}
                              <span className="text-[9px] text-white/15">{getTimeAgo(video.publishedAt)}</span>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </section>
                )}
              </>
            )}

            {/* Artists */}
            {(activeFilter === 'all' || activeFilter === 'artists') && filteredArtists.length > 0 && (
              <section>
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2"><Headphones className="w-5 h-5 text-cent-400" /> Artists</h3>
                <div className="flex gap-4 overflow-x-auto pb-4 no-scrollbar">
                  {filteredArtists.map((artist, i) => (
                    <motion.div key={artist.id} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }} whileHover={{ y: -4 }}
                      className="flex-shrink-0 text-center cursor-pointer group" onClick={() => { setSelectedArtist(artist); setPage('artist'); }}>
                      <div className="w-24 h-24 rounded-full overflow-hidden mb-2 ring-2 ring-transparent group-hover:ring-cent-400/50 transition-all shadow-lg">
                        <img src={artist.image} alt={artist.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                      </div>
                      <p className="text-sm font-semibold text-white">{artist.name}</p>
                      <p className="text-xs text-white/30">{formatNumber(artist.followers)}</p>
                    </motion.div>
                  ))}
                </div>
              </section>
            )}

            {/* Genres */}
            {(activeFilter === 'all' || activeFilter === 'genres') && filteredGenres.length > 0 && (
              <section>
                <h3 className="text-lg font-semibold text-white mb-4">Genres</h3>
                <div className="flex gap-3 flex-wrap">
                  {filteredGenres.map(g => (
                    <motion.span key={g.name} whileHover={{ scale: 1.05 }} className="px-4 py-2 rounded-full text-sm font-medium text-white cursor-pointer"
                      style={{ background: g.color + '25', borderColor: g.color + '40', borderWidth: 1 }} onClick={() => handleQueryChange(g.name)}>
                      {g.icon} {g.name}
                    </motion.span>
                  ))}
                </div>
              </section>
            )}

            {/* Tracks */}
            {(activeFilter === 'all' || activeFilter === 'tracks') && filteredTracks.length > 0 && (
              <section>
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2"><Music2 className="w-5 h-5 text-cent-400" /> Tracks</h3>
                <div className="glass rounded-2xl overflow-hidden divide-y divide-white/[0.03]">
                  {filteredTracks.map((track, i) => (<TrackCard key={track.id} track={track} index={i} variant="list" />))}
                </div>
              </section>
            )}

            {/* No Results */}
            {filteredTracks.length === 0 && filteredArtists.length === 0 && filteredGenres.length === 0 && ytResults.length === 0 && !ytLoading && (
              <div className="text-center py-20">
                <p className="text-4xl mb-4">🔍</p>
                <p className="text-white/40 mb-2">No results for &ldquo;{query}&rdquo;</p>
                <p className="text-sm text-white/20 mb-6">Try different keywords or search YouTube</p>
                <button onClick={() => { lastQueryRef.current = ''; searchingRef.current = false; doYouTubeSearch(query); }} disabled={ytLoading}
                  className="px-6 py-3 rounded-xl bg-red-500 text-white text-sm font-bold shadow-lg shadow-red-500/20 flex items-center gap-2 mx-auto">
                  <Youtube className="w-4 h-4" /> Search YouTube
                </button>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
