import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { GENRES, TRACKS, ARTISTS, formatNumber } from '../data/mock';
import { TrackCard } from '../components/TrackCard';
import { useStore } from '../store/useStore';
import { TrendingUp, Flame, Star, Compass, Globe, Sparkles, Youtube, Search, ChevronRight, Brain, Music, Play, Download } from 'lucide-react';
import { getJamendoPopular, jamendoToTrack, type JamendoTrack } from '../services/jamendo';

function JamendoExplore() {
  const [tracks, setTracks] = useState<JamendoTrack[]>([]);
  const [loading, setLoading] = useState(true);
  const { setCurrentTrack, setIsPlaying, currentTrack, isPlaying, togglePlay, setPage } = useStore();

  useEffect(() => {
    getJamendoPopular(8).then(data => { setTracks(data); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  if (loading) return (
    <section className="mb-10">
      <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2"><Music className="w-5 h-5 text-emerald-400" /> Free Music</h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">{[0,1,2,3].map(i => <div key={i} className="aspect-square rounded-2xl skeleton" />)}</div>
    </section>
  );

  if (tracks.length === 0) return null;

  return (
    <section className="mb-10">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <Music className="w-5 h-5 text-emerald-400" /> Free Music
          <span className="text-[10px] text-emerald-400/50 font-normal ml-1">Jamendo</span>
        </h2>
        <button onClick={() => setPage('library')} className="text-xs text-emerald-400 flex items-center gap-1 font-medium">Downloads <ChevronRight className="w-3 h-3" /></button>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
        {tracks.map((jt, i) => {
          const track = jamendoToTrack(jt);
          const isActive = currentTrack?.id === track.id;
          return (
            <motion.div key={jt.id} initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} transition={{delay:i*0.05}} whileHover={{y:-4}}
              className="group cursor-pointer" onClick={() => { if (isActive) togglePlay(); else { setCurrentTrack(track); setIsPlaying(true); } }}>
              <div className="relative aspect-square rounded-2xl overflow-hidden mb-3 shadow-lg bg-white/5">
                <img src={jt.album_image||jt.image} alt={jt.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" loading="lazy" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition" />
                <div className="absolute bottom-3 right-3 w-10 h-10 rounded-full bg-emerald-500 shadow-lg flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all">
                  <Play className="w-4 h-4 text-white fill-white ml-0.5" />
                </div>
                {isActive && isPlaying && (
                  <div className="absolute top-2 left-2 px-2 py-1 rounded-full bg-emerald-500/90">
                    <div className="flex items-end gap-[2px] h-3">{[0,1,2].map(j=><motion.div key={j} className="w-[2px] bg-white rounded-full" animate={{height:['25%','100%','25%']}} transition={{duration:0.6,repeat:Infinity,delay:j*0.15}} />)}</div>
                  </div>
                )}
                <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition">
                  <a href={jt.audiodownload||jt.audio} target="_blank" rel="noopener noreferrer" onClick={e=>e.stopPropagation()} className="p-1.5 rounded-lg bg-black/50 backdrop-blur-sm text-white/60 hover:text-white transition">
                    <Download className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
              <p className={`text-sm font-semibold truncate ${isActive?'text-emerald-400':'text-white/80'}`}>{jt.name}</p>
              <p className="text-[11px] text-white/25 truncate mt-0.5">{jt.artist_name}</p>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}

export function ExplorePage() {
  const { setSelectedArtist, setPage } = useStore();

  return (
    <div className="space-y-10">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-3xl md:text-4xl font-display font-bold text-white mb-2 flex items-center gap-3">
          <Compass className="w-8 h-8 text-cent-400" /> Explore
        </h1>
        <p className="text-white/40">Discover new sounds, genres, and artists</p>
      </motion.div>

      {/* Featured Banner */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative rounded-3xl overflow-hidden"
      >
        <div className="absolute inset-0 bg-gradient-to-r from-cent-600/30 via-accent-pink/20 to-accent-blue/30 animate-gradient" />
        <div className="absolute inset-0 glass" />
        <div className="relative p-8 text-center">
          <Globe className="w-10 h-10 text-cent-400 mx-auto mb-3" />
          <h2 className="text-2xl font-bold text-white mb-2">Discover Worldwide</h2>
          <p className="text-sm text-white/40 max-w-md mx-auto">Explore music from 195+ countries, curated by AI to match your taste</p>
        </div>
      </motion.div>

      {/* Genres Grid */}
      <section>
        <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
          <Star className="w-5 h-5 text-cent-400" /> Browse Genres
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
          {GENRES.map((genre, i) => (
            <motion.button
              key={genre.name}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.05 }}
              whileHover={{ scale: 1.05, y: -3 }}
              className="relative p-5 rounded-2xl overflow-hidden glass hover-lift text-left group"
              style={{ borderColor: genre.color + '20' }}
            >
              <div className="absolute top-0 right-0 text-4xl opacity-20 group-hover:opacity-40 transition-opacity">{genre.icon}</div>
              <div className="absolute inset-0 opacity-5 group-hover:opacity-15 transition-opacity" style={{ background: `radial-gradient(circle at top right, ${genre.color}, transparent)` }} />
              <span className="text-3xl mb-2 block group-hover:scale-110 transition-transform">{genre.icon}</span>
              <p className="text-sm font-semibold text-white relative">{genre.name}</p>
            </motion.button>
          ))}
        </div>
      </section>

      {/* Charts */}
      <section>
        <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-cent-400" /> Top Charts
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="glass rounded-2xl p-5">
            <h3 className="text-sm font-semibold text-cent-400 mb-4 flex items-center gap-2">
              <Flame className="w-4 h-4" /> Top Tracks Global
            </h3>
            <div className="space-y-1">
              {TRACKS.slice(0, 5).map((track, i) => (
                <TrackCard key={track.id} track={track} index={i} variant="list" />
              ))}
            </div>
          </div>
          <div className="glass rounded-2xl p-5">
            <h3 className="text-sm font-semibold text-cent-400 mb-4 flex items-center gap-2">
              <Sparkles className="w-4 h-4" /> Rising Stars
            </h3>
            <div className="space-y-1">
              {TRACKS.slice(6, 11).map((track, i) => (
                <TrackCard key={track.id} track={track} index={i} variant="list" />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* New Releases */}
      <section>
        <h2 className="text-xl font-bold text-white mb-4">New Releases</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {TRACKS.map((track, i) => (
            <TrackCard key={track.id} track={track} index={i} />
          ))}
        </div>
      </section>

      {/* Quick Access Cards */}
      <section>
        <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-cent-400" /> Quick Access
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <motion.div
            whileHover={{ scale: 1.02, y: -3 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setPage('search')}
            className="relative rounded-2xl overflow-hidden cursor-pointer group"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-red-600/15 to-orange-600/15" />
            <div className="absolute inset-0 glass" />
            <div className="relative flex items-center gap-4 p-5">
              <div className="w-12 h-12 rounded-xl bg-red-500/15 flex items-center justify-center flex-shrink-0 group-hover:bg-red-500/25 transition-colors">
                <Youtube className="w-6 h-6 text-red-500" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  Search YouTube <Search className="w-3.5 h-3.5 text-white/30" />
                </h3>
                <p className="text-[10px] text-white/30">ابحث عن أغاني YouTube من بحث التطبيق</p>
              </div>
              <ChevronRight className="w-4 h-4 text-white/15 group-hover:text-white/30 transition-colors" />
            </div>
          </motion.div>

          <motion.div
            whileHover={{ scale: 1.02, y: -3 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setPage('aichat')}
            className="relative rounded-2xl overflow-hidden cursor-pointer group"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-cent-600/15 to-purple-600/15" />
            <div className="absolute inset-0 glass" />
            <div className="relative flex items-center gap-4 p-5">
              <div className="w-12 h-12 rounded-xl bg-cent-500/15 flex items-center justify-center flex-shrink-0 group-hover:bg-cent-500/25 transition-colors">
                <Brain className="w-6 h-6 text-cent-400" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-sm font-bold text-white">AI Recommendations</h3>
                <p className="text-[10px] text-white/30">اطلب من الذكاء الاصطناعي اقتراحات موسيقية</p>
              </div>
              <ChevronRight className="w-4 h-4 text-white/15 group-hover:text-white/30 transition-colors" />
            </div>
          </motion.div>
        </div>
      </section>

      {/* Jamendo Free Music */}
      <JamendoExplore />

      {/* Featured Artists */}
      <section>
        <h2 className="text-xl font-bold text-white mb-4">Featured Artists</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {ARTISTS.slice(0, 4).map((artist, i) => (
            <motion.div
              key={artist.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              whileHover={{ y: -6 }}
              className="glass rounded-2xl p-6 text-center cursor-pointer group"
              onClick={() => { setSelectedArtist(artist); setPage('artist'); }}
            >
              <div className="relative mx-auto w-24 h-24 mb-4">
                <motion.div className="absolute -inset-2 rounded-full bg-gradient-to-br from-cent-400/20 to-accent-pink/20 opacity-0 group-hover:opacity-100 blur-lg transition-opacity" />
                <div className="relative w-24 h-24 rounded-full overflow-hidden ring-2 ring-transparent group-hover:ring-cent-400/40 transition-all shadow-lg">
                  <img src={artist.image} alt={artist.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                </div>
              </div>
              <p className="text-sm font-semibold text-white">{artist.name}</p>
              <p className="text-xs text-white/40">{formatNumber(artist.followers)} followers</p>
              <p className="text-xs text-cent-400 mt-1">{artist.genre}</p>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
}
