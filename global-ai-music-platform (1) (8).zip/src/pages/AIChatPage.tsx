import { useState, useRef, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Bot, User, Sparkles, Music, Loader2, RefreshCw, Trash2, Zap, Headphones, Brain, MessageSquare } from 'lucide-react';
import { sendChatMessage, QUICK_PROMPTS, type ChatMessage } from '../services/ai';

export function AIChatPage() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [streamingContent, setStreamingContent] = useState('');
  const [error, setError] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, streamingContent, scrollToBottom]);

  const sendMessage = useCallback(async (text?: string) => {
    const content = text || input.trim();
    if (!content || isTyping) return;

    setInput('');
    setError('');

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content,
      timestamp: Date.now(),
    };

    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setIsTyping(true);
    setStreamingContent('');

    try {
      const response = await sendChatMessage(
        newMessages.filter(m => m.role !== 'system'),
        (chunk) => {
          setStreamingContent(chunk);
        }
      );

      const assistantMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response,
        timestamp: Date.now(),
      };

      setMessages(prev => [...prev, assistantMsg]);
      setStreamingContent('');
    } catch {
      setError('Failed to get response. Please try again.');
    } finally {
      setIsTyping(false);
    }
  }, [input, isTyping, messages]);

  const clearChat = () => {
    setMessages([]);
    setStreamingContent('');
    setError('');
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const hasMessages = messages.length > 0;

  return (
    <div className="flex flex-col h-[calc(100vh-200px)] md:h-[calc(100vh-140px)] max-w-4xl mx-auto">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-4 flex-shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-cent-400 to-cent-600 flex items-center justify-center shadow-lg shadow-cent-500/25">
                <Brain className="w-5 h-5 text-white" />
              </div>
              <motion.div
                className="absolute -inset-1 rounded-xl bg-cent-400/20 blur-lg -z-10"
                animate={{ opacity: [0.2, 0.5, 0.2] }}
                transition={{ duration: 3, repeat: Infinity }}
              />
            </div>
            <div>
              <h1 className="text-xl md:text-2xl font-display font-bold text-white flex items-center gap-2">
                CENT AI <Sparkles className="w-4 h-4 text-cent-400" />
              </h1>
              <p className="text-[10px] text-white/25">Powered by DeepSeek AI · Music Intelligence</p>
            </div>
          </div>
          {hasMessages && (
            <button
              onClick={clearChat}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs text-white/30 hover:text-white/60 hover:bg-white/5 transition"
            >
              <Trash2 className="w-3 h-3" /> Clear
            </button>
          )}
        </div>
      </motion.div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto no-scrollbar space-y-4 pb-4">
        {!hasMessages && !isTyping ? (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="h-full flex flex-col items-center justify-center px-4">
            {/* Welcome */}
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: 'spring', stiffness: 200, damping: 15 }}
              className="relative mb-8"
            >
              <motion.div
                className="absolute -inset-6 rounded-full bg-cent-400/10 blur-3xl"
                animate={{ scale: [1, 1.3, 1], opacity: [0.2, 0.4, 0.2] }}
                transition={{ duration: 4, repeat: Infinity }}
              />
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-cent-400 via-cent-500 to-cent-700 flex items-center justify-center shadow-2xl shadow-cent-500/30 relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-white/20 via-transparent to-transparent" />
                <Bot className="w-10 h-10 text-white relative z-10" />
              </div>
            </motion.div>

            <h2 className="text-2xl md:text-3xl font-bold text-white mb-2 text-center">
              Hello! I'm <span className="text-gradient">CENT AI</span>
            </h2>
            <p className="text-sm text-white/30 mb-8 text-center max-w-md">
              Your intelligent music companion. Ask me about songs, artists, genres, playlists, music theory, and more!
            </p>

            {/* Capabilities */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 w-full max-w-2xl mb-8">
              {[
                { icon: Music, label: 'Recommendations', color: '#7a5af8' },
                { icon: Headphones, label: 'Playlist Creation', color: '#ec4899' },
                { icon: MessageSquare, label: 'Lyrics Analysis', color: '#3b82f6' },
                { icon: Zap, label: 'Music Theory', color: '#f59e0b' },
              ].map((cap, i) => (
                <motion.div
                  key={cap.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 + i * 0.1 }}
                  className="glass rounded-xl p-3 text-center"
                >
                  <cap.icon className="w-5 h-5 mx-auto mb-2" style={{ color: cap.color }} />
                  <p className="text-[10px] text-white/40 font-medium">{cap.label}</p>
                </motion.div>
              ))}
            </div>

            {/* Quick Prompts */}
            <div className="w-full max-w-2xl">
              <h3 className="text-xs font-semibold text-white/20 mb-3 text-center uppercase tracking-wider">Try asking</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {QUICK_PROMPTS.map((qp, i) => (
                  <motion.button
                    key={i}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.5 + i * 0.06 }}
                    onClick={() => sendMessage(qp.prompt)}
                    className="flex items-center gap-2 p-3 rounded-xl glass text-left text-sm text-white/50 hover:text-white hover:bg-white/[0.06] transition-all group"
                  >
                    <span className="text-base">{qp.text.slice(0, 2)}</span>
                    <span className="flex-1 text-xs">{qp.text.slice(2).trim()}</span>
                    <Send className="w-3 h-3 text-white/10 group-hover:text-cent-400 transition-colors" />
                  </motion.button>
                ))}
              </div>
            </div>
          </motion.div>
        ) : (
          <>
            {messages.map((msg, i) => (
              <MessageBubble key={msg.id} message={msg} index={i} />
            ))}

            {/* Streaming response */}
            {isTyping && streamingContent && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="flex gap-3">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cent-400 to-cent-600 flex items-center justify-center flex-shrink-0 mt-1">
                  <Bot className="w-4 h-4 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="glass rounded-2xl rounded-tl-md p-4 max-w-[85%]">
                    <div className="text-sm text-white/80 whitespace-pre-wrap leading-relaxed">{streamingContent}</div>
                    <motion.span
                      className="inline-block w-1.5 h-4 bg-cent-400 rounded-full ml-0.5 align-text-bottom"
                      animate={{ opacity: [1, 0, 1] }}
                      transition={{ duration: 0.8, repeat: Infinity }}
                    />
                  </div>
                </div>
              </motion.div>
            )}

            {/* Typing indicator */}
            {isTyping && !streamingContent && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex gap-3">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cent-400 to-cent-600 flex items-center justify-center flex-shrink-0">
                  <Bot className="w-4 h-4 text-white" />
                </div>
                <div className="glass rounded-2xl rounded-tl-md p-4 flex items-center gap-2">
                  <div className="flex gap-1">
                    {[0, 1, 2].map(i => (
                      <motion.div
                        key={i}
                        className="w-2 h-2 rounded-full bg-cent-400"
                        animate={{ y: [0, -6, 0], opacity: [0.4, 1, 0.4] }}
                        transition={{ duration: 0.8, repeat: Infinity, delay: i * 0.15 }}
                      />
                    ))}
                  </div>
                  <span className="text-xs text-white/25 ml-1">CENT AI is thinking...</span>
                </div>
              </motion.div>
            )}

            {/* Error */}
            <AnimatePresence>
              {error && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="flex gap-3 items-start"
                >
                  <div className="w-8 h-8 rounded-lg bg-red-500/15 flex items-center justify-center flex-shrink-0">
                    <Bot className="w-4 h-4 text-red-400" />
                  </div>
                  <div className="p-4 rounded-2xl bg-red-500/10 border border-red-500/20 text-sm text-red-400 flex items-center gap-3">
                    <span>{error}</span>
                    <button
                      onClick={() => { setError(''); sendMessage(messages[messages.length - 1]?.content); }}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-red-500/15 text-red-400 text-xs font-medium hover:bg-red-500/25 transition flex-shrink-0"
                    >
                      <RefreshCw className="w-3 h-3" /> Retry
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div ref={messagesEndRef} />
          </>
        )}
      </div>

      {/* Input Area */}
      <div className="flex-shrink-0 pt-3">
        {hasMessages && (
          <div className="flex gap-2 mb-3 overflow-x-auto no-scrollbar pb-1">
            {QUICK_PROMPTS.slice(0, 4).map((qp, i) => (
              <button
                key={i}
                onClick={() => sendMessage(qp.prompt)}
                disabled={isTyping}
                className="px-3 py-1.5 rounded-full glass text-[10px] text-white/30 hover:text-white/60 whitespace-nowrap transition disabled:opacity-50"
              >
                {qp.text}
              </button>
            ))}
          </div>
        )}

        <div className="relative glass rounded-2xl overflow-hidden border border-white/5 focus-within:border-cent-400/30 transition-colors">
          <textarea
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask CENT AI about music..."
            rows={1}
            className="w-full px-4 py-3.5 pr-14 bg-transparent text-white text-sm placeholder:text-white/20 focus:outline-none resize-none max-h-32"
            style={{ minHeight: 48 }}
          />
          <button
            onClick={() => sendMessage()}
            disabled={!input.trim() || isTyping}
            className="absolute right-2 bottom-2 w-9 h-9 rounded-xl bg-gradient-to-r from-cent-400 to-cent-600 flex items-center justify-center text-white disabled:opacity-30 transition-opacity shadow-lg shadow-cent-500/20"
          >
            {isTyping ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Send className="w-4 h-4" />
            )}
          </button>
        </div>

        <p className="text-[9px] text-white/[0.08] text-center mt-2">
          CENT AI · Powered by DeepSeek · Responses may not always be accurate
        </p>
      </div>
    </div>
  );
}

function MessageBubble({ message, index }: { message: ChatMessage; index: number }) {
  const isUser = message.role === 'user';

  return (
    <motion.div
      initial={{ opacity: 0, y: 10, x: isUser ? 10 : -10 }}
      animate={{ opacity: 1, y: 0, x: 0 }}
      transition={{ delay: index * 0.05 }}
      className={`flex gap-3 ${isUser ? 'flex-row-reverse' : ''}`}
    >
      <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-1 ${
        isUser
          ? 'bg-white/10'
          : 'bg-gradient-to-br from-cent-400 to-cent-600'
      }`}>
        {isUser ? <User className="w-4 h-4 text-white/60" /> : <Bot className="w-4 h-4 text-white" />}
      </div>
      <div className={`flex-1 min-w-0 ${isUser ? 'flex justify-end' : ''}`}>
        <div className={`rounded-2xl p-4 max-w-[85%] ${
          isUser
            ? 'bg-cent-500/15 border border-cent-500/10 rounded-tr-md'
            : 'glass rounded-tl-md'
        }`}>
          <div className="text-sm text-white/80 whitespace-pre-wrap leading-relaxed break-words">
            {message.content}
          </div>
        </div>
        <p className={`text-[9px] text-white/10 mt-1 ${isUser ? 'text-right' : ''}`}>
          {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </p>
      </div>
    </motion.div>
  );
}
