import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, Clock, Download, ListMusic, Plus, Music, TrendingUp, Headphones, BarChart3, Calendar, Star, Shuffle, Play, Pause, MoreHorizontal, Search, Youtube, X } from 'lucide-react';
import { TRACKS, PLAYLISTS, formatNumber, formatDuration } from '../data/mock';
import { useStore, type Track } from '../store/useStore';
import { searchJamendo, jamendoToTrack, formatJamendoDuration, type JamendoTrack } from '../services/jamendo';
import { showToast } from '../services/share';

type Tab = 'playlists' | 'favorites' | 'history' | 'downloads' | 'stats';

/* ========== Jamendo Download Card ========== */
function JamendoCard({ jt, onPlay }: { jt: JamendoTrack; onPlay: (t: Track) => void }) {
  const { favorites, toggleFavorite } = useStore();
  const track = jamendoToTrack(jt);
  const isFav = favorites.includes(track.id);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex items-center gap-3 p-3 rounded-xl hover:bg-white/[0.03] transition group cursor-pointer"
      onClick={() => onPlay(track)}
    >
      <div className="relative w-12 h-12 rounded-lg overflow-hidden flex-shrink-0 shadow-md bg-white/5">
        <img src={jt.album_image || jt.image} alt="" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
          <Play className="w-4 h-4 text-white fill-white ml-0.5" />
        </div>
        <div className="absolute bottom-0 right-0 w-4 h-4 bg-emerald-500 rounded-tl-md flex items-center justify-center">
          <Download className="w-2.5 h-2.5 text-white" />
        </div>
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-white/80 truncate">{jt.name}</p>
        <p className="text-[10px] text-white/25 truncate">{jt.artist_name} · {jt.album_name}</p>
      </div>
      <span className="text-[10px] text-white/15 font-mono hidden sm:block">{formatJamendoDuration(jt.duration)}</span>
      <button
        onClick={(e) => { e.stopPropagation(); toggleFavorite(track.id, track); }}
        className="opacity-0 group-hover:opacity-100 transition-opacity p-1"
      >
        <Heart className={`w-4 h-4 ${isFav ? 'fill-cent-400 text-cent-400' : 'text-white/15'}`} />
      </button>
      <a
        href={jt.audiodownload || jt.audio}
        target="_blank"
        rel="noopener noreferrer"
        onClick={(e) => { e.stopPropagation(); showToast('📥 Downloading from Jamendo...', 'success'); }}
        className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-emerald-500/20"
        title="Download MP3"
      >
        <Download className="w-3.5 h-3.5" />
      </a>
    </motion.div>
  );
}

/* ========== Favorite Track Row (supports YT + Jamendo + regular) ========== */
function FavoriteTrackRow({ track, index }: { track: Track; index: number }) {
  const { currentTrack, setCurrentTrack, isPlaying, togglePlay, toggleFavorite } = useStore();
  const isActive = currentTrack?.id === track.id;
  const isYT = track.id.startsWith('yt_');
  const isJM = track.id.startsWith('jm_');

  const handlePlay = () => {
    if (isActive) {
      togglePlay();
    } else {
      if (isYT) {
        // For YouTube, import and use playYouTubeVideo
        import('../services/youtubePlayer').then(({ playYouTubeVideo }) => {
          const videoId = track.id.replace('yt_', '');
          playYouTubeVideo({
            id: videoId,
            title: track.title,
            channel: track.artist,
            thumbnail: track.cover,
            thumbnailHigh: track.cover,
            publishedAt: '',
            description: '',
          });
        });
      } else if (isJM) {
        // Jamendo tracks have audio URLs
        setCurrentTrack(track);
        useStore.getState().setIsPlaying(true);
      } else {
        setCurrentTrack(track);
        useStore.getState().setIsPlaying(true);
      }
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.04 }}
      className={`flex items-center gap-4 p-3 rounded-xl group cursor-pointer transition-all ${
        isActive ? 'bg-cent-500/6' : 'hover:bg-white/[0.02]'
      }`}
      onClick={handlePlay}
    >
      <span className={`text-sm w-6 text-right font-mono ${isActive ? 'text-cent-400' : 'text-white/15'}`}>
        {isActive && isPlaying ? (
          <div className="flex items-end gap-[2px] h-4 justify-end">
            {[0, 1, 2].map(i => (
              <motion.div
                key={i}
                className="w-[2px] bg-cent-400 rounded-full"
                animate={{ height: ['20%', '100%', '20%'] }}
                transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.15 }}
              />
            ))}
          </div>
        ) : (
          index + 1
        )}
      </span>
      <div className="relative w-11 h-11 rounded-lg overflow-hidden flex-shrink-0 shadow-md">
        <img src={track.cover} alt="" className="w-full h-full object-cover" />
        {isYT && (
          <div className="absolute bottom-0 right-0 w-4 h-4 bg-red-500 rounded-tl-md flex items-center justify-center">
            <Youtube className="w-2.5 h-2.5 text-white" />
          </div>
        )}
        {isJM && (
          <div className="absolute bottom-0 right-0 w-4 h-4 bg-emerald-500 rounded-tl-md flex items-center justify-center">
            <Download className="w-2.5 h-2.5 text-white" />
          </div>
        )}
        <div className={`absolute inset-0 bg-black/40 flex items-center justify-center transition-opacity ${isActive ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}>
          {isActive && isPlaying ? <Pause className="w-4 h-4 text-white" /> : <Play className="w-4 h-4 text-white ml-0.5" />}
        </div>
      </div>
      <div className="flex-1 min-w-0">
        <p className={`text-sm font-medium truncate ${isActive ? 'text-cent-400' : 'text-white/80'}`}>{track.title}</p>
        <p className="text-[11px] text-white/25 truncate flex items-center gap-1">
          {isYT && <Youtube className="w-3 h-3 text-red-400 flex-shrink-0" />}
          {isJM && <Download className="w-3 h-3 text-emerald-400 flex-shrink-0" />}
          {track.artist} · {track.album}
        </p>
      </div>
      <span className="text-[11px] text-white/15 font-mono w-10 text-right hidden sm:block">{formatDuration(track.duration)}</span>
      <motion.button
        whileTap={{ scale: 0.8 }}
        onClick={(e) => { e.stopPropagation(); toggleFavorite(track.id, track); }}
        className="p-1"
      >
        <Heart className="w-4 h-4 fill-cent-400 text-cent-400" />
      </motion.button>
    </motion.div>
  );
}

export function LibraryPage() {
  const [activeTab, setActiveTab] = useState<Tab>('playlists');
  const { favorites, likedTracksMap, setSelectedPlaylist, setPage, setCurrentTrack, setIsPlaying, setQueue } = useStore();

  // Get all favorite tracks from both mock data and liked tracks map
  const favTracks: Track[] = [];
  for (const id of favorites) {
    if (likedTracksMap[id]) {
      favTracks.push(likedTracksMap[id]);
    } else {
      const mockTrack = TRACKS.find(t => t.id === id);
      if (mockTrack) favTracks.push(mockTrack);
    }
  }

  // Jamendo search for downloads section
  const [jmQuery, setJmQuery] = useState('');
  const [jmResults, setJmResults] = useState<JamendoTrack[]>([]);
  const [jmLoading, setJmLoading] = useState(false);
  const [jmPopular, setJmPopular] = useState<JamendoTrack[]>([]);
  const [jmPopularLoading, setJmPopularLoading] = useState(false);

  const loadPopular = useCallback(async () => {
    if (jmPopular.length > 0 || jmPopularLoading) return;
    setJmPopularLoading(true);
    try {
      const { getJamendoPopular } = await import('../services/jamendo');
      const data = await getJamendoPopular(12);
      setJmPopular(data);
    } catch { /* ignore */ }
    setJmPopularLoading(false);
  }, [jmPopular.length, jmPopularLoading]);

  useEffect(() => {
    if (activeTab === 'downloads') loadPopular();
  }, [activeTab, loadPopular]);

  const handleJmSearch = async () => {
    if (!jmQuery.trim()) return;
    setJmLoading(true);
    try {
      const results = await searchJamendo(jmQuery, 15);
      setJmResults(results);
    } catch { /* ignore */ }
    setJmLoading(false);
  };

  const playJamendo = (track: Track) => {
    setCurrentTrack(track);
    setIsPlaying(true);
  };

  // History items
  const historyItems = TRACKS.slice(0, 10).map((track, i) => ({
    ...track,
    playedAt: i === 0 ? 'Now' : i < 3 ? `${i * 12}m ago` : i < 6 ? `${i}h ago` : `${i - 4}d ago`,
    listenedPct: 100 - i * 8,
  }));

  const TABS: { id: Tab; label: string; icon: typeof Heart; count?: number }[] = [
    { id: 'playlists', label: 'Playlists', icon: ListMusic, count: PLAYLISTS.length + 1 },
    { id: 'favorites', label: 'Favorites', icon: Heart, count: favTracks.length },
    { id: 'history', label: 'History', icon: Clock },
    { id: 'downloads', label: 'Downloads', icon: Download },
    { id: 'stats', label: 'Stats', icon: BarChart3 },
  ];

  const playAllFavorites = () => {
    if (favTracks.length > 0) {
      setQueue(favTracks);
      setCurrentTrack(favTracks[0]);
      setIsPlaying(true);
    }
  };

  return (
    <div className="space-y-8">
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
        <div className="flex items-center justify-between mb-2">
          <div>
            <h1 className="text-3xl font-display font-bold text-white">Your Library</h1>
            <p className="text-white/30 text-sm mt-1">Your music, organized and personalized</p>
          </div>
          <div className="flex items-center gap-2">
            <button className="p-2 rounded-xl glass text-white/30 hover:text-white/60 transition"><Search className="w-5 h-5" /></button>
            <button className="p-2 rounded-xl glass text-white/30 hover:text-white/60 transition"><Plus className="w-5 h-5" /></button>
          </div>
        </div>
      </motion.div>

      {/* Quick Stats */}
      <div className="glass rounded-2xl p-4 flex items-center justify-around">
        <div className="text-center"><p className="text-xl font-bold text-white">{favTracks.length}</p><p className="text-[9px] text-white/25 uppercase">Liked</p></div>
        <div className="w-px h-8 bg-white/5" />
        <div className="text-center"><p className="text-xl font-bold text-white">{PLAYLISTS.length}</p><p className="text-[9px] text-white/25 uppercase">Playlists</p></div>
        <div className="w-px h-8 bg-white/5" />
        <div className="text-center"><p className="text-xl font-bold text-white">342h</p><p className="text-[9px] text-white/25 uppercase">Listened</p></div>
        <div className="w-px h-8 bg-white/5 hidden sm:block" />
        <div className="text-center hidden sm:block"><p className="text-xl font-bold text-white">{favTracks.filter(t => t.id.startsWith('yt_')).length}</p><p className="text-[9px] text-white/25 uppercase">YouTube ♡</p></div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
        {TABS.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
              activeTab === tab.id ? 'bg-cent-500 text-white shadow-lg shadow-cent-500/20' : 'bg-white/5 text-white/40 hover:text-white/60'
            }`}>
            <tab.icon className="w-4 h-4" />{tab.label}
            {tab.count !== undefined && <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-white/10">{tab.count}</span>}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div key={activeTab} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>

          {/* ═══ PLAYLISTS ═══ */}
          {activeTab === 'playlists' && (
            <div className="space-y-6">
              <motion.button whileHover={{ scale: 1.01 }} className="w-full flex items-center gap-4 p-4 rounded-2xl glass hover:bg-white/[0.06] transition-all group">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-cent-400 to-cent-600 flex items-center justify-center shadow-lg shadow-cent-500/20">
                  <Plus className="w-6 h-6 text-white" />
                </div>
                <div className="text-left"><p className="text-sm font-semibold text-white">Create New Playlist</p><p className="text-[10px] text-white/30">Start a new music collection</p></div>
              </motion.button>

              {/* Liked Songs Card */}
              <motion.div whileHover={{ scale: 1.01 }} onClick={() => { setActiveTab('favorites'); }}
                className="flex items-center gap-4 p-4 rounded-2xl overflow-hidden cursor-pointer group relative">
                <div className="absolute inset-0 bg-gradient-to-r from-pink-600/15 via-rose-600/10 to-transparent" />
                <div className="absolute inset-0 glass" />
                <div className="relative w-14 h-14 rounded-xl bg-gradient-to-br from-pink-500 to-rose-600 flex items-center justify-center shadow-lg shadow-pink-500/20">
                  <Heart className="w-6 h-6 text-white fill-white" />
                </div>
                <div className="relative flex-1"><p className="text-sm font-semibold text-white">Liked Songs</p>
                  <p className="text-[10px] text-white/30">{favTracks.length} songs{favTracks.length > 0 ? ` · ${formatDuration(favTracks.reduce((a, t) => a + t.duration, 0))} total` : ' · Add songs you love'}</p>
                </div>
                <div className="relative flex items-center gap-2">
                  {favTracks.length > 0 && (
                    <div className="w-10 h-10 rounded-full bg-pink-500 flex items-center justify-center shadow-lg shadow-pink-500/30 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Play className="w-4 h-4 text-white fill-white ml-0.5" />
                    </div>
                  )}
                </div>
              </motion.div>

              {/* Playlist Grid */}
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {PLAYLISTS.map((pl, i) => (
                  <motion.div key={pl.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }}
                    whileHover={{ y: -4 }} className="cursor-pointer group" onClick={() => { setSelectedPlaylist(pl); setPage('playlist'); }}>
                    <div className={`aspect-square rounded-2xl overflow-hidden mb-3 bg-gradient-to-br ${pl.gradient} p-4 flex flex-col justify-end shadow-lg relative`}>
                      <img src={pl.cover} alt="" className="absolute inset-0 w-full h-full object-cover opacity-30 mix-blend-overlay" />
                      <motion.div className="absolute bottom-3 right-3 w-11 h-11 rounded-full bg-white shadow-xl flex items-center justify-center opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition-all duration-300">
                        <Play className="w-4 h-4 text-black fill-black ml-0.5" />
                      </motion.div>
                      <p className="relative text-base font-bold text-white drop-shadow-lg">{pl.name}</p>
                      <p className="relative text-[10px] text-white/60">{pl.trackCount} tracks</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          )}

          {/* ═══ FAVORITES — FIXED! ═══ */}
          {activeTab === 'favorites' && (
            <div>
              {favTracks.length > 0 ? (
                <div className="space-y-1">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <p className="text-sm text-white/40">{favTracks.length} liked songs</p>
                      <p className="text-[10px] text-white/20">
                        {favTracks.filter(t => t.id.startsWith('yt_')).length} from YouTube · 
                        {favTracks.filter(t => t.id.startsWith('jm_')).length} from Jamendo · 
                        {favTracks.filter(t => !t.id.startsWith('yt_') && !t.id.startsWith('jm_')).length} from CENT
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <button onClick={playAllFavorites} className="flex items-center gap-2 px-4 py-2 rounded-full bg-cent-500 text-white text-xs font-bold shadow-lg shadow-cent-500/20">
                        <Play className="w-3.5 h-3.5 fill-white" /> Play All
                      </button>
                      <button className="p-2 rounded-full glass text-white/30"><Shuffle className="w-4 h-4" /></button>
                    </div>
                  </div>
                  <div className="glass rounded-2xl overflow-hidden divide-y divide-white/[0.03]">
                    {favTracks.map((track, i) => (
                      <FavoriteTrackRow key={track.id} track={track} index={i} />
                    ))}
                  </div>
                </div>
              ) : (
                <div className="text-center py-20">
                  <Heart className="w-16 h-16 text-white/10 mx-auto mb-4" />
                  <p className="text-white/40 mb-2 text-lg">No favorites yet</p>
                  <p className="text-white/20 text-sm mb-6">Tap the ♡ icon on any track, YouTube video, or Jamendo song to save it here</p>
                  <button onClick={() => setPage('explore')} className="px-6 py-2.5 rounded-full bg-cent-500 text-white text-sm font-semibold shadow-lg shadow-cent-500/20">
                    Discover Music
                  </button>
                </div>
              )}
            </div>
          )}

          {/* ═══ HISTORY ═══ */}
          {activeTab === 'history' && (
            <div className="space-y-1">
              <div className="flex items-center justify-between mb-4">
                <p className="text-sm text-white/40">Recently played</p>
                <button className="text-xs text-cent-400 font-medium">Clear History</button>
              </div>
              {historyItems.map((track, i) => (
                <motion.div key={track.id + i} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.04 }}
                  className="flex items-center gap-4 p-3 rounded-xl group cursor-pointer hover:bg-white/[0.02] transition-all"
                  onClick={() => { setCurrentTrack(track); setIsPlaying(true); }}>
                  <div className="relative w-11 h-11 rounded-lg overflow-hidden flex-shrink-0 shadow-md">
                    <img src={track.cover} alt="" className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <Play className="w-4 h-4 text-white fill-white ml-0.5" />
                    </div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white/80 truncate">{track.title}</p>
                    <p className="text-[10px] text-white/25">{track.artist}</p>
                  </div>
                  <div className="text-right hidden sm:block">
                    <p className="text-[10px] text-white/15 font-mono">{track.playedAt}</p>
                    <div className="w-16 h-1 bg-white/5 rounded-full mt-1">
                      <div className="h-full bg-cent-400/30 rounded-full" style={{ width: `${track.listenedPct}%` }} />
                    </div>
                  </div>
                  <button className="opacity-0 group-hover:opacity-100 transition-opacity p-1"><MoreHorizontal className="w-4 h-4 text-white/15" /></button>
                </motion.div>
              ))}
            </div>
          )}

          {/* ═══ DOWNLOADS — Jamendo Integration ═══ */}
          {activeTab === 'downloads' && (
            <div className="space-y-6">
              {/* Jamendo Search */}
              <div className="glass-premium rounded-2xl p-5">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/15 flex items-center justify-center">
                    <Download className="w-5 h-5 text-emerald-400" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white">Free Music Downloads</h3>
                    <p className="text-[10px] text-white/25">Powered by Jamendo · Free & legal MP3 downloads</p>
                  </div>
                </div>
                <div className="relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
                  <input
                    type="text"
                    value={jmQuery}
                    onChange={e => setJmQuery(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && handleJmSearch()}
                    placeholder="Search free music to download..."
                    className="w-full pl-11 pr-24 py-3 rounded-xl bg-white/5 border border-white/10 text-white text-sm placeholder:text-white/20 focus:outline-none focus:border-emerald-500/50"
                    dir="auto"
                  />
                  <div className="absolute right-2 top-1/2 -translate-y-1/2 flex gap-1">
                    {jmQuery && (
                      <button onClick={() => { setJmQuery(''); setJmResults([]); }} className="p-2 rounded-lg hover:bg-white/10 transition">
                        <X className="w-3.5 h-3.5 text-white/30" />
                      </button>
                    )}
                    <button onClick={handleJmSearch} disabled={jmLoading || !jmQuery.trim()}
                      className="px-4 py-2 rounded-lg bg-emerald-500 text-white text-xs font-bold disabled:opacity-50">
                      {jmLoading ? '...' : 'Search'}
                    </button>
                  </div>
                </div>
              </div>

              {/* Jamendo Results */}
              {jmResults.length > 0 && (
                <div className="glass rounded-2xl overflow-hidden">
                  <div className="p-4 border-b border-white/5 flex items-center justify-between">
                    <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                      <Music className="w-4 h-4 text-emerald-400" /> {jmResults.length} results · Free downloads
                    </h3>
                  </div>
                  <div className="divide-y divide-white/[0.03]">
                    {jmResults.map(jt => (
                      <JamendoCard key={jt.id} jt={jt} onPlay={playJamendo} />
                    ))}
                  </div>
                </div>
              )}

              {/* Quick Search Categories */}
              {jmResults.length === 0 && !jmLoading && (
                <div>
                  <p className="text-xs text-white/25 mb-3">Quick search:</p>
                  <div className="flex flex-wrap gap-2">
                    {['Electronic', 'Rock', 'Jazz', 'Classical', 'Pop', 'Ambient', 'Hip Hop', 'Chill'].map(cat => (
                      <button key={cat} onClick={() => { setJmQuery(cat); searchJamendo(cat, 15).then(setJmResults); }}
                        className="px-3 py-1.5 rounded-full glass text-xs text-white/40 hover:text-white/70 transition">
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Popular on Jamendo */}
              {jmPopular.length > 0 && jmResults.length === 0 && (
                <div className="glass rounded-2xl overflow-hidden">
                  <div className="p-4 border-b border-white/5">
                    <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-emerald-400" /> Popular on Jamendo
                    </h3>
                  </div>
                  <div className="divide-y divide-white/[0.03]">
                    {jmPopular.slice(0, 8).map(jt => (
                      <JamendoCard key={jt.id} jt={jt} onPlay={playJamendo} />
                    ))}
                  </div>
                </div>
              )}

              {jmPopularLoading && (
                <div className="text-center py-10">
                  <motion.div className="w-10 h-10 mx-auto rounded-full border-2 border-emerald-500/20 border-t-emerald-500"
                    animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }} />
                  <p className="text-xs text-white/25 mt-3">Loading popular tracks...</p>
                </div>
              )}

              {/* Previously downloaded (demo) */}
              <div>
                <h3 className="text-sm font-semibold text-white/40 mb-3">Previously Downloaded</h3>
                {TRACKS.slice(0, 3).map((track, i) => (
                  <motion.div key={track.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}
                    className="flex items-center gap-4 p-4 rounded-2xl glass mb-2 group cursor-pointer" onClick={() => { setCurrentTrack(track); setIsPlaying(true); }}>
                    <div className="relative w-14 h-14 rounded-xl overflow-hidden flex-shrink-0 shadow-lg">
                      <img src={track.cover} alt="" className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <Play className="w-5 h-5 text-white fill-white ml-0.5" />
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-white">{track.title}</p>
                      <p className="text-xs text-white/30">{track.artist} · {track.album}</p>
                      <span className="text-[10px] text-emerald-400/60 flex items-center gap-1 mt-1"><Download className="w-3 h-3" /> Downloaded · 16 MB</span>
                    </div>
                    <span className="text-[10px] px-2 py-1 rounded-full bg-emerald-500/10 text-emerald-400/70">FLAC</span>
                  </motion.div>
                ))}
              </div>
            </div>
          )}

          {/* ═══ STATS ═══ */}
          {activeTab === 'stats' && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { label: 'Total Plays', value: '12,847', icon: Music, color: '#7a5af8' },
                  { label: 'Listening Time', value: '342h', icon: Headphones, color: '#ec4899' },
                  { label: 'Liked Songs', value: String(favTracks.length), icon: Heart, color: '#ef4444' },
                  { label: 'This Week', value: '28h', icon: Calendar, color: '#10b981' },
                ].map((stat, i) => (
                  <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }} className="glass rounded-2xl p-5 text-center">
                    <stat.icon className="w-6 h-6 mx-auto mb-3" style={{ color: stat.color }} />
                    <p className="text-2xl font-bold text-white">{stat.value}</p>
                    <p className="text-[10px] text-white/30 mt-1">{stat.label}</p>
                  </motion.div>
                ))}
              </div>

              <div className="glass rounded-2xl p-6">
                <h3 className="text-sm font-semibold text-white/60 mb-4 uppercase tracking-wider flex items-center gap-2"><Star className="w-4 h-4 text-cent-400" /> Top Genres</h3>
                <div className="space-y-3">
                  {[
                    { name: 'Electronic', pct: 42, plays: '5.4K', color: '#7a5af8' },
                    { name: 'Ambient', pct: 28, plays: '3.6K', color: '#3b82f6' },
                    { name: 'Synthwave', pct: 18, plays: '2.3K', color: '#ec4899' },
                    { name: 'Lo-fi', pct: 12, plays: '1.5K', color: '#10b981' },
                  ].map(g => (
                    <div key={g.name}>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-white/60">{g.name}</span>
                        <div className="flex items-center gap-3">
                          <span className="text-[10px] text-white/20 font-mono">{g.plays} plays</span>
                          <span className="text-white/30 font-mono text-xs">{g.pct}%</span>
                        </div>
                      </div>
                      <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                        <motion.div initial={{ width: 0 }} animate={{ width: `${g.pct}%` }} transition={{ duration: 1, delay: 0.3 }} className="h-full rounded-full" style={{ background: g.color }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="glass rounded-2xl p-6">
                <h3 className="text-sm font-semibold text-white/60 mb-4 uppercase tracking-wider flex items-center gap-2"><TrendingUp className="w-4 h-4 text-cent-400" /> Your Top Artists</h3>
                <div className="space-y-3">
                  {TRACKS.slice(0, 5).map((track, i) => (
                    <div key={track.id} className="flex items-center gap-3">
                      <span className={`text-sm font-bold w-6 text-center ${i === 0 ? 'text-yellow-400' : i === 1 ? 'text-gray-400' : i === 2 ? 'text-amber-600' : 'text-white/15'}`}>{i + 1}</span>
                      <div className="w-8 h-8 rounded-full overflow-hidden"><img src={track.cover} alt="" className="w-full h-full object-cover" /></div>
                      <div className="flex-1 min-w-0"><p className="text-sm font-medium text-white/70">{track.artist}</p><p className="text-[10px] text-white/20">{formatNumber(track.plays)} plays</p></div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="glass rounded-2xl p-6">
                <h3 className="text-sm font-semibold text-white/60 mb-4 uppercase tracking-wider">Weekly Activity</h3>
                <div className="flex items-end justify-between gap-2 h-24">
                  {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, i) => {
                    const heights = [45, 72, 55, 88, 62, 95, 78];
                    return (
                      <div key={day} className="flex-1 flex flex-col items-center gap-2">
                        <motion.div initial={{ height: 0 }} animate={{ height: `${heights[i]}%` }} transition={{ delay: i * 0.08, duration: 0.5 }}
                          className="w-full rounded-t-md" style={{ background: `linear-gradient(to top, rgba(122,90,248,0.2), rgba(122,90,248,0.8))` }} />
                        <span className="text-[8px] text-white/20">{day}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

        </motion.div>
      </AnimatePresence>
    </div>
  );
}
