import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Home, Search, Compass, Library, Mic, Info, Shield, X, Music, Youtube, Brain, Settings, Heart, MoreHorizontal } from 'lucide-react';
import { useStore } from '../store/useStore';
import { useSettings } from '../store/useSettings';
import { t } from '../i18n/translations';

export function MobileNav() {
  const { currentPage, setPage } = useStore();
  const [showMore, setShowMore] = useState(false);
  const lang = useSettings(s => s.language);

  const TABS = [
    { id: 'home' as const, icon: Home, label: t('home', lang) },
    { id: 'explore' as const, icon: Compass, label: t('explore', lang) },
    { id: 'recognize' as const, icon: Mic, label: '' },
    { id: 'search' as const, icon: Search, label: t('search', lang) },
    { id: 'library' as const, icon: Library, label: t('library', lang) },
  ];

  const MORE_ITEMS = [
    { id: 'youtube' as const, icon: Youtube, label: t('youtubeMusic', lang), desc: lang === 'ar' ? 'ابحث وشاهد فيديوهات موسيقية' : 'Search & watch music videos', color: '#ef4444' },
    { id: 'aichat' as const, icon: Brain, label: t('centAI', lang), desc: lang === 'ar' ? 'مساعد الموسيقى الذكي' : 'AI music assistant', color: '#7a5af8' },
    { id: 'about' as const, icon: Info, label: t('about', lang) + ' CENT', desc: lang === 'ar' ? 'تعرف على المنصة والمؤسسين' : 'About the platform & founders', color: '#8b5cf6' },
    { id: 'settings' as const, icon: Settings, label: t('settings', lang), desc: lang === 'ar' ? 'جودة الصوت، المظهر، اللغة' : 'Audio, display, language', color: '#10b981' },
    { id: 'admin' as const, icon: Shield, label: t('admin', lang), desc: lang === 'ar' ? 'إدارة المحتوى والمستخدمين' : 'Content & user management', color: '#3b82f6' },
  ];

  const isMoreActive = ['about', 'admin', 'youtube', 'aichat', 'settings'].includes(currentPage);

  return (
    <>
      {/* More Menu Overlay */}
      <AnimatePresence>
        {showMore && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="lg:hidden fixed inset-0 bg-black/60 backdrop-blur-md z-50"
              onClick={() => setShowMore(false)}
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              className="lg:hidden fixed bottom-0 left-0 right-0 z-50 p-3 safe-area-bottom"
            >
              <div className="glass-strong rounded-3xl overflow-hidden shadow-2xl border border-white/5">
                {/* Header */}
                <div className="flex items-center justify-between p-5 border-b border-white/5">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cent-400 to-cent-600 flex items-center justify-center shadow-lg">
                      <Music className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <span className="font-display text-lg font-bold text-gradient">CENT</span>
                      <p className="text-[9px] text-white/15 -mt-0.5">{t('moreOptions', lang)}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setShowMore(false)}
                    className="p-2.5 rounded-xl hover:bg-white/5 transition"
                  >
                    <X className="w-5 h-5 text-white/40" />
                  </button>
                </div>

                {/* Menu Items */}
                <div className="p-2.5 space-y-0.5">
                  {MORE_ITEMS.map((item, i) => (
                    <motion.button
                      key={item.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.05 }}
                      whileTap={{ scale: 0.97 }}
                      onClick={() => {
                        setPage(item.id);
                        setShowMore(false);
                      }}
                      className={`w-full flex items-center gap-4 px-4 py-3.5 rounded-2xl transition-all ${
                        currentPage === item.id
                          ? 'bg-white/[0.06]'
                          : 'hover:bg-white/[0.03] active:bg-white/[0.06]'
                      }`}
                    >
                      <div
                        className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0"
                        style={{ background: item.color + '12' }}
                      >
                        <item.icon className="w-5 h-5" style={{ color: item.color }} />
                      </div>
                      <div className="text-left flex-1 min-w-0">
                        <p className="text-sm font-semibold text-white">{item.label}</p>
                        <p className="text-[10px] text-white/25">{item.desc}</p>
                      </div>
                      {currentPage === item.id && (
                        <motion.div
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                          style={{ background: item.color }}
                        />
                      )}
                    </motion.button>
                  ))}
                </div>

                {/* Footer */}
                <div className="px-5 py-3 border-t border-white/5 flex items-center justify-center gap-1.5">
                  <Heart className="w-2.5 h-2.5 text-cent-400/40 fill-cent-400/40" />
                  <span className="text-[9px] text-white/[0.08]">CENT v11.0.0</span>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Main Nav Bar */}
      <motion.nav
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        transition={{ type: 'spring', stiffness: 300, damping: 30 }}
        className="lg:hidden fixed bottom-0 left-0 right-0 z-40"
      >
        <div className="glass-dark safe-area-bottom border-t border-white/[0.03]">
          <div className="flex items-center justify-around px-1 py-1">
            {TABS.map((tab) => {
              const isActive = currentPage === tab.id;
              const isCenter = tab.id === 'recognize';

              if (isCenter) {
                return (
                  <button
                    key={tab.id}
                    onClick={() => setPage(tab.id)}
                    className="relative -mt-6"
                  >
                    <motion.div
                      whileTap={{ scale: 0.9 }}
                      className="rounded-full flex items-center justify-center shadow-xl shadow-cent-500/30 relative overflow-hidden"
                      style={{
                        background: 'linear-gradient(135deg, #7a5af8, #5b21b6)',
                        width: 56,
                        height: 56,
                      }}
                    >
                      <div className="absolute inset-0 bg-gradient-to-br from-white/20 via-transparent to-transparent" />
                      <Mic className="w-6 h-6 text-white relative z-10" />
                    </motion.div>
                    <motion.div
                      className="absolute -inset-2 rounded-full bg-cent-500/15 blur-xl -z-10"
                      animate={{
                        scale: [1, 1.3, 1],
                        opacity: [0.2, 0.4, 0.2],
                      }}
                      transition={{ duration: 3, repeat: Infinity }}
                    />
                  </button>
                );
              }

              return (
                <button
                  key={tab.id}
                  onClick={() => setPage(tab.id)}
                  className={`flex flex-col items-center gap-0.5 py-2 px-3 rounded-2xl transition-all ${
                    isActive ? 'text-white' : 'text-white/25'
                  }`}
                >
                  <div className="relative">
                    <tab.icon
                      className={`w-[22px] h-[22px] ${
                        isActive ? 'text-cent-400' : ''
                      }`}
                    />
                    {isActive && (
                      <motion.div
                        layoutId="mobileActive"
                        className="absolute -inset-2 rounded-xl bg-cent-400/8 -z-10"
                        transition={{
                          type: 'spring',
                          stiffness: 300,
                          damping: 30,
                        }}
                      />
                    )}
                  </div>
                  <span className="text-[10px] font-medium">{tab.label}</span>
                </button>
              );
            })}

            {/* More button */}
            <button
              onClick={() => setShowMore(true)}
              className={`flex flex-col items-center gap-0.5 py-2 px-3 rounded-2xl transition-all ${
                isMoreActive ? 'text-cent-400' : 'text-white/25'
              }`}
            >
              <div className="relative">
                <MoreHorizontal className="w-[22px] h-[22px]" />
                {isMoreActive && (
                  <motion.div
                    layoutId="mobileActiveMore"
                    className="absolute -inset-2 rounded-xl bg-cent-400/8 -z-10"
                  />
                )}
                {/* Notification dot for new features */}
                <div className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-cent-400 border border-surface" />
              </div>
              <span className="text-[10px] font-medium">{t('more', lang)}</span>
            </button>
          </div>
        </div>
      </motion.nav>
    </>
  );
}
