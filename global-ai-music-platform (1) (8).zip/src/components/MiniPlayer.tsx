import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Play, Pause, SkipForward, SkipBack, Heart, X, Youtube, ExternalLink, ChevronUp, ChevronDown } from 'lucide-react';
import { useStore } from '../store/useStore';
import { useAudio } from '../App';

export function MiniPlayer() {
  const currentTrack = useStore(s => s.currentTrack);
  const isPlaying = useStore(s => s.isPlaying);
  const showMiniPlayer = useStore(s => s.showMiniPlayer);
  const progress = useStore(s => s.progress);
  const favorites = useStore(s => s.favorites);
  const togglePlay = useStore(s => s.togglePlay);
  const toggleFavorite = useStore(s => s.toggleFavorite);
  const setShowMiniPlayer = useStore(s => s.setShowMiniPlayer);
  const setIsPlaying = useStore(s => s.setIsPlaying);
  const setPage = useStore(s => s.setPage);
  const { playNext, playPrev } = useAudio();
  const [showYTPlayer, setShowYTPlayer] = useState(false);

  // Determine if YouTube track
  const isYT = currentTrack?.id?.startsWith('yt_') || false;
  const ytVideoId = isYT && currentTrack ? currentTrack.id.replace('yt_', '') : null;
  const isFav = currentTrack ? favorites.includes(currentTrack.id) : false;

  // Close YT player when track changes
  useEffect(() => {
    setShowYTPlayer(false);
  }, [currentTrack?.id]);

  // Don't render if no track
  if (!currentTrack || !showMiniPlayer) return null;

  return (
    <>
      {/* YouTube Floating Video Player */}
      <AnimatePresence>
        {showYTPlayer && ytVideoId && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.9 }}
            transition={{ type: 'spring', stiffness: 300, damping: 25 }}
            className="fixed bottom-[140px] lg:bottom-[100px] left-2 right-2 lg:left-[268px] lg:right-3 z-50"
          >
            <div className="glass-strong rounded-2xl overflow-hidden shadow-2xl border border-white/10">
              <div className="flex items-center justify-between px-3 py-2 border-b border-white/5">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                  <span className="text-xs text-white/50 font-medium">YouTube Player</span>
                </div>
                <div className="flex items-center gap-1">
                  <a href={`https://www.youtube.com/watch?v=${ytVideoId}`} target="_blank" rel="noopener noreferrer"
                    className="flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] text-red-400 hover:bg-red-500/10 transition">
                    <ExternalLink className="w-3 h-3" /> Open
                  </a>
                  <button onClick={() => setShowYTPlayer(false)} className="p-1 rounded-lg hover:bg-white/10 transition">
                    <X className="w-4 h-4 text-white/40" />
                  </button>
                </div>
              </div>
              <div className="aspect-video bg-black">
                <iframe
                  src={`https://www.youtube.com/embed/${ytVideoId}?autoplay=1&rel=0&playsinline=1`}
                  title="YouTube"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  className="w-full h-full"
                />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Mini Player Bar */}
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ type: 'spring', stiffness: 300, damping: 30 }}
        className="fixed bottom-[68px] lg:bottom-0 left-0 lg:left-[260px] right-0 z-40"
      >
        <div className="mx-2 mb-2 lg:mx-3 lg:mb-3">
          <div
            className="glass-strong rounded-2xl overflow-hidden cursor-pointer group hover-glow transition-all relative"
            onClick={() => {
              if (isYT) {
                setShowYTPlayer(!showYTPlayer);
              } else {
                setPage('player');
              }
            }}
          >
            {/* Track color accent */}
            <div
              className="absolute inset-0 opacity-[0.06] transition-opacity group-hover:opacity-[0.12]"
              style={{ background: `radial-gradient(ellipse at 0% 50%, ${currentTrack.color}, transparent 70%)` }}
            />

            {/* Progress bar */}
            <div className="h-[3px] bg-white/[0.04] relative">
              <motion.div
                className="h-full relative"
                style={{
                  width: `${isYT ? 0 : progress}%`,
                  background: `linear-gradient(90deg, ${currentTrack.color}, ${currentTrack.color}cc)`,
                  boxShadow: `0 0 8px ${currentTrack.color}30`,
                }}
              >
                <div className="absolute right-0 top-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-white shadow-lg opacity-0 group-hover:opacity-100 transition-opacity" style={{ transform: 'translate(50%, -50%)' }} />
              </motion.div>
            </div>

            <div className="flex items-center gap-3 p-2.5 sm:p-3 relative">
              {/* Album art */}
              <div className="relative w-12 h-12 sm:w-13 sm:h-13 rounded-xl overflow-hidden flex-shrink-0 shadow-lg">
                <img src={currentTrack.cover} alt={currentTrack.title} className="w-full h-full object-cover" />
                {/* YouTube badge */}
                {isYT && (
                  <div className="absolute bottom-0.5 right-0.5 w-5 h-5 rounded-md bg-red-500 flex items-center justify-center shadow-sm">
                    <Youtube className="w-3 h-3 text-white" />
                  </div>
                )}
                {/* Playing animation */}
                {isPlaying && !isYT && (
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                    <div className="flex items-end gap-[2px] h-4">
                      {[0, 1, 2, 3].map(i => (
                        <motion.div
                          key={i}
                          className="w-[3px] rounded-full"
                          style={{ background: currentTrack.color }}
                          animate={{ height: ['30%', '100%', '30%'] }}
                          transition={{ duration: 0.7, repeat: Infinity, delay: i * 0.15, ease: 'easeInOut' }}
                        />
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Track info */}
              <div className="flex-1 min-w-0">
                <motion.p
                  key={currentTrack.title}
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-sm font-semibold text-white truncate"
                >
                  {currentTrack.title}
                </motion.p>
                <p className="text-[11px] text-white/30 truncate flex items-center gap-1">
                  {isYT && <Youtube className="w-3 h-3 text-red-400 flex-shrink-0" />}
                  {currentTrack.artist}
                </p>
              </div>

              {/* Controls */}
              <div className="flex items-center gap-0.5 sm:gap-1" onClick={(e) => e.stopPropagation()}>
                {/* Like */}
                <motion.button
                  whileTap={{ scale: 0.85 }}
                  onClick={() => toggleFavorite(currentTrack.id, currentTrack)}
                  className="p-2 rounded-full hover:bg-white/5 transition"
                >
                  <Heart className={`w-4 h-4 transition-colors ${isFav ? 'fill-cent-400 text-cent-400' : 'text-white/25'}`} />
                </motion.button>

                {/* YouTube toggle */}
                {isYT && (
                  <button
                    onClick={() => setShowYTPlayer(!showYTPlayer)}
                    className="p-2 rounded-full hover:bg-white/5 transition"
                  >
                    {showYTPlayer ? <ChevronDown className="w-4 h-4 text-red-400" /> : <ChevronUp className="w-4 h-4 text-red-400" />}
                  </button>
                )}

                {/* Prev - desktop only, non-YT */}
                {!isYT && (
                  <button onClick={playPrev} className="p-2 rounded-full hover:bg-white/5 transition hidden sm:block">
                    <SkipBack className="w-4 h-4 text-white/35" />
                  </button>
                )}

                {/* Play/Pause */}
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={() => {
                    // For both YT and regular tracks, toggle play state
                    // YT: The PersistentYouTubePlayer in App.tsx will handle iframe reload
                    // Regular: useAudioPlayer handles globalAudio play/pause
                    if (isYT) {
                      setIsPlaying(!isPlaying);
                    } else {
                      togglePlay();
                    }
                  }}
                  className="w-10 h-10 rounded-full flex items-center justify-center shadow-lg"
                  style={{
                    background: `linear-gradient(135deg, ${currentTrack.color}, ${currentTrack.color}bb)`,
                    boxShadow: `0 4px 15px ${currentTrack.color}30`,
                  }}
                >
                  {isPlaying ? <Pause className="w-4 h-4 text-white" /> : <Play className="w-4 h-4 text-white ml-0.5" />}
                </motion.button>

                {/* Next */}
                {!isYT && (
                  <button onClick={playNext} className="p-2 rounded-full hover:bg-white/5 transition">
                    <SkipForward className="w-4 h-4 text-white/35" />
                  </button>
                )}

                {/* Open in YouTube */}
                {isYT && ytVideoId && (
                  <a
                    href={`https://www.youtube.com/watch?v=${ytVideoId}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 rounded-full hover:bg-white/5 transition"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <ExternalLink className="w-4 h-4 text-white/25" />
                  </a>
                )}

                {/* Close - mobile only */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowMiniPlayer(false);
                    setShowYTPlayer(false);
                    if (isYT) setIsPlaying(false);
                  }}
                  className="p-2 rounded-full hover:bg-white/5 transition lg:hidden"
                >
                  <X className="w-4 h-4 text-white/15" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </>
  );
}
