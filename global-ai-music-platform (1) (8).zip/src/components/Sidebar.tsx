import { motion } from 'framer-motion';
import { Home, Search, Library, Mic, Info, Shield, Compass, Music, Zap, Headphones, Heart, Youtube, Brain, Settings } from 'lucide-react';
import { useStore } from '../store/useStore';
import { useSettings } from '../store/useSettings';
import { t } from '../i18n/translations';

function useNavItems() {
  const lang = useSettings(s => s.language);
  return [
    { id: 'home' as const, icon: Home, label: t('home', lang) },
    { id: 'explore' as const, icon: Compass, label: t('explore', lang) },
    { id: 'search' as const, icon: Search, label: t('search', lang) },
    { id: 'library' as const, icon: Library, label: t('library', lang) },
    { id: 'youtube' as const, icon: Youtube, label: t('youtubeMusic', lang) },
    { id: 'aichat' as const, icon: Brain, label: t('centAI', lang) },
    { id: 'recognize' as const, icon: Mic, label: t('recognize', lang), badge: true },
    { id: 'settings' as const, icon: Settings, label: t('settings', lang) },
    { id: 'admin' as const, icon: Shield, label: t('admin', lang) },
    { id: 'about' as const, icon: Info, label: t('about', lang) },
  ];
}

export function Sidebar() {
  const { currentPage, setPage } = useStore();
  const NAV_ITEMS = useNavItems();

  return (
    <motion.aside
      initial={{ x: -100, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      transition={{ duration: 0.5, ease: 'easeOut' }}
      className="hidden lg:flex fixed left-0 top-0 bottom-0 w-[260px] flex-col z-40 p-3"
    >
      <div className="flex-1 flex flex-col glass rounded-2xl overflow-hidden">
        {/* Logo */}
        <div className="p-6 pb-5 flex items-center gap-3">
          <div className="relative">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-cent-400 to-cent-600 flex items-center justify-center shadow-lg shadow-cent-500/25 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-white/15 via-transparent to-transparent" />
              <Music className="w-5 h-5 text-white relative z-10" />
            </div>
            <motion.div
              className="absolute -inset-1.5 rounded-xl bg-cent-400/15 blur-xl -z-10"
              animate={{ opacity: [0.2, 0.5, 0.2] }}
              transition={{ duration: 3, repeat: Infinity }}
            />
          </div>
          <div>
            <span className="font-display text-2xl font-black text-gradient tracking-tight">CENT</span>
            <p className="text-[9px] text-white/15 tracking-[0.2em] uppercase -mt-1">AI Music Platform</p>
          </div>
        </div>

        <div className="mx-5 h-px bg-gradient-to-r from-transparent via-white/8 to-transparent" />

        {/* Navigation */}
        <nav className="flex-1 px-3 py-4 space-y-0.5">
          {NAV_ITEMS.map((item) => {
            const isActive = currentPage === item.id;
            return (
              <motion.button
                key={item.id}
                whileHover={{ x: 3 }}
                whileTap={{ scale: 0.97 }}
                onClick={() => setPage(item.id)}
                className={`relative w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-300 ${
                  isActive ? 'text-white' : 'text-white/30 hover:text-white/60'
                }`}
              >
                {isActive && (
                  <motion.div
                    layoutId="sidebarActive"
                    className="absolute inset-0 rounded-xl bg-gradient-to-r from-cent-500/12 to-cent-600/5 border border-cent-500/15"
                    transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                  />
                )}
                {isActive && (
                  <motion.div
                    layoutId="sidebarIndicator"
                    className="absolute left-0 w-[3px] h-5 bg-gradient-to-b from-cent-400 to-cent-500 rounded-r-full shadow-lg shadow-cent-400/50"
                    transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                  />
                )}
                <item.icon className={`w-[18px] h-[18px] relative z-10 transition-colors ${isActive ? 'text-cent-400' : ''}`} />
                <span className="relative z-10">{item.label}</span>
                {item.badge && (
                  <span className="ml-auto relative z-10">
                    <span className="flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cent-400 opacity-75" />
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-cent-400" />
                    </span>
                  </span>
                )}
              </motion.button>
            );
          })}
        </nav>

        <div className="mx-5 h-px bg-gradient-to-r from-transparent via-white/8 to-transparent" />

        {/* Trending Stats */}
        <div className="px-5 py-4">
          <div className="flex items-center gap-2 mb-3">
            <Headphones className="w-3.5 h-3.5 text-white/15" />
            <span className="text-[10px] text-white/15 uppercase tracking-wider">Now Trending</span>
          </div>
          <div className="space-y-2">
            {['Electronic', 'Ambient', 'Lo-fi'].map((genre, i) => (
              <div key={genre} className="flex items-center gap-2">
                <div className="flex-1 h-1 bg-white/5 rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-cent-400 to-cent-500 rounded-full"
                    initial={{ width: 0 }}
                    animate={{ width: `${80 - i * 20}%` }}
                    transition={{ delay: 0.5 + i * 0.2, duration: 1 }}
                  />
                </div>
                <span className="text-[9px] text-white/15 w-14 text-right">{genre}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="mx-5 h-px bg-gradient-to-r from-transparent via-white/8 to-transparent" />

        {/* Premium Card */}
        <div className="p-4">
          <motion.div
            whileHover={{ scale: 1.02 }}
            className="relative p-5 rounded-2xl overflow-hidden cursor-pointer group"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-cent-500/15 via-accent-pink/8 to-cent-700/15 animate-gradient" />
            <div className="absolute inset-0 border border-cent-400/15 rounded-2xl group-hover:border-cent-400/25 transition-colors" />
            
            <div className="relative">
              <div className="flex items-center gap-2 mb-2">
                <Zap className="w-4 h-4 text-cent-400" />
                <p className="text-sm font-bold text-white">Go Premium</p>
              </div>
              <p className="text-[11px] text-white/30 mb-4 leading-relaxed">
                Unlimited skips, offline mode, spatial audio & more
              </p>
              <button className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cent-400 to-cent-600 text-white text-xs font-bold hover:opacity-90 transition-all shadow-lg shadow-cent-500/15">
                Upgrade Now
              </button>
            </div>
          </motion.div>
        </div>

        {/* Footer branding */}
        <div className="px-5 pb-4 flex items-center justify-center gap-1">
          <Heart className="w-2.5 h-2.5 text-cent-400/30 fill-cent-400/30" />
          <span className="text-[9px] text-white/[0.06]">CENT v11.0.0</span>
        </div>
      </div>
    </motion.aside>
  );
}
