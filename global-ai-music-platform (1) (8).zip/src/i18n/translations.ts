export type Language = 'en' | 'ar' | 'fr' | 'es' | 'de' | 'ja' | 'ko';

export const LANGUAGE_NAMES: Record<Language, string> = {
  en: 'English',
  ar: 'العربية',
  fr: 'Français',
  es: 'Español',
  de: 'Deutsch',
  ja: '日本語',
  ko: '한국어',
};

export const RTL_LANGUAGES: Language[] = ['ar'];

type TranslationKeys = {
  // Navigation
  home: string;
  explore: string;
  search: string;
  library: string;
  recognize: string;
  settings: string;
  about: string;
  admin: string;
  more: string;
  moreOptions: string;
  player: string;

  // Home
  goodMorning: string;
  goodAfternoon: string;
  goodEvening: string;
  trendingToday: string;
  listeningNow: string;
  featured: string;
  playNow: string;
  quickPicks: string;
  moodPlaylists: string;
  madeForYou: string;
  seeAll: string;
  trendingNow: string;
  popularArtists: string;
  newRelease: string;
  topCharts: string;
  recentlyPlayed: string;
  getPremium: string;
  learnMore: string;

  // Search
  searchPlaceholder: string;
  searchCentYoutube: string;
  trending: string;
  recentSearches: string;
  browseAll: string;
  noResults: string;
  tryDifferent: string;
  searchInYoutube: string;
  results: string;
  tracks: string;
  artists: string;
  genres: string;

  // Library
  yourLibrary: string;
  playlists: string;
  favorites: string;
  history: string;
  downloads: string;
  noFavorites: string;
  noDownloads: string;
  createPlaylist: string;
  likedSongs: string;
  yourStats: string;
  totalPlays: string;
  listeningTime: string;
  topGenres: string;

  // Player
  playingFrom: string;
  lyrics: string;
  equalizer: string;
  queue: string;
  poweredByCent: string;

  // Recognize
  songRecognition: string;
  tapToIdentify: string;
  listening: string;
  processing: string;
  songFound: string;
  noMatch: string;
  tryAgain: string;
  recognizeAnother: string;
  mlPipeline: string;

  // Settings
  settingsTitle: string;
  customizeExperience: string;
  audio: string;
  streamingQuality: string;
  downloadQuality: string;
  equalizerPreset: string;
  volume: string;
  spatialAudio: string;
  autoPlay: string;
  crossfade: string;
  volumeNormalization: string;
  display: string;
  theme: string;
  darkMode: string;
  lightMode: string;
  switchTheme: string;
  showLyrics: string;
  language: string;
  dataStorage: string;
  wifiOnly: string;
  offlineMode: string;
  storageLimit: string;
  storageUsed: string;
  notifications: string;
  pushNotifications: string;
  security: string;
  privacy: string;
  connectedDevices: string;

  // YouTube
  youtubeMusic: string;
  searchAndPlay: string;
  browseByGenre: string;
  trendingMusic: string;
  nowPlaying: string;
  openInYoutube: string;

  // AI
  centAI: string;
  askAboutMusic: string;
  musicIntelligence: string;
  aiThinking: string;
  clearChat: string;
  tryAsking: string;
  recommendations: string;
  playlistCreation: string;
  lyricsAnalysis: string;
  musicTheory: string;

  // About
  aboutCent: string;
  globalAiMusic: string;
  meetFounders: string;
  platformFeatures: string;
  systemArchitecture: string;
  techStack: string;
  databaseSchema: string;
  whyCent: string;
  forListeners: string;
  forArtists: string;
  forFuture: string;
  followInstagram: string;
  futureIsHere: string;
  allRightsReserved: string;
  madeWithLove: string;

  // Admin
  adminDashboard: string;
  overview: string;
  music: string;
  users: string;
  analytics: string;
  moderation: string;

  // Common
  play: string;
  pause: string;
  next: string;
  previous: string;
  shuffle: string;
  repeat: string;
  share: string;
  download: string;
  follow: string;
  save: string;
  cancel: string;
  confirm: string;
  loading: string;
  error: string;
  retry: string;
  back: string;
  songs: string;
  followers: string;
};

const en: TranslationKeys = {
  home: 'Home',
  explore: 'Explore',
  search: 'Search',
  library: 'Library',
  recognize: 'Recognize',
  settings: 'Settings',
  about: 'About',
  admin: 'Admin',
  more: 'More',
  moreOptions: 'More options',
  player: 'Player',
  goodMorning: 'Good Morning',
  goodAfternoon: 'Good Afternoon',
  goodEvening: 'Good Evening',
  trendingToday: "Here's what's trending on CENT today",
  listeningNow: 'listening now',
  featured: 'Featured',
  playNow: 'Play Now',
  quickPicks: 'Quick Picks',
  moodPlaylists: 'Mood Playlists',
  madeForYou: 'Made For You',
  seeAll: 'See All',
  trendingNow: 'Trending Now',
  popularArtists: 'Popular Artists',
  newRelease: 'New Release',
  topCharts: 'Top Charts',
  recentlyPlayed: 'Recently Played',
  getPremium: 'Get Premium',
  learnMore: 'Learn More',
  searchPlaceholder: 'Search songs, artists, or YouTube videos...',
  searchCentYoutube: 'CENT + YouTube',
  trending: 'Trending',
  recentSearches: 'Recent Searches',
  browseAll: 'Browse All',
  noResults: 'No results found',
  tryDifferent: 'Try different search terms',
  searchInYoutube: 'Search in YouTube',
  results: 'results',
  tracks: 'Tracks',
  artists: 'Artists',
  genres: 'Genres',
  yourLibrary: 'Your Library',
  playlists: 'Playlists',
  favorites: 'Favorites',
  history: 'History',
  downloads: 'Downloads',
  noFavorites: 'No favorites yet',
  noDownloads: 'No downloads yet',
  createPlaylist: 'Create New Playlist',
  likedSongs: 'Liked Songs',
  yourStats: 'Your Stats',
  totalPlays: 'Total Plays',
  listeningTime: 'Listening Time',
  topGenres: 'Top Genres',
  playingFrom: 'Playing From',
  lyrics: 'Lyrics',
  equalizer: 'EQ',
  queue: 'Queue',
  poweredByCent: 'Powered by CENT',
  songRecognition: 'Song Recognition',
  tapToIdentify: 'Tap to Identify',
  listening: 'Listening...',
  processing: 'Processing Audio',
  songFound: 'Song Found!',
  noMatch: 'No Match Found',
  tryAgain: 'Try Again',
  recognizeAnother: 'Recognize Another Song',
  mlPipeline: 'ML Pipeline',
  settingsTitle: 'Settings',
  customizeExperience: 'Customize your CENT experience',
  audio: 'Audio',
  streamingQuality: 'Streaming Quality',
  downloadQuality: 'Download Quality',
  equalizerPreset: 'Equalizer Preset',
  volume: 'Volume',
  spatialAudio: 'Spatial Audio',
  autoPlay: 'Auto-Play',
  crossfade: 'Crossfade',
  volumeNormalization: 'Volume Normalization',
  display: 'Display',
  theme: 'Theme',
  darkMode: 'Dark Mode',
  lightMode: 'Light Mode',
  switchTheme: 'Switch',
  showLyrics: 'Show Lyrics',
  language: 'Language',
  dataStorage: 'Data & Storage',
  wifiOnly: 'Wi-Fi Only',
  offlineMode: 'Offline Mode',
  storageLimit: 'Storage Limit',
  storageUsed: 'Storage Used',
  notifications: 'Notifications',
  pushNotifications: 'Push Notifications',
  security: 'Security',
  privacy: 'Privacy',
  connectedDevices: 'Connected Devices',
  youtubeMusic: 'YouTube Music',
  searchAndPlay: 'Search & play music videos',
  browseByGenre: 'Browse by genre',
  trendingMusic: 'Trending Music',
  nowPlaying: 'Now Playing',
  openInYoutube: 'Open in YouTube',
  centAI: 'CENT AI',
  askAboutMusic: 'Ask CENT AI about music...',
  musicIntelligence: 'Music Intelligence',
  aiThinking: 'CENT AI is thinking...',
  clearChat: 'Clear',
  tryAsking: 'Try asking',
  recommendations: 'Recommendations',
  playlistCreation: 'Playlist Creation',
  lyricsAnalysis: 'Lyrics Analysis',
  musicTheory: 'Music Theory',
  aboutCent: 'About CENT',
  globalAiMusic: 'Global AI Music Platform',
  meetFounders: 'Meet the Founders',
  platformFeatures: 'Platform Features',
  systemArchitecture: 'System Architecture',
  techStack: 'Tech Stack',
  databaseSchema: 'Database Schema',
  whyCent: 'Why CENT?',
  forListeners: 'For Listeners',
  forArtists: 'For Artists',
  forFuture: 'For the Future',
  followInstagram: 'Follow us on Instagram for updates',
  futureIsHere: 'The future of music is here.',
  allRightsReserved: '© 2025 CENT Music. All rights reserved.',
  madeWithLove: 'Made with ❤️ for the world',
  adminDashboard: 'Admin Dashboard',
  overview: 'Overview',
  music: 'Music',
  users: 'Users',
  analytics: 'Analytics',
  moderation: 'Moderation',
  play: 'Play',
  pause: 'Pause',
  next: 'Next',
  previous: 'Previous',
  shuffle: 'Shuffle',
  repeat: 'Repeat',
  share: 'Share',
  download: 'Download',
  follow: 'Follow',
  save: 'Save',
  cancel: 'Cancel',
  confirm: 'Confirm',
  loading: 'Loading...',
  error: 'Error',
  retry: 'Retry',
  back: 'Back',
  songs: 'songs',
  followers: 'followers',
};

const ar: TranslationKeys = {
  home: 'الرئيسية',
  explore: 'استكشاف',
  search: 'بحث',
  library: 'المكتبة',
  recognize: 'التعرف',
  settings: 'الإعدادات',
  about: 'حول',
  admin: 'لوحة التحكم',
  more: 'المزيد',
  moreOptions: 'خيارات إضافية',
  player: 'المشغل',
  goodMorning: 'صباح الخير',
  goodAfternoon: 'مساء الخير',
  goodEvening: 'مساء الخير',
  trendingToday: 'إليك ما هو رائج على CENT اليوم',
  listeningNow: 'يستمعون الآن',
  featured: 'مميز',
  playNow: 'تشغيل الآن',
  quickPicks: 'اختيارات سريعة',
  moodPlaylists: 'قوائم حسب المزاج',
  madeForYou: 'مصمم لك',
  seeAll: 'عرض الكل',
  trendingNow: 'رائج الآن',
  popularArtists: 'فنانون مشهورون',
  newRelease: 'إصدار جديد',
  topCharts: 'الأكثر استماعاً',
  recentlyPlayed: 'سمعت مؤخراً',
  getPremium: 'اشترك بريميوم',
  learnMore: 'اعرف المزيد',
  searchPlaceholder: 'ابحث عن أغاني، فنانين، أو فيديوهات YouTube...',
  searchCentYoutube: 'CENT + YouTube',
  trending: 'رائج',
  recentSearches: 'عمليات بحث سابقة',
  browseAll: 'تصفح الكل',
  noResults: 'لا توجد نتائج',
  tryDifferent: 'جرب كلمات بحث مختلفة',
  searchInYoutube: 'بحث في YouTube',
  results: 'نتيجة',
  tracks: 'أغاني',
  artists: 'فنانون',
  genres: 'أنواع',
  yourLibrary: 'مكتبتك',
  playlists: 'قوائم التشغيل',
  favorites: 'المفضلة',
  history: 'السجل',
  downloads: 'التنزيلات',
  noFavorites: 'لا توجد مفضلات بعد',
  noDownloads: 'لا توجد تنزيلات بعد',
  createPlaylist: 'إنشاء قائمة جديدة',
  likedSongs: 'الأغاني المحبوبة',
  yourStats: 'إحصائياتك',
  totalPlays: 'إجمالي التشغيل',
  listeningTime: 'وقت الاستماع',
  topGenres: 'أكثر الأنواع',
  playingFrom: 'يتم التشغيل من',
  lyrics: 'كلمات',
  equalizer: 'المعادل',
  queue: 'قائمة الانتظار',
  poweredByCent: 'مدعوم من CENT',
  songRecognition: 'التعرف على الأغاني',
  tapToIdentify: 'اضغط للتعرف',
  listening: 'جاري الاستماع...',
  processing: 'جاري المعالجة',
  songFound: 'تم العثور على الأغنية!',
  noMatch: 'لم يتم العثور على تطابق',
  tryAgain: 'حاول مجدداً',
  recognizeAnother: 'تعرف على أغنية أخرى',
  mlPipeline: 'خط أنابيب ML',
  settingsTitle: 'الإعدادات',
  customizeExperience: 'خصص تجربتك في CENT',
  audio: 'الصوت',
  streamingQuality: 'جودة البث',
  downloadQuality: 'جودة التنزيل',
  equalizerPreset: 'إعداد المعادل',
  volume: 'مستوى الصوت',
  spatialAudio: 'صوت مكاني',
  autoPlay: 'تشغيل تلقائي',
  crossfade: 'انتقال سلس',
  volumeNormalization: 'توازن الصوت',
  display: 'العرض',
  theme: 'المظهر',
  darkMode: 'الوضع الداكن',
  lightMode: 'الوضع الفاتح',
  switchTheme: 'تبديل',
  showLyrics: 'عرض الكلمات',
  language: 'اللغة',
  dataStorage: 'البيانات والتخزين',
  wifiOnly: 'عبر Wi-Fi فقط',
  offlineMode: 'وضع بدون إنترنت',
  storageLimit: 'حد التخزين',
  storageUsed: 'المساحة المستخدمة',
  notifications: 'الإشعارات',
  pushNotifications: 'إشعارات فورية',
  security: 'الأمان',
  privacy: 'الخصوصية',
  connectedDevices: 'الأجهزة المتصلة',
  youtubeMusic: 'يوتيوب ميوزك',
  searchAndPlay: 'ابحث وشغل فيديوهات موسيقية',
  browseByGenre: 'تصفح حسب النوع',
  trendingMusic: 'الموسيقى الرائجة',
  nowPlaying: 'قيد التشغيل',
  openInYoutube: 'فتح في YouTube',
  centAI: 'ذكاء CENT',
  askAboutMusic: 'اسأل CENT AI عن الموسيقى...',
  musicIntelligence: 'ذكاء موسيقي',
  aiThinking: 'CENT AI يفكر...',
  clearChat: 'مسح',
  tryAsking: 'جرب أن تسأل',
  recommendations: 'توصيات',
  playlistCreation: 'إنشاء قوائم',
  lyricsAnalysis: 'تحليل كلمات',
  musicTheory: 'نظرية موسيقية',
  aboutCent: 'حول CENT',
  globalAiMusic: 'منصة موسيقى عالمية بالذكاء الاصطناعي',
  meetFounders: 'تعرف على المؤسسين',
  platformFeatures: 'ميزات المنصة',
  systemArchitecture: 'بنية النظام',
  techStack: 'التقنيات المستخدمة',
  databaseSchema: 'مخطط قاعدة البيانات',
  whyCent: 'لماذا CENT؟',
  forListeners: 'للمستمعين',
  forArtists: 'للفنانين',
  forFuture: 'للمستقبل',
  followInstagram: 'تابعنا على إنستغرام للتحديثات',
  futureIsHere: 'مستقبل الموسيقى هنا.',
  allRightsReserved: '© 2025 CENT Music. جميع الحقوق محفوظة.',
  madeWithLove: 'صُنع بحب ❤️ للعالم',
  adminDashboard: 'لوحة التحكم',
  overview: 'نظرة عامة',
  music: 'الموسيقى',
  users: 'المستخدمون',
  analytics: 'التحليلات',
  moderation: 'الإشراف',
  play: 'تشغيل',
  pause: 'إيقاف',
  next: 'التالي',
  previous: 'السابق',
  shuffle: 'عشوائي',
  repeat: 'تكرار',
  share: 'مشاركة',
  download: 'تنزيل',
  follow: 'متابعة',
  save: 'حفظ',
  cancel: 'إلغاء',
  confirm: 'تأكيد',
  loading: 'جاري التحميل...',
  error: 'خطأ',
  retry: 'إعادة المحاولة',
  back: 'رجوع',
  songs: 'أغاني',
  followers: 'متابع',
};

const fr: TranslationKeys = {
  ...en,
  home: 'Accueil',
  explore: 'Explorer',
  search: 'Recherche',
  library: 'Bibliothèque',
  recognize: 'Reconnaître',
  settings: 'Paramètres',
  about: 'À propos',
  admin: 'Admin',
  more: 'Plus',
  goodMorning: 'Bonjour',
  goodAfternoon: 'Bon après-midi',
  goodEvening: 'Bonsoir',
  playNow: 'Écouter',
  quickPicks: 'Sélection rapide',
  trendingNow: 'Tendances',
  popularArtists: 'Artistes populaires',
  topCharts: 'Top classement',
  recentlyPlayed: 'Écouté récemment',
  getPremium: 'Passer Premium',
  searchPlaceholder: 'Rechercher chansons, artistes, vidéos YouTube...',
  favorites: 'Favoris',
  history: 'Historique',
  downloads: 'Téléchargements',
  settingsTitle: 'Paramètres',
  language: 'Langue',
  theme: 'Thème',
  volume: 'Volume',
  notifications: 'Notifications',
  security: 'Sécurité',
  play: 'Lire',
  pause: 'Pause',
  next: 'Suivant',
  previous: 'Précédent',
  share: 'Partager',
  loading: 'Chargement...',
  retry: 'Réessayer',
  back: 'Retour',
  songs: 'chansons',
  followers: 'abonnés',
};

const es: TranslationKeys = {
  ...en,
  home: 'Inicio',
  explore: 'Explorar',
  search: 'Buscar',
  library: 'Biblioteca',
  settings: 'Ajustes',
  about: 'Acerca de',
  more: 'Más',
  goodMorning: 'Buenos días',
  goodAfternoon: 'Buenas tardes',
  goodEvening: 'Buenas noches',
  playNow: 'Reproducir',
  trendingNow: 'Tendencia',
  popularArtists: 'Artistas populares',
  getPremium: 'Hazte Premium',
  favorites: 'Favoritos',
  history: 'Historial',
  downloads: 'Descargas',
  language: 'Idioma',
  theme: 'Tema',
  notifications: 'Notificaciones',
  play: 'Reproducir',
  pause: 'Pausar',
  share: 'Compartir',
  loading: 'Cargando...',
  back: 'Atrás',
  songs: 'canciones',
  followers: 'seguidores',
};

const de: TranslationKeys = { ...en, home: 'Startseite', explore: 'Entdecken', search: 'Suche', library: 'Bibliothek', settings: 'Einstellungen', about: 'Über', goodMorning: 'Guten Morgen', goodAfternoon: 'Guten Tag', goodEvening: 'Guten Abend', playNow: 'Abspielen', favorites: 'Favoriten', language: 'Sprache', notifications: 'Benachrichtigungen', play: 'Abspielen', pause: 'Pause', share: 'Teilen', loading: 'Laden...', back: 'Zurück', songs: 'Lieder', followers: 'Follower' };

const ja: TranslationKeys = { ...en, home: 'ホーム', explore: '探索', search: '検索', library: 'ライブラリ', settings: '設定', about: '概要', goodMorning: 'おはようございます', goodAfternoon: 'こんにちは', goodEvening: 'こんばんは', playNow: '再生', favorites: 'お気に入り', language: '言語', play: '再生', pause: '一時停止', share: '共有', loading: '読み込み中...', back: '戻る', songs: '曲', followers: 'フォロワー' };

const ko: TranslationKeys = { ...en, home: '홈', explore: '탐색', search: '검색', library: '보관함', settings: '설정', about: '소개', goodMorning: '좋은 아침', goodAfternoon: '안녕하세요', goodEvening: '좋은 저녁', playNow: '재생', favorites: '즐겨찾기', language: '언어', play: '재생', pause: '일시정지', share: '공유', loading: '로딩 중...', back: '뒤로', songs: '곡', followers: '팔로워' };

export const translations: Record<Language, TranslationKeys> = { en, ar, fr, es, de, ja, ko };

export function t(key: keyof TranslationKeys, lang: Language = 'en'): string {
  return translations[lang]?.[key] || translations.en[key] || key;
}
