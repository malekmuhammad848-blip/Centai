import { useState, useEffect, useCallback, createContext, useContext } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useStore } from './store/useStore';
import { useAudioPlayer } from './hooks/useAudioPlayer';
import { useSettings } from './store/useSettings';
import { RTL_LANGUAGES } from './i18n/translations';
import { Sidebar } from './components/Sidebar';
import { MobileNav } from './components/MobileNav';
import { MiniPlayer } from './components/MiniPlayer';
import { HomePage } from './pages/HomePage';
import { ExplorePage } from './pages/ExplorePage';
import { SearchPage } from './pages/SearchPage';
import { LibraryPage } from './pages/LibraryPage';
import { PlayerPage } from './pages/PlayerPage';
import { RecognizePage } from './pages/RecognizePage';
import { AboutPage } from './pages/AboutPage';
import { AdminPage } from './pages/AdminPage';
import { PlaylistPage } from './pages/PlaylistPage';
import { ArtistPage } from './pages/ArtistPage';
import { YouTubePage } from './pages/YouTubePage';
import { AIChatPage } from './pages/AIChatPage';
import { SettingsPage } from './pages/SettingsPage';

/* ============ AUDIO CONTEXT ============ */
interface AudioContextType {
  seekTo: (pct: number) => void;
  playNext: () => void;
  playPrev: () => void;
  getCurrentTime: () => number;
  getDuration: () => number;
}

const AudioCtx = createContext<AudioContextType>({
  seekTo: () => {},
  playNext: () => {},
  playPrev: () => {},
  getCurrentTime: () => 0,
  getDuration: () => 0,
});

export const useAudio = () => useContext(AudioCtx);

/* ============ ANIMATED PARTICLES ============ */
function SplashParticles() {
  const particles = Array.from({ length: 30 }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    delay: Math.random() * 3,
    duration: 3 + Math.random() * 5,
    size: 1.5 + Math.random() * 3,
    opacity: 0.1 + Math.random() * 0.3,
  }));

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {particles.map(p => (
        <motion.div
          key={p.id}
          className="absolute rounded-full bg-cent-400"
          style={{ width: p.size, height: p.size, left: `${p.x}%`, opacity: p.opacity }}
          initial={{ y: '110vh', opacity: 0 }}
          animate={{ y: '-10vh', opacity: [0, p.opacity, p.opacity, 0] }}
          transition={{ duration: p.duration, delay: p.delay, repeat: Infinity, ease: 'linear' }}
        />
      ))}
    </div>
  );
}

/* ============ CINEMATIC SPLASH SCREEN ============ */
function SplashScreen({ onComplete }: { onComplete: () => void }) {
  const [progress, setProgress] = useState(0);
  const [phase, setPhase] = useState<'logo' | 'text' | 'loading' | 'exit'>('logo');

  useEffect(() => {
    const t1 = setTimeout(() => setPhase('text'), 600);
    const t2 = setTimeout(() => setPhase('loading'), 1400);
    const t3 = setTimeout(() => setPhase('exit'), 3200);
    const t4 = setTimeout(onComplete, 3700);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); clearTimeout(t4); };
  }, [onComplete]);

  useEffect(() => {
    if (phase === 'loading') {
      const interval = setInterval(() => {
        setProgress(p => Math.min(100, p + 2));
      }, 28);
      return () => clearInterval(interval);
    }
  }, [phase]);

  return (
    <motion.div
      className="fixed inset-0 z-[200] flex items-center justify-center overflow-hidden"
      style={{ background: '#030308' }}
      animate={phase === 'exit' ? { opacity: 0, scale: 1.15 } : {}}
      transition={{ duration: 0.5, ease: 'easeInOut' }}
    >
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          className="absolute w-[500px] h-[500px] md:w-[700px] md:h-[700px] rounded-full animate-morph"
          style={{ background: 'radial-gradient(circle, rgba(122,90,248,0.12) 0%, transparent 70%)', top: '0%', left: '10%' }}
          animate={{ x: [0, 120, -60, 0], y: [0, -100, 60, 0], scale: [1, 1.3, 0.8, 1] }}
          transition={{ duration: 12, repeat: Infinity, ease: 'easeInOut' }}
        />
        <motion.div
          className="absolute w-[400px] h-[400px] md:w-[500px] md:h-[500px] rounded-full animate-morph"
          style={{ background: 'radial-gradient(circle, rgba(236,72,153,0.08) 0%, transparent 70%)', bottom: '0%', right: '10%' }}
          animate={{ x: [0, -80, 50, 0], y: [0, 60, -70, 0], scale: [1, 0.75, 1.2, 1] }}
          transition={{ duration: 14, repeat: Infinity, ease: 'easeInOut' }}
        />
        <SplashParticles />
      </div>

      <div className="relative z-10 flex flex-col items-center px-6">
        <motion.div
          initial={{ scale: 0, rotate: -180, opacity: 0 }}
          animate={{ scale: 1, rotate: 0, opacity: 1 }}
          transition={{ type: 'spring', stiffness: 120, damping: 12, delay: 0.1 }}
        >
          <div className="relative">
            <motion.div
              className="absolute inset-0 blur-[70px]"
              style={{ background: 'radial-gradient(circle, rgba(122,90,248,0.5) 0%, transparent 70%)' }}
              animate={{ scale: [1, 1.5, 1], opacity: [0.3, 0.7, 0.3] }}
              transition={{ duration: 3, repeat: Infinity }}
            />
            <div className="relative w-28 h-28 md:w-40 md:h-40 rounded-[28px] md:rounded-[30px] bg-gradient-to-br from-cent-400 via-cent-500 to-cent-700 flex items-center justify-center shadow-2xl shadow-cent-500/50">
              <div className="absolute inset-0 rounded-[28px] md:rounded-[30px] overflow-hidden">
                <div className="absolute -inset-1/2 bg-gradient-to-br from-white/25 via-transparent to-transparent rotate-12" />
              </div>
              <motion.span
                className="text-5xl md:text-7xl font-display font-black text-white relative z-10"
                animate={{ textShadow: ['0 0 20px rgba(255,255,255,0.3)', '0 0 60px rgba(255,255,255,0.6)', '0 0 20px rgba(255,255,255,0.3)'] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                C
              </motion.span>
            </div>
          </div>
        </motion.div>

        <AnimatePresence>
          {(phase === 'text' || phase === 'loading' || phase === 'exit') && (
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: 'easeOut' }}
              className="text-center mt-8 md:mt-10"
            >
              <h1 className="text-6xl md:text-8xl font-display font-black tracking-tight">
                <span className="text-gradient animate-text-glow">CENT</span>
              </h1>
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.3 }}
                className="text-xs md:text-base text-white/20 mt-2 md:mt-3 tracking-[0.35em] uppercase font-light"
              >
                Global AI Music
              </motion.p>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {(phase === 'loading' || phase === 'exit') && (
            <motion.div
              initial={{ opacity: 0, width: 0 }}
              animate={{ opacity: 1, width: 200 }}
              transition={{ duration: 0.4 }}
              className="mt-10 md:mt-12"
            >
              <div className="w-[200px] md:w-[240px] h-[3px] bg-white/5 rounded-full overflow-hidden">
                <motion.div
                  className="h-full rounded-full"
                  style={{
                    width: `${progress}%`,
                    background: 'linear-gradient(90deg, #7a5af8, #a78bfa, #ec4899)',
                    boxShadow: '0 0 25px rgba(122,90,248,0.5)',
                  }}
                />
              </div>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="flex justify-between mt-3"
              >
                <span className="text-[10px] text-white/10 font-mono">v14.0.0</span>
                <span className="text-[10px] text-white/10 font-mono">{progress}%</span>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}

/* ============ PAGE ROUTER ============ */
function PageContent() {
  const currentPage = useStore(s => s.currentPage);

  switch (currentPage) {
    case 'home': return <HomePage />;
    case 'explore': return <ExplorePage />;
    case 'search': return <SearchPage />;
    case 'library': return <LibraryPage />;
    case 'recognize': return <RecognizePage />;
    case 'about': return <AboutPage />;
    case 'admin': return <AdminPage />;
    case 'playlist': return <PlaylistPage />;
    case 'artist': return <ArtistPage />;
    case 'youtube': return <YouTubePage />;
    case 'aichat': return <AIChatPage />;
    case 'settings': return <SettingsPage />;
    default: return <HomePage />;
  }
}

/* ============ PERSISTENT YOUTUBE PLAYER ============ */
function PersistentYouTubePlayer() {
  const currentTrack = useStore(s => s.currentTrack);
  const isPlaying = useStore(s => s.isPlaying);
  
  const isYT = currentTrack?.id?.startsWith('yt_') || false;
  const videoId = isYT && currentTrack ? currentTrack.id.replace('yt_', '') : null;

  if (!videoId) return null;

  // Hidden iframe that plays YouTube audio in background
  // autoplay=1 makes it play immediately
  // When isPlaying changes, we reload with autoplay on/off
  return (
    <div
      style={{
        position: 'fixed',
        width: 1,
        height: 1,
        bottom: 0,
        left: 0,
        opacity: 0.01,
        pointerEvents: 'none',
        zIndex: -1,
        overflow: 'hidden',
      }}
      aria-hidden="true"
    >
      <iframe
        key={`${videoId}_${isPlaying}`}
        src={`https://www.youtube.com/embed/${videoId}?autoplay=${isPlaying ? 1 : 0}&rel=0&playsinline=1&enablejsapi=1`}
        title="CENT YouTube Audio"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope"
        style={{ width: 320, height: 180 }}
      />
    </div>
  );
}

/* ============ MAIN APP ============ */
export function App() {
  const [showSplash, setShowSplash] = useState(true);
  const showMiniPlayer = useStore(s => s.showMiniPlayer);
  const currentPage = useStore(s => s.currentPage);
  // CRITICAL: useAudioPlayer creates the global audio system singleton.
  // It must be called HERE at the top level so it persists across ALL page navigations.
  // The audio element lives OUTSIDE React, so it continues playing even when components unmount.
  const audioPlayer = useAudioPlayer();
  const { language } = useSettings();

  const theme = useStore(s => s.theme);

  // Apply language direction on mount and changes
  useEffect(() => {
    const isRTL = RTL_LANGUAGES.includes(language);
    document.documentElement.dir = isRTL ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [language]);

  // Apply theme on mount and changes
  useEffect(() => {
    document.documentElement.classList.toggle('light', theme === 'light');
    document.documentElement.classList.toggle('dark', theme === 'dark');
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', theme === 'dark' ? '#050509' : '#f5f5f7');
  }, [theme]);

  // Register Service Worker for PWA + background audio
  useEffect(() => {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').catch(() => {});
    }
  }, []);

  const handleSplashComplete = useCallback(() => setShowSplash(false), []);

  if (showSplash) {
    return <SplashScreen onComplete={handleSplashComplete} />;
  }

  // AudioCtx.Provider wraps EVERYTHING so audio persists across all pages including player
  return (
    <AudioCtx.Provider value={audioPlayer}>
      {/* Persistent hidden YouTube iframe - plays audio in background across all pages */}
      <PersistentYouTubePlayer />

      {currentPage === 'player' ? (
        // Player page is full screen but audio context is still provided from parent
        <PlayerPage />
      ) : (
        <div className="min-h-screen bg-mesh text-white">
          {/* Noise texture */}
          <div className="fixed inset-0 pointer-events-none z-0 opacity-[0.008]" style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E")`,
            backgroundRepeat: 'repeat',
          }} />

          <Sidebar />

          <main className={`lg:ml-[260px] relative z-10 ${showMiniPlayer ? 'pb-44 lg:pb-32' : 'pb-28 lg:pb-8'}`}>
            <div className="px-4 md:px-6 lg:px-8 pt-4 lg:pt-6">
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentPage}
                  initial={{ opacity: 0, y: 16, filter: 'blur(4px)' }}
                  animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                  exit={{ opacity: 0, y: -16, filter: 'blur(4px)' }}
                  transition={{ duration: 0.3, ease: 'easeOut' }}
                >
                  <PageContent />
                </motion.div>
              </AnimatePresence>
            </div>
          </main>

          <MiniPlayer />
          <MobileNav />
        </div>
      )}
    </AudioCtx.Provider>
  );
}
