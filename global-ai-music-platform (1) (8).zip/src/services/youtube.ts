const YT_API_KEY = 'AIzaSyDB8kRZYHXPjhgg-oT6pEQdAapYhhY64LM';
const YT_BASE = 'https://www.googleapis.com/youtube/v3';

export interface YouTubeVideo {
  id: string;
  title: string;
  channel: string;
  thumbnail: string;
  thumbnailHigh: string;
  publishedAt: string;
  description: string;
  viewCount?: string;
  duration?: string;
}

export interface YouTubeSearchResult {
  items: YouTubeVideo[];
  nextPageToken?: string;
  totalResults: number;
}

/* ========== CACHE ========== */
const searchCache = new Map<string, { data: YouTubeSearchResult; ts: number }>();
let trendingCached: { data: YouTubeVideo[]; ts: number } = { data: [], ts: 0 };
const CACHE_TTL = 10 * 60 * 1000;

/* ========== ABORT ========== */
let activeController: AbortController | null = null;

export function cancelPendingSearch() {
  if (activeController) {
    try { activeController.abort(); } catch { /* ignore */ }
    activeController = null;
  }
}

/* ========== SAFE FETCH ========== */
async function safeFetch(url: string, signal?: AbortSignal): Promise<any> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15000);

  try {
    const res = await fetch(url, {
      signal: signal || controller.signal,
    });
    clearTimeout(timer);

    if (!res.ok) {
      const text = await res.text().catch(() => '');
      console.warn(`YT API Error ${res.status}:`, text.slice(0, 300));
      throw new Error(`YouTube API error: ${res.status}`);
    }
    return await res.json();
  } catch (err) {
    clearTimeout(timer);
    throw err;
  }
}

/* ========== SEARCH ========== */
export async function searchYouTubeMusic(query: string, maxResults = 20): Promise<YouTubeSearchResult> {
  const q = query.trim();
  if (!q) return { items: [], totalResults: 0 };

  // Check cache first
  const cacheKey = `${q.toLowerCase()}_${maxResults}`;
  const cached = searchCache.get(cacheKey);
  if (cached && Date.now() - cached.ts < CACHE_TTL) {
    return cached.data;
  }

  // Cancel any pending search
  cancelPendingSearch();
  const controller = new AbortController();
  activeController = controller;

  try {
    // Simple search - don't modify the query
    const params = new URLSearchParams({
      part: 'snippet',
      q: q,
      type: 'video',
      maxResults: String(Math.min(maxResults, 50)),
      key: YT_API_KEY,
      order: 'relevance',
    });

    const data = await safeFetch(`${YT_BASE}/search?${params}`, controller.signal);

    if (!data.items?.length) {
      return { items: [], totalResults: 0 };
    }

    // Extract video IDs
    const videoIds = data.items
      .filter((i: any) => i.id?.videoId)
      .map((i: any) => i.id.videoId);

    if (videoIds.length === 0) {
      return { items: [], totalResults: 0 };
    }

    // Get details (views + duration) in one call
    let detailsMap: Record<string, { viewCount?: string; duration?: string }> = {};
    try {
      const detailsParams = new URLSearchParams({
        part: 'statistics,contentDetails',
        id: videoIds.join(','),
        key: YT_API_KEY,
      });
      const detailsData = await safeFetch(`${YT_BASE}/videos?${detailsParams}`, controller.signal);
      if (detailsData.items) {
        for (const item of detailsData.items) {
          detailsMap[item.id] = {
            viewCount: item.statistics?.viewCount,
            duration: formatYTDuration(item.contentDetails?.duration),
          };
        }
      }
    } catch {
      // Continue without details
    }

    const items: YouTubeVideo[] = data.items
      .filter((item: any) => item.id?.videoId)
      .map((item: any) => {
        const vid = item.id.videoId;
        const details = detailsMap[vid] || {};
        return {
          id: vid,
          title: decodeHTML(item.snippet?.title || ''),
          channel: item.snippet?.channelTitle || '',
          thumbnail: item.snippet?.thumbnails?.medium?.url || item.snippet?.thumbnails?.default?.url || '',
          thumbnailHigh: item.snippet?.thumbnails?.high?.url || '',
          publishedAt: item.snippet?.publishedAt || '',
          description: item.snippet?.description || '',
          viewCount: details.viewCount,
          duration: details.duration,
        };
      });

    const result: YouTubeSearchResult = {
      items,
      nextPageToken: data.nextPageToken,
      totalResults: data.pageInfo?.totalResults || items.length,
    };

    // Cache result
    searchCache.set(cacheKey, { data: result, ts: Date.now() });
    if (searchCache.size > 80) {
      const first = searchCache.keys().next().value;
      if (first) searchCache.delete(first);
    }

    return result;
  } catch (err) {
    if (err instanceof DOMException && err.name === 'AbortError') {
      return { items: [], totalResults: 0 };
    }
    throw err;
  }
}

/* ========== TRENDING ========== */
export async function getYouTubeTrending(maxResults = 20): Promise<YouTubeVideo[]> {
  if (trendingCached.data.length > 0 && Date.now() - trendingCached.ts < CACHE_TTL) {
    return trendingCached.data;
  }

  const params = new URLSearchParams({
    part: 'snippet,statistics,contentDetails',
    chart: 'mostPopular',
    videoCategoryId: '10',
    maxResults: String(maxResults),
    key: YT_API_KEY,
    regionCode: 'US',
  });

  const data = await safeFetch(`${YT_BASE}/videos?${params}`);

  const items: YouTubeVideo[] = (data.items || []).map((item: any) => ({
    id: item.id,
    title: decodeHTML(item.snippet?.title || ''),
    channel: item.snippet?.channelTitle || '',
    thumbnail: item.snippet?.thumbnails?.medium?.url || '',
    thumbnailHigh: item.snippet?.thumbnails?.high?.url || '',
    publishedAt: item.snippet?.publishedAt || '',
    description: item.snippet?.description || '',
    viewCount: item.statistics?.viewCount,
    duration: formatYTDuration(item.contentDetails?.duration),
  }));

  trendingCached = { data: items, ts: Date.now() };
  return items;
}

/* ========== SEARCH BY CATEGORY ========== */
export async function searchYouTubeByCategory(category: string, maxResults = 12): Promise<YouTubeVideo[]> {
  const result = await searchYouTubeMusic(category, maxResults);
  return result.items;
}

/* ========== HELPERS ========== */
function decodeHTML(html: string): string {
  const txt = document.createElement('textarea');
  txt.innerHTML = html;
  return txt.value;
}

export function formatViewCount(count: string | undefined): string {
  if (!count) return '';
  const n = parseInt(count);
  if (isNaN(n)) return count;
  if (n >= 1e9) return (n / 1e9).toFixed(1) + 'B';
  if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
  if (n >= 1e3) return (n / 1e3).toFixed(1) + 'K';
  return count;
}

export function formatYTDuration(iso: string | undefined): string {
  if (!iso) return '';
  const m = iso.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
  if (!m) return '';
  const h = m[1] ? parseInt(m[1]) : 0;
  const min = m[2] ? parseInt(m[2]) : 0;
  const s = m[3] ? parseInt(m[3]) : 0;
  if (h > 0) return `${h}:${String(min).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  return `${min}:${String(s).padStart(2, '0')}`;
}

export function getTimeAgo(dateStr: string): string {
  if (!dateStr) return '';
  const diff = Date.now() - new Date(dateStr).getTime();
  if (isNaN(diff)) return '';
  const s = Math.floor(diff / 1000);
  const min = Math.floor(s / 60);
  const h = Math.floor(min / 60);
  const d = Math.floor(h / 24);
  const mo = Math.floor(d / 30);
  const y = Math.floor(d / 365);
  if (y > 0) return `${y}y ago`;
  if (mo > 0) return `${mo}mo ago`;
  if (d > 0) return `${d}d ago`;
  if (h > 0) return `${h}h ago`;
  if (min > 0) return `${min}m ago`;
  return 'Just now';
}
