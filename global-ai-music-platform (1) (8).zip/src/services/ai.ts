const AI_API_KEY = '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';
const AI_BASE = 'https://openrouter.ai/api/v1';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
}

const SYSTEM_PROMPT = `You are CENT AI — the intelligent music assistant for the CENT Global AI Music Platform. You are helpful, enthusiastic about music, and knowledgeable about all genres, artists, and music theory.

Your capabilities:
- Recommend songs, albums, and artists based on mood, genre, or similar artists
- Create themed playlists with song suggestions
- Explain music theory, production techniques, and song structures
- Discuss music history and cultural significance
- Analyze lyrics and song meanings
- Suggest music for specific activities (workout, study, relaxation, etc.)
- Share interesting facts about artists and songs
- You can respond in Arabic, English, or any language the user uses

Always respond in a friendly, engaging tone. Use emojis occasionally. Keep responses concise but informative. When recommending music, include artist names and song titles.

You are part of the CENT platform — a global AI music startup. Be proud of the platform and its features like spatial audio, AI recognition, and personalized discovery.`;

// List of free models to try in order (most reliable first)
const MODELS = [
  'meta-llama/llama-3.3-8b-instruct:free',
  'google/gemma-3-1b-it:free',
  'qwen/qwen3-8b:free',
  'deepseek/deepseek-chat-v3-0324:free',
  'microsoft/phi-4-reasoning-plus:free',
  'deepseek/deepseek-r1-0528:free',
];

export async function sendChatMessage(
  messages: ChatMessage[],
  onStream?: (chunk: string) => void
): Promise<string> {
  const apiMessages = [
    { role: 'system' as const, content: SYSTEM_PROMPT },
    ...messages.map(m => ({
      role: m.role as 'user' | 'assistant',
      content: m.content,
    })),
  ];

  // Try streaming first, then non-streaming
  for (const model of MODELS) {
    try {
      // Try streaming
      if (onStream) {
        try {
          const result = await fetchAI(model, apiMessages, true, onStream);
          if (result && result.length > 5) return result;
        } catch {
          // Streaming failed, try non-streaming with same model
        }
      }

      // Non-streaming fallback
      const result = await fetchAI(model, apiMessages, false);
      if (result && result.length > 5) return result;
    } catch (err) {
      console.warn(`Model ${model} failed:`, err);
      continue;
    }
  }

  throw new Error('All AI models are currently unavailable. Please try again later.');
}

async function fetchAI(
  model: string,
  messages: { role: string; content: string }[],
  stream: boolean,
  onStream?: (chunk: string) => void
): Promise<string> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30000); // 30s timeout

  try {
    const res = await fetch(`${AI_BASE}/chat/completions`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${AI_API_KEY}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': window.location.origin || 'https://cent.music',
        'X-Title': 'CENT Music Platform',
      },
      body: JSON.stringify({
        model,
        messages,
        stream,
        max_tokens: 1024,
        temperature: 0.8,
      }),
      signal: controller.signal,
    });

    clearTimeout(timeout);

    if (!res.ok) {
      throw new Error(`HTTP ${res.status}`);
    }

    if (stream && onStream && res.body) {
      return await readStream(res.body, onStream);
    } else {
      const data = await res.json();
      const content = data.choices?.[0]?.message?.content;
      if (!content) throw new Error('Empty response');
      return content;
    }
  } catch (err) {
    clearTimeout(timeout);
    throw err;
  }
}

async function readStream(body: ReadableStream, onStream: (chunk: string) => void): Promise<string> {
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let fullContent = '';
  let buffer = '';

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith('data: ')) continue;
        const data = trimmed.slice(6);
        if (data === '[DONE]') continue;

        try {
          const parsed = JSON.parse(data);
          const content = parsed.choices?.[0]?.delta?.content;
          if (content) {
            fullContent += content;
            onStream(fullContent);
          }
        } catch {
          // Skip malformed JSON
        }
      }
    }
  } catch {
    // Stream interrupted - return what we have
  } finally {
    reader.releaseLock();
  }

  if (fullContent.length === 0) throw new Error('Empty stream');
  return fullContent;
}

export const QUICK_PROMPTS = [
  { text: '🎵 Recommend songs for studying', prompt: 'Recommend me some great songs for studying and focusing. I like ambient, lo-fi, and calm electronic music.' },
  { text: '🎸 Best rock albums ever', prompt: 'What are the best rock albums of all time? Give me a top 10 list with brief descriptions.' },
  { text: '😊 Happy mood playlist', prompt: 'Create a happy, upbeat playlist of 10 songs that will boost my mood. Mix of genres please!' },
  { text: '🎹 Explain music theory', prompt: 'Explain the basics of music theory in a simple way. What are scales, chords, and progressions?' },
  { text: '🌙 Late night vibes', prompt: 'Suggest some perfect late night listening. I want something atmospheric and moody.' },
  { text: '🏋️ Workout playlist', prompt: 'Create an intense workout playlist with 10 high-energy songs across different genres.' },
  { text: '🎤 Similar to The Weeknd', prompt: 'Recommend me artists and songs similar to The Weeknd. I love his dark R&B style.' },
  { text: '📖 Song meaning analysis', prompt: 'Analyze the meaning behind "Bohemian Rhapsody" by Queen. What is the song really about?' },
];
