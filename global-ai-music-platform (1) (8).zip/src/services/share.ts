import type { Track } from '../store/useStore';

/* ========== SHARE ========== */
export async function shareTrack(track: Track): Promise<boolean> {
  const shareData = {
    title: `${track.title} — ${track.artist}`,
    text: `🎵 Listen to "${track.title}" by ${track.artist} on CENT\n\n${track.album} • ${track.genre}`,
    url: window.location.origin,
  };

  // Try native Web Share API first (works on mobile)
  if (navigator.share) {
    try {
      await navigator.share(shareData);
      return true;
    } catch (err) {
      if ((err as Error).name === 'AbortError') return false;
      // Fall through to clipboard
    }
  }

  // Fallback: copy to clipboard
  try {
    await navigator.clipboard.writeText(`${shareData.text}\n${shareData.url}`);
    return true;
  } catch {
    // Last resort: use deprecated execCommand
    const textArea = document.createElement('textarea');
    textArea.value = `${shareData.text}\n${shareData.url}`;
    textArea.style.position = 'fixed';
    textArea.style.left = '-9999px';
    document.body.appendChild(textArea);
    textArea.select();
    try {
      document.execCommand('copy');
      document.body.removeChild(textArea);
      return true;
    } catch {
      document.body.removeChild(textArea);
      return false;
    }
  }
}

export async function shareYouTubeVideo(videoId: string, title: string): Promise<boolean> {
  const shareData = {
    title: title,
    text: `🎬 Watch "${title}" on CENT`,
    url: `https://www.youtube.com/watch?v=${videoId}`,
  };

  if (navigator.share) {
    try {
      await navigator.share(shareData);
      return true;
    } catch {
      // Fall through
    }
  }

  try {
    await navigator.clipboard.writeText(shareData.url);
    return true;
  } catch {
    return false;
  }
}

/* ========== DOWNLOAD ========== */
export function downloadTrack(track: Track): void {
  // For YouTube tracks, open YouTube page
  if (track.id.startsWith('yt_')) {
    const videoId = track.id.replace('yt_', '');
    window.open(`https://www.youtube.com/watch?v=${videoId}`, '_blank');
    showToast('📥 Opening YouTube...', 'info');
    return;
  }

  // For Jamendo tracks — direct MP3 download!
  if (track.id.startsWith('jm_') && track.downloadUrl) {
    window.open(track.downloadUrl, '_blank');
    showToast(`📥 Downloading "${track.title}" from Jamendo...`, 'success');
    return;
  }
  if (track.id.startsWith('jm_') && track.audioUrl) {
    window.open(track.audioUrl, '_blank');
    showToast(`📥 Downloading "${track.title}"...`, 'success');
    return;
  }
  
  // For demo tracks: open the audio URL directly (browser will handle download)
  const audioSources: Record<string, string> = {};
  for (let i = 1; i <= 12; i++) {
    audioSources[String(i)] = `https://www.soundhelix.com/examples/mp3/SoundHelix-Song-${i}.mp3`;
  }
  
  const src = audioSources[track.id];
  if (src) {
    window.open(src, '_blank');
    showToast(`📥 Downloading "${track.title}"...`, 'success');
  } else {
    showToast('Download not available', 'error');
  }
}

export function downloadYouTubeLink(videoId: string): void {
  // Open YouTube video page (actual download requires backend)
  window.open(`https://www.youtube.com/watch?v=${videoId}`, '_blank');
}

/* ========== TOAST NOTIFICATION ========== */
let toastTimeout: ReturnType<typeof setTimeout> | null = null;
let toastElement: HTMLDivElement | null = null;

export function showToast(message: string, type: 'success' | 'error' | 'info' = 'success') {
  // Remove existing toast
  if (toastElement) {
    document.body.removeChild(toastElement);
    toastElement = null;
  }
  if (toastTimeout) clearTimeout(toastTimeout);

  const colors = {
    success: 'background: linear-gradient(135deg, rgba(16,185,129,0.95), rgba(5,150,105,0.95));',
    error: 'background: linear-gradient(135deg, rgba(239,68,68,0.95), rgba(220,38,38,0.95));',
    info: 'background: linear-gradient(135deg, rgba(122,90,248,0.95), rgba(91,33,182,0.95));',
  };

  const toast = document.createElement('div');
  toast.innerHTML = `<div style="display:flex;align-items:center;gap:8px;">
    <span style="font-size:16px;">${type === 'success' ? '✓' : type === 'error' ? '✗' : 'ℹ'}</span>
    <span>${message}</span>
  </div>`;
  toast.style.cssText = `
    position: fixed; top: 20px; left: 50%; transform: translateX(-50%) translateY(-20px);
    z-index: 99999; padding: 12px 24px; border-radius: 16px; color: white;
    font-size: 14px; font-weight: 600; font-family: Inter, sans-serif;
    ${colors[type]}
    backdrop-filter: blur(20px); box-shadow: 0 8px 32px rgba(0,0,0,0.3);
    animation: toast-in 0.3s ease forwards;
    pointer-events: none;
  `;

  // Add animation
  const style = document.createElement('style');
  style.textContent = `
    @keyframes toast-in { from { opacity:0; transform: translateX(-50%) translateY(-20px); } to { opacity:1; transform: translateX(-50%) translateY(0); } }
    @keyframes toast-out { from { opacity:1; transform: translateX(-50%) translateY(0); } to { opacity:0; transform: translateX(-50%) translateY(-20px); } }
  `;
  toast.appendChild(style);

  document.body.appendChild(toast);
  toastElement = toast;

  toastTimeout = setTimeout(() => {
    if (toast.parentNode) {
      toast.style.animation = 'toast-out 0.3s ease forwards';
      setTimeout(() => {
        if (toast.parentNode) document.body.removeChild(toast);
        toastElement = null;
      }, 300);
    }
  }, 2500);
}
