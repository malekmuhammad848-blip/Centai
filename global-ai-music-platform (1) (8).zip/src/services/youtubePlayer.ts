/**
 * YouTube Player Bridge
 * Bridges YouTube video playback with the CENT store system
 * so MiniPlayer, notifications, and background controls work
 */
import { useStore, type Track } from '../store/useStore';
import type { YouTubeVideo } from './youtube';

// Convert YouTube video to a Track object for the store
export function youtubeVideoToTrack(video: YouTubeVideo): Track {
  return {
    id: `yt_${video.id}`,
    title: video.title,
    artist: video.channel,
    album: 'YouTube',
    duration: parseDurationToSeconds(video.duration || '0:00'),
    cover: video.thumbnailHigh || video.thumbnail,
    genre: 'YouTube',
    plays: parseInt(video.viewCount || '0') || 0,
    liked: false,
    color: '#ef4444', // YouTube red
  };
}

function parseDurationToSeconds(duration: string): number {
  const parts = duration.split(':').map(Number);
  if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  if (parts.length === 2) return parts[0] * 60 + parts[1];
  return parts[0] || 0;
}

/**
 * Play a YouTube video through the CENT store.
 * This ensures:
 * 1. MiniPlayer shows at the bottom
 * 2. Media Session notifications work (lock screen controls)
 * 3. Track info is displayed everywhere
 */
export function playYouTubeVideo(video: YouTubeVideo) {
  const track = youtubeVideoToTrack(video);
  const store = useStore.getState();
  
  // Stop any regular audio that might be playing
  // The globalAudio element is handled by useAudioPlayer - it will skip YT tracks
  
  // IMPORTANT: Set all three in the correct order
  store.setCurrentTrack(track);  // This also sets showMiniPlayer: true
  store.setShowMiniPlayer(true); // Explicit - ensure MiniPlayer shows
  store.setIsPlaying(true);      // Set playing state
  store.setProgress(0);          // Reset progress for new track

  // Update Media Session for lock screen / notification controls
  if ('mediaSession' in navigator) {
    try {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: video.title,
        artist: video.channel,
        album: 'YouTube Music • CENT',
        artwork: [
          { src: video.thumbnail, sizes: '96x96', type: 'image/jpeg' },
          { src: video.thumbnail, sizes: '128x128', type: 'image/jpeg' },
          { src: video.thumbnailHigh || video.thumbnail, sizes: '256x256', type: 'image/jpeg' },
          { src: video.thumbnailHigh || video.thumbnail, sizes: '512x512', type: 'image/jpeg' },
        ],
      });
      navigator.mediaSession.playbackState = 'playing';
    } catch {
      // MediaSession not supported or errored
    }
  }

  console.log('[CENT] ▶ YouTube:', video.title, '| MiniPlayer ✓ | Background audio via hidden iframe ✓');
}

// Check if a track is a YouTube track
export function isYouTubeTrack(track: Track | null): boolean {
  return track?.id?.startsWith('yt_') || false;
}

// Get YouTube video ID from a CENT track
export function getYouTubeVideoId(track: Track): string | null {
  if (!track.id.startsWith('yt_')) return null;
  return track.id.replace('yt_', '');
}
