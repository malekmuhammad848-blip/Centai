/**
 * Jamendo API Service — Free Music with Download Links
 * Base URL: https://api.jamendo.com/v3.0
 * Client ID: c8157cf1
 */

const JAMENDO_BASE = 'https://api.jamendo.com/v3.0';
const CLIENT_ID = 'c8157cf1';

export interface JamendoTrack {
  id: string;
  name: string;
  artist_name: string;
  album_name: string;
  album_image: string;
  duration: number;
  audio: string;        // Stream URL
  audiodownload: string; // Download URL
  position: number;
  shareurl: string;
  image: string;
  releasedate: string;
  genre?: string;
}

export interface JamendoSearchResult {
  results: JamendoTrack[];
  headers: { results_count: number };
}

/* ========== CACHE ========== */
const cache = new Map<string, { data: JamendoTrack[]; ts: number }>();
const CACHE_TTL = 10 * 60 * 1000;

/* ========== SEARCH ========== */
export async function searchJamendo(query: string, limit = 20): Promise<JamendoTrack[]> {
  const q = query.trim();
  if (!q) return [];

  const cacheKey = `${q.toLowerCase()}_${limit}`;
  const cached = cache.get(cacheKey);
  if (cached && Date.now() - cached.ts < CACHE_TTL) return cached.data;

  try {
    const params = new URLSearchParams({
      client_id: CLIENT_ID,
      format: 'json',
      limit: String(limit),
      search: q,
      include: 'musicinfo',
      imagesize: '300',
      audioformat: 'mp32',
    });

    const res = await fetch(`${JAMENDO_BASE}/tracks?${params}`);
    if (!res.ok) throw new Error(`Jamendo API error: ${res.status}`);
    
    const data = await res.json();
    const tracks: JamendoTrack[] = (data.results || []).map((t: any) => ({
      id: String(t.id),
      name: t.name || 'Unknown',
      artist_name: t.artist_name || 'Unknown Artist',
      album_name: t.album_name || '',
      album_image: t.album_image || t.image || '',
      duration: t.duration || 0,
      audio: t.audio || '',
      audiodownload: t.audiodownload || '',
      position: t.position || 0,
      shareurl: t.shareurl || '',
      image: t.image || t.album_image || '',
      releasedate: t.releasedate || '',
      genre: t.musicinfo?.tags?.genres?.[0] || '',
    }));

    cache.set(cacheKey, { data: tracks, ts: Date.now() });
    if (cache.size > 50) {
      const first = cache.keys().next().value;
      if (first) cache.delete(first);
    }

    return tracks;
  } catch (err) {
    console.warn('Jamendo search error:', err);
    return [];
  }
}

/* ========== GET TRACK WITH DOWNLOAD LINK ========== */
export async function getJamendoTrack(trackId: string): Promise<JamendoTrack | null> {
  try {
    const params = new URLSearchParams({
      client_id: CLIENT_ID,
      format: 'json',
      id: trackId,
      audioformat: 'mp32',
    });

    const res = await fetch(`${JAMENDO_BASE}/tracks?${params}`);
    if (!res.ok) throw new Error(`Jamendo API error: ${res.status}`);
    
    const data = await res.json();
    if (!data.results?.length) return null;

    const t = data.results[0];
    return {
      id: String(t.id),
      name: t.name,
      artist_name: t.artist_name,
      album_name: t.album_name || '',
      album_image: t.album_image || t.image || '',
      duration: t.duration || 0,
      audio: t.audio || '',
      audiodownload: t.audiodownload || '',
      position: t.position || 0,
      shareurl: t.shareurl || '',
      image: t.image || '',
      releasedate: t.releasedate || '',
    };
  } catch {
    return null;
  }
}

/* ========== GET POPULAR TRACKS ========== */
let popularCache: { data: JamendoTrack[]; ts: number } = { data: [], ts: 0 };

export async function getJamendoPopular(limit = 20): Promise<JamendoTrack[]> {
  if (popularCache.data.length > 0 && Date.now() - popularCache.ts < CACHE_TTL) {
    return popularCache.data;
  }

  try {
    const params = new URLSearchParams({
      client_id: CLIENT_ID,
      format: 'json',
      limit: String(limit),
      order: 'popularity_week',
      imagesize: '300',
      audioformat: 'mp32',
      include: 'musicinfo',
    });

    const res = await fetch(`${JAMENDO_BASE}/tracks?${params}`);
    if (!res.ok) throw new Error(`Jamendo error: ${res.status}`);
    
    const data = await res.json();
    const tracks: JamendoTrack[] = (data.results || []).map((t: any) => ({
      id: String(t.id),
      name: t.name || 'Unknown',
      artist_name: t.artist_name || 'Unknown',
      album_name: t.album_name || '',
      album_image: t.album_image || t.image || '',
      duration: t.duration || 0,
      audio: t.audio || '',
      audiodownload: t.audiodownload || '',
      position: t.position || 0,
      shareurl: t.shareurl || '',
      image: t.image || '',
      releasedate: t.releasedate || '',
      genre: t.musicinfo?.tags?.genres?.[0] || '',
    }));

    popularCache = { data: tracks, ts: Date.now() };
    return tracks;
  } catch {
    return [];
  }
}

/* ========== CONVERT TO CENT TRACK ========== */
import type { Track } from '../store/useStore';

export function jamendoToTrack(jt: JamendoTrack): Track {
  return {
    id: `jm_${jt.id}`,
    title: jt.name,
    artist: jt.artist_name,
    album: jt.album_name || 'Jamendo',
    duration: jt.duration,
    cover: jt.album_image || jt.image || 'https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=300&h=300&fit=crop',
    genre: jt.genre || 'Jamendo',
    plays: 0,
    liked: false,
    color: '#1db954', // Jamendo green
    audioUrl: jt.audio,
    downloadUrl: jt.audiodownload,
  };
}

/* ========== FORMAT DURATION ========== */
export function formatJamendoDuration(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}
