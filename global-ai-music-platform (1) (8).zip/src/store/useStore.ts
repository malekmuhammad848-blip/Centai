import { create } from 'zustand';

export interface Track {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: number;
  cover: string;
  genre: string;
  plays: number;
  liked: boolean;
  color: string;
  // Optional fields for Jamendo tracks
  audioUrl?: string;
  downloadUrl?: string;
}

export interface Artist {
  id: string;
  name: string;
  image: string;
  followers: number;
  genre: string;
  verified: boolean;
}

export interface Playlist {
  id: string;
  name: string;
  cover: string;
  trackCount: number;
  description: string;
  gradient: string;
}

type Page = 'home' | 'explore' | 'library' | 'search' | 'recognize' | 'player' | 'about' | 'admin' | 'playlist' | 'artist' | 'album' | 'youtube' | 'aichat' | 'settings';

// Load favorites from localStorage
function loadFavorites(): string[] {
  try {
    const stored = localStorage.getItem('cent_favorites');
    if (stored) return JSON.parse(stored);
  } catch { /* ignore */ }
  return [];
}

function saveFavorites(ids: string[]) {
  try { localStorage.setItem('cent_favorites', JSON.stringify(ids)); } catch { /* ignore */ }
}

// Load liked tracks data (full Track objects for YouTube/Jamendo tracks)
function loadLikedTracksMap(): Record<string, Track> {
  try {
    const stored = localStorage.getItem('cent_liked_tracks_map');
    if (stored) return JSON.parse(stored);
  } catch { /* ignore */ }
  return {};
}

function saveLikedTracksMap(map: Record<string, Track>) {
  try { localStorage.setItem('cent_liked_tracks_map', JSON.stringify(map)); } catch { /* ignore */ }
}

interface AppState {
  currentPage: Page;
  setPage: (page: Page) => void;
  currentTrack: Track | null;
  setCurrentTrack: (track: Track | null) => void;
  isPlaying: boolean;
  setIsPlaying: (playing: boolean) => void;
  togglePlay: () => void;
  queue: Track[];
  setQueue: (tracks: Track[]) => void;
  volume: number;
  setVolume: (vol: number) => void;
  progress: number;
  setProgress: (p: number) => void;
  isRecognizing: boolean;
  setIsRecognizing: (r: boolean) => void;
  recognizedTrack: Track | null;
  setRecognizedTrack: (t: Track | null) => void;
  favorites: string[];
  likedTracksMap: Record<string, Track>;
  toggleFavorite: (id: string, trackData?: Track | undefined) => void;
  isFavorite: (id: string) => boolean;
  getFavoriteTracks: () => Track[];
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  showMiniPlayer: boolean;
  setShowMiniPlayer: (s: boolean) => void;
  selectedPlaylist: Playlist | null;
  setSelectedPlaylist: (p: Playlist | null) => void;
  selectedArtist: Artist | null;
  setSelectedArtist: (a: Artist | null) => void;
  shuffle: boolean;
  toggleShuffle: () => void;
  repeatMode: 'off' | 'all' | 'one';
  cycleRepeat: () => void;
  equalizerPreset: string;
  setEqualizerPreset: (p: string) => void;
  theme: 'dark' | 'light';
  toggleTheme: () => void;
}

export const useStore = create<AppState>((set, get) => ({
  currentPage: 'home',
  setPage: (page) => set({ currentPage: page }),
  currentTrack: null,
  setCurrentTrack: (track) => set({ currentTrack: track, showMiniPlayer: !!track }),
  isPlaying: false,
  setIsPlaying: (playing) => set({ isPlaying: playing }),
  togglePlay: () => set((s) => ({ isPlaying: !s.isPlaying })),
  queue: [],
  setQueue: (tracks) => set({ queue: tracks }),
  volume: 80,
  setVolume: (vol) => set({ volume: vol }),
  progress: 0,
  setProgress: (p) => set({ progress: p }),
  isRecognizing: false,
  setIsRecognizing: (r) => set({ isRecognizing: r }),
  recognizedTrack: null,
  setRecognizedTrack: (t) => set({ recognizedTrack: t }),
  
  favorites: loadFavorites(),
  likedTracksMap: loadLikedTracksMap(),
  
  toggleFavorite: (id, trackData) => {
    const s = get();
    const isCurrentlyFav = s.favorites.includes(id);
    
    let newFavs: string[];
    let newMap = { ...s.likedTracksMap };
    
    if (isCurrentlyFav) {
      // Remove from favorites
      newFavs = s.favorites.filter(f => f !== id);
      delete newMap[id];
    } else {
      // Add to favorites
      newFavs = [...s.favorites, id];
      // Store the track data if provided, or use current track
      if (trackData) {
        newMap[id] = trackData;
      } else if (s.currentTrack && s.currentTrack.id === id) {
        newMap[id] = s.currentTrack;
      }
    }
    
    saveFavorites(newFavs);
    saveLikedTracksMap(newMap);
    set({ favorites: newFavs, likedTracksMap: newMap });
  },
  
  isFavorite: (id) => get().favorites.includes(id),
  
  getFavoriteTracks: () => {
    // This returns tracks from the likedTracksMap only
    // For mock TRACKS, the component should handle lookup
    const s = get();
    return Object.values(s.likedTracksMap).filter(t => s.favorites.includes(t.id));
  },
  
  searchQuery: '',
  setSearchQuery: (q) => set({ searchQuery: q }),
  showMiniPlayer: false,
  setShowMiniPlayer: (s) => set({ showMiniPlayer: s }),
  selectedPlaylist: null,
  setSelectedPlaylist: (p) => set({ selectedPlaylist: p }),
  selectedArtist: null,
  setSelectedArtist: (a) => set({ selectedArtist: a }),
  shuffle: false,
  toggleShuffle: () => set((s) => ({ shuffle: !s.shuffle })),
  repeatMode: 'off',
  cycleRepeat: () => set((s) => ({
    repeatMode: s.repeatMode === 'off' ? 'all' : s.repeatMode === 'all' ? 'one' : 'off'
  })),
  equalizerPreset: 'flat',
  setEqualizerPreset: (p) => set({ equalizerPreset: p }),
  theme: (localStorage.getItem('cent_theme') as 'dark' | 'light') || 'dark',
  toggleTheme: () => set((s) => {
    const newTheme = s.theme === 'dark' ? 'light' : 'dark';
    document.documentElement.classList.toggle('light', newTheme === 'light');
    document.documentElement.classList.toggle('dark', newTheme === 'dark');
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', newTheme === 'dark' ? '#050509' : '#f5f5f7');
    localStorage.setItem('cent_theme', newTheme);
    return { theme: newTheme };
  }),
}));
